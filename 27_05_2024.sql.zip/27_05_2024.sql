﻿prompt PL/SQL Developer import file
prompt Created on יום שני 27 מאי 2024 by USER
set feedback off
set define off
prompt Dropping ACADEMIC_INSTITUTION...
drop table ACADEMIC_INSTITUTION cascade constraints;
prompt Dropping TEACHER...
drop table TEACHER cascade constraints;
prompt Dropping TRAINING...
drop table TRAINING cascade constraints;
prompt Dropping PARTICIPANT...
drop table PARTICIPANT cascade constraints;
prompt Dropping PUPIL...
drop table PUPIL cascade constraints;
prompt Dropping STUDENTCOUNCIL...
drop table STUDENTCOUNCIL cascade constraints;
prompt Dropping REPRESENTIVE...
drop table REPRESENTIVE cascade constraints;
prompt Dropping TEACH...
drop table TEACH cascade constraints;
prompt Creating ACADEMIC_INSTITUTION...
create table ACADEMIC_INSTITUTION
(
  institutionid NUMBER(10) not null,
  name          VARCHAR2(30),
  kind          VARCHAR2(30),
  numofstudents NUMBER(4),
  numofteachers NUMBER(3),
  address       VARCHAR2(30)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table ACADEMIC_INSTITUTION
  add primary key (INSTITUTIONID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Creating TEACHER...
create table TEACHER
(
  id          NUMBER(9) not null,
  firstname   VARCHAR2(20),
  lastname    VARCHAR2(20),
  proffassion VARCHAR2(30),
  seniority   NUMBER(3),
  gender      VARCHAR2(1),
  phone       NUMBER(10),
  freeday     NUMBER(1)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table TEACHER
  add primary key (ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Creating TRAINING...
create table TRAINING
(
  trainingid    NUMBER(10) not null,
  location      VARCHAR2(30),
  training_date DATE,
  name          VARCHAR2(30)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table TRAINING
  add primary key (TRAININGID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Creating PARTICIPANT...
create table PARTICIPANT
(
  id         NUMBER(9) not null,
  trainingid NUMBER(10) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table PARTICIPANT
  add primary key (ID, TRAININGID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table PARTICIPANT
  add foreign key (ID)
  references TEACHER (ID);
alter table PARTICIPANT
  add foreign key (TRAININGID)
  references TRAINING (TRAININGID);

prompt Creating PUPIL...
create table PUPIL
(
  id            NUMBER(9) not null,
  firstname     VARCHAR2(20),
  lastname      VARCHAR2(20),
  birthdate     DATE,
  homeclass     VARCHAR2(4),
  gender        VARCHAR2(1),
  parentphone   NUMBER(10),
  institutionid NUMBER(10),
  allergics     VARCHAR2(30)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table PUPIL
  add primary key (ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table PUPIL
  add foreign key (INSTITUTIONID)
  references ACADEMIC_INSTITUTION (INSTITUTIONID);

prompt Creating STUDENTCOUNCIL...
create table STUDENTCOUNCIL
(
  year      NUMBER(4) not null,
  head      VARCHAR2(40),
  assistant VARCHAR2(40)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table STUDENTCOUNCIL
  add primary key (YEAR)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Creating REPRESENTIVE...
create table REPRESENTIVE
(
  id      NUMBER(9) not null,
  role    VARCHAR2(15),
  age     NUMBER(2),
  average NUMBER(3),
  year    NUMBER(4)
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table REPRESENTIVE
  add primary key (ID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table REPRESENTIVE
  add foreign key (YEAR)
  references STUDENTCOUNCIL (YEAR);
alter table REPRESENTIVE
  add foreign key (ID)
  references PUPIL (ID);

prompt Creating TEACH...
create table TEACH
(
  id            NUMBER(9) not null,
  institutionid NUMBER(10) not null
)
tablespace SYSTEM
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table TEACH
  add primary key (ID, INSTITUTIONID)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table TEACH
  add foreign key (ID)
  references TEACHER (ID);
alter table TEACH
  add foreign key (INSTITUTIONID)
  references ACADEMIC_INSTITUTION (INSTITUTIONID);

prompt Disabling triggers for ACADEMIC_INSTITUTION...
alter table ACADEMIC_INSTITUTION disable all triggers;
prompt Disabling triggers for TEACHER...
alter table TEACHER disable all triggers;
prompt Disabling triggers for TRAINING...
alter table TRAINING disable all triggers;
prompt Disabling triggers for PARTICIPANT...
alter table PARTICIPANT disable all triggers;
prompt Disabling triggers for PUPIL...
alter table PUPIL disable all triggers;
prompt Disabling triggers for STUDENTCOUNCIL...
alter table STUDENTCOUNCIL disable all triggers;
prompt Disabling triggers for REPRESENTIVE...
alter table REPRESENTIVE disable all triggers;
prompt Disabling triggers for TEACH...
alter table TEACH disable all triggers;
prompt Disabling foreign key constraints for PARTICIPANT...
alter table PARTICIPANT disable constraint SYS_C009151;
alter table PARTICIPANT disable constraint SYS_C009152;
prompt Disabling foreign key constraints for PUPIL...
alter table PUPIL disable constraint SYS_C009144;
prompt Disabling foreign key constraints for REPRESENTIVE...
alter table REPRESENTIVE disable constraint SYS_C009146;
alter table REPRESENTIVE disable constraint SYS_C009147;
prompt Disabling foreign key constraints for TEACH...
alter table TEACH disable constraint SYS_C009154;
alter table TEACH disable constraint SYS_C009155;
prompt Loading ACADEMIC_INSTITUTION...
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000000, 'Dorot SchoolOtzma SchoolPelech', 'Graduate School', 6049, 306, '63 Terence Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000001, 'Amit SiyonOtzma SchoolPelech S', 'Charter School', 2344, 733, '81 Milton Keynes Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000002, 'Merhavim SchoolOtzma SchoolPel', 'Public School', 528, 984, '925 Javon Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000003, 'Levona SchoolOtzma SchoolPelec', 'Bilingual School', 2694, 673, '22 Rizzo');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000004, 'Noam ToraniOtzma SchoolPelech ', 'Public School', 2185, 701, '14 Neeson Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000005, 'Maale GilboaOtzma SchoolPelech', 'Technical Institute', 569, 129, '433 Atlanta');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000006, 'Bnei Akiva DarcaOtzma SchoolPe', 'Early Childhood Education Cent', 4989, 592, '346 Feore Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000007, 'Bnot Rachel SchoolOtzma School', 'Bilingual School', 6311, 338, '38 Lucy Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000008, 'Harel High SchoolOtzma SchoolP', 'Youth Center', 2725, 210, '10 Morioka Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000009, 'Otzma SchoolPelech SchoolRamat', 'Medical School', 7876, 833, '81 Chandler Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000010, 'Keshet SchoolOtzma SchoolPelec', 'Graduate School', 5786, 6, '857 Palma de Mallorca Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000011, 'Mikveh IsraelOtzma SchoolPelec', 'After-School Program', 8546, 70, '75 Shepard Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000012, 'Bnei Akiva Givat ShmuelOtzma S', 'Law School', 5520, 50, '51st Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000013, 'Kiryat NoarOtzma SchoolPelech ', 'Technical Institute', 608, 68, '337 Essex Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000014, 'Mesivta SchoolOtzma SchoolPele', 'After-School Program', 9364, 819, '20 Tambor Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000015, 'Bialik SchoolOtzma SchoolPelec', 'Gifted and Talented School', 9645, 964, '29 Porto alegre Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000016, 'Amit ShacharOtzma SchoolPelech', 'Private School', 8337, 674, '9 Rik Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000017, 'Mikveh IsraelOtzma SchoolPelec', 'Sports Academy', 5539, 882, '32nd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000018, 'Maale SchoolOtzma SchoolPelech', 'Preschool', 462, 72, '24 Gallant Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000019, 'Hadarim SchoolOtzma SchoolPele', 'After-School Program', 1392, 932, '75 Ruiz Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000020, 'Neot ShakedOtzma SchoolPelech ', 'Military School', 8657, 799, '52 Scott Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000021, 'Darca OfekOtzma SchoolPelech S', 'Nursery School', 5563, 730, '91 Harrison');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000022, 'Amit ShakedOtzma SchoolPelech ', 'Continuing Education Program', 851, 577, '48 Foster Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000023, 'Amit Siach SodOtzma SchoolPele', 'High School', 1479, 424, '73 Mickey Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000024, 'Harel High SchoolOtzma SchoolP', 'College', 9643, 626, '81 Sheen Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000025, 'Amit ModiinOtzma SchoolPelech ', 'Community College', 4248, 644, '343 Diane Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000026, 'Orot YehuditOtzma SchoolPelech', 'Montessori School', 1962, 826, '477 Chuck Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000027, 'Amit Bar IlanOtzma SchoolPelec', 'Art School', 1771, 319, '48 Walsh Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000028, 'Elitzur SchoolOtzma SchoolPele', 'Religious School', 3272, 348, '465 Gaynor Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000029, 'Bnei Akiva Givat ShmuelOtzma S', 'Law School', 6505, 801, '47 Sandoval Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000030, 'Amit Junior HighOtzma SchoolPe', 'Private School', 2207, 902, '20 Darius Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000031, 'Hadassim SchoolOtzma SchoolPel', 'STEM School', 6602, 336, '100 Hatchet Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000032, 'Negev SchoolOtzma SchoolPelech', 'Language School', 1259, 911, '96 Nathan Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000033, 'Bnot Rachel SchoolOtzma School', 'Technical School', 727, 83, '7 Debi Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000034, 'Bialik SchoolOtzma SchoolPelec', 'College', 790, 729, '95 Larry Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000035, 'Bnei Akiva DarcaOtzma SchoolPe', 'Outdoor Education School', 1154, 260, '96 Quinones');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000036, 'Amit Girls SchoolOtzma SchoolP', 'Summer School', 8242, 652, '73 Macht Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000037, 'Nave YeshivaOtzma SchoolPelech', 'Middle School', 1341, 944, '53 Quיbec Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000038, 'Amit ToraniOtzma SchoolPelech ', 'Boarding School', 7597, 201, '47 Carradine Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000039, 'Hatzav SchoolOtzma SchoolPelec', 'Graduate School', 8467, 105, '75 Allan Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000040, 'Mikveh ShalomOtzma SchoolPelec', 'Community College', 2061, 628, '14 Belgrad Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000041, 'Amit Boys SchoolOtzma SchoolPe', 'STEM School', 6505, 947, '8 Famke Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000042, 'Amit ShakedOtzma SchoolPelech ', 'Charter School', 3452, 268, '59 Lucinda Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000043, 'Noam Bnei AkivaOtzma SchoolPel', 'Elementary School', 8256, 749, '315 Washington Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000044, 'Mamlachti SchoolOtzma SchoolPe', 'Vocational School', 4005, 435, '835 Jeter Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000045, 'Amit ToraniOtzma SchoolPelech ', 'Gifted and Talented School', 3918, 34, '72 Milpitas Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000046, 'Morasha SchoolOtzma SchoolPele', 'Elementary School', 8633, 841, '13 Stoltz Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000047, 'Maalot High SchoolOtzma School', 'Engineering School', 7572, 15, '67 Chaka Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000048, 'Amit ModiinOtzma SchoolPelech ', 'Law School', 7555, 97, '60 Sutherland');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000049, 'Negev SchoolOtzma SchoolPelech', 'Middle School', 2169, 436, '54 Cotton Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000050, 'Mor High SchoolOtzma SchoolPel', 'Summer School', 7766, 187, '46 Theron Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000051, 'Amit Bar IlanOtzma SchoolPelec', 'Alternative School', 4215, 676, '41 Shearer Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000052, 'Atid High SchoolOtzma SchoolPe', 'Nursery School', 2554, 855, '52 Renfro Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000053, 'Neot ShakedOtzma SchoolPelech ', 'Business School', 9505, 689, '4 Miko Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000054, 'Otzma SchoolPelech SchoolRamat', 'Outdoor Education School', 2273, 359, '33rd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000055, 'Merhavim SchoolOtzma SchoolPel', 'Outdoor Education School', 9593, 898, '21 Wade Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000056, 'Orot YehuditOtzma SchoolPelech', 'Public School', 4425, 239, '853 Janney Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000057, 'Mor High SchoolOtzma SchoolPel', 'Gifted and Talented School', 7756, 708, '116 Palo Alto Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000058, 'Amit Girls SchoolOtzma SchoolP', 'Business School', 4532, 503, '74 Keith Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000059, 'Mikveh ShalomOtzma SchoolPelec', 'Summer School', 1012, 904, '41 Weaving Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000060, 'Mesivta SchoolOtzma SchoolPele', 'Gifted and Talented School', 1623, 216, '92nd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000061, 'Herzog High SchoolOtzma School', 'Medical School', 1884, 190, '11 Tah Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000062, 'Amirim SchoolOtzma SchoolPelec', 'Law School', 9152, 45, '768 Blige Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000063, 'Mikveh IsraelOtzma SchoolPelec', 'Kindergarten', 4426, 634, '90 Cathy Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000064, 'Mor High SchoolOtzma SchoolPel', 'University', 2109, 295, '738 Taye Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000065, 'Amit ShakedOtzma SchoolPelech ', 'Dance School', 8104, 893, '4 Oakland Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000066, 'Eshkolot SchoolOtzma SchoolPel', 'Outdoor Education School', 4792, 328, '98 Jude Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000067, 'Neot ShakedOtzma SchoolPelech ', 'Military School', 4712, 269, '42 Clark Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000068, 'Mesivta SchoolOtzma SchoolPele', 'Engineering School', 9736, 987, '74 McIntosh Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000069, 'Nave SchoolOtzma SchoolPelech ', 'Outdoor Education School', 2291, 11, '67 Benicio Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000070, 'Elitzur SchoolOtzma SchoolPele', 'Music School', 6463, 674, '111 Zafferana Etnea Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000071, 'Orot HaLevOtzma SchoolPelech S', 'Engineering School', 1842, 4, '643 Tanya Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000072, 'Amit Junior HighOtzma SchoolPe', 'Charter School', 3180, 266, '15 Philadelphia');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000073, 'Ortam SchoolOtzma SchoolPelech', 'College', 3224, 577, '44 Kweller Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000074, 'Amit ToraniOtzma SchoolPelech ', 'Montessori School', 6030, 840, '55 Newton-le-willows Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000075, 'Otzma SchoolPelech SchoolRamat', 'Dance School', 5660, 810, '53 El Paso Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000076, 'Kiryat NoarOtzma SchoolPelech ', 'Engineering School', 7796, 318, '8 Armatrading Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000077, 'Bnei Akiva DarcaOtzma SchoolPe', 'Summer School', 2618, 135, '93 Alpharetta Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000078, 'Hadassim SchoolOtzma SchoolPel', 'Montessori School', 7691, 558, '98 Ledger Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000079, 'Negev SchoolOtzma SchoolPelech', 'Sports Academy', 5129, 80, '32nd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000080, 'Nave SchoolOtzma SchoolPelech ', 'Elementary School', 7460, 109, '36 Gano Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000081, 'Amit Junior HighOtzma SchoolPe', 'Law School', 4084, 137, '3 Marin Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000082, 'Eshkolot SchoolOtzma SchoolPel', 'Nursery School', 6683, 675, '49 Whoopi Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000083, 'Merhavim SchoolOtzma SchoolPel', 'Religious School', 2652, 981, '87 Elle Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000084, 'Maccabim SchoolOtzma SchoolPel', 'Bilingual School', 7024, 511, '52 Jared Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000085, 'Merhavim SchoolOtzma SchoolPel', 'Technical Institute', 509, 410, '93rd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000086, 'Darca MakifOtzma SchoolPelech ', 'Graduate School', 4078, 810, '19 Quיbec Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000087, 'Mesivta SchoolOtzma SchoolPele', 'Dance School', 7437, 310, '84 Popper Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000088, 'Orot YehudaOtzma SchoolPelech ', 'Elementary School', 5161, 820, '21st Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000089, 'Amit Boys SchoolOtzma SchoolPe', 'Summer School', 8199, 943, '53 Irving Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000090, 'Eshkolot SchoolOtzma SchoolPel', 'Montessori School', 9725, 720, '52 Wilson Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000091, 'Horev YeshivaOtzma SchoolPelec', 'Community College', 6237, 378, '62 Vertical Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000092, 'Amit Boys SchoolOtzma SchoolPe', 'Art School', 9631, 304, '62nd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000093, 'Mesivta SchoolOtzma SchoolPele', 'Magnet School', 4357, 942, '96 Conners Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000094, 'Amit SiyonOtzma SchoolPelech S', 'Youth Center', 6920, 140, '89 Barnett Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000095, 'Amit Boys SchoolOtzma SchoolPe', 'Business School', 9347, 371, '48 Charles Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000096, 'Atid High SchoolOtzma SchoolPe', 'Private School', 247, 601, '28 Duvall Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000097, 'Bialik SchoolOtzma SchoolPelec', 'Nursery School', 3413, 412, '62nd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000098, 'Noam ToraniOtzma SchoolPelech ', 'Elementary School', 5108, 911, '527 Brad Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000099, 'Hatzav SchoolOtzma SchoolPelec', 'Law School', 5115, 793, '91 McDonald Drive');
commit;
prompt 100 records committed...
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000100, 'Atid High SchoolOtzma SchoolPe', 'Outdoor Education School', 8554, 368, '89 Staten Island Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000101, 'Maalot High SchoolOtzma School', 'Public School', 3136, 428, '92 Michaels Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000102, 'Etzion SchoolOtzma SchoolPelec', 'Homeschooling Program', 4778, 550, '78 Marin Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000103, 'Amit Junior HighOtzma SchoolPe', 'Community College', 5744, 728, '50 Close Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000104, 'Nesher SchoolOtzma SchoolPelec', 'Public School', 6646, 224, '63 King Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000105, 'Amit Kfar BatyaOtzma SchoolPel', 'Nursery School', 6666, 228, '54 Alessandro Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000106, 'Magen SchoolOtzma SchoolPelech', 'Homeschooling Program', 5790, 688, '28 Glen Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000107, 'Nave SchoolOtzma SchoolPelech ', 'Law School', 6011, 389, '68 Nanci Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000108, 'Bnei Akiva YeshivaOtzma School', 'Bilingual School', 909, 710, '82 Atlas Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000109, 'Lev HaTorahOtzma SchoolPelech ', 'Kindergarten', 5045, 537, '209 Claire Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000110, 'Barkai SchoolOtzma SchoolPelec', 'College', 4832, 556, '8 Foxx Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000111, 'Bnei Akiva OrotOtzma SchoolPel', 'Kindergarten', 6593, 954, '81 Barbara Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000112, 'Or Avner SchoolOtzma SchoolPel', 'Magnet School', 3469, 769, '91st Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000113, 'Amit Boys SchoolOtzma SchoolPe', 'Dance School', 1741, 597, '64 Paraju Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000114, 'Otzma SchoolPelech SchoolRamat', 'Outdoor Education School', 4271, 865, '11 Susan Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000115, 'Orot YehuditOtzma SchoolPelech', 'Elementary School', 5359, 119, '63 Ice Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000116, 'Bnei Akiva OrotOtzma SchoolPel', 'Private School', 5607, 757, '11 Cozier Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000117, 'Maale HabsorOtzma SchoolPelech', 'Science Academy', 7760, 601, '21st Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000118, 'Nesher SchoolOtzma SchoolPelec', 'Medical School', 677, 426, '50 Wiest Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000119, 'Otzma SchoolPelech SchoolRamat', 'Special Education School', 7389, 362, '826 Hershey Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000120, 'Elitzur SchoolOtzma SchoolPele', 'Private School', 7087, 226, '40 Ford Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000121, 'Nave SchoolOtzma SchoolPelech ', 'Middle School', 8480, 459, '56 Diesel Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000122, 'Or Torah SchoolOtzma SchoolPel', 'Vocational School', 5230, 186, '20 Gettysburg Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000123, 'Magen SchoolOtzma SchoolPelech', 'Homeschooling Program', 3249, 441, '32nd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000124, 'Hadassim SchoolOtzma SchoolPel', 'University', 5056, 69, '56 Posener Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000125, 'Eshkolot SchoolOtzma SchoolPel', 'Private School', 6463, 345, '925 Palmer Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000126, 'Otzma SchoolPelech SchoolRamat', 'Nursery School', 7868, 362, '28 Walnut Creek Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000127, 'Darca ShomronOtzma SchoolPelec', 'STEM School', 621, 678, '84 Bautzen Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000128, 'Etzion SchoolOtzma SchoolPelec', 'Technical School', 6080, 953, '67 Grapevine Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000129, 'Maale GilboaOtzma SchoolPelech', 'After-School Program', 4972, 727, '370 Hunter Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000130, 'Nesher SchoolOtzma SchoolPelec', 'After-School Program', 3755, 276, '84 Orleans Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000131, 'Otzma SchoolPelech SchoolRamat', 'Special Education School', 9859, 477, '24 Winona Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000132, 'Nativ SchoolOtzma SchoolPelech', 'Nursery School', 3251, 604, '14 Alice Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000133, 'Ben Gurion SchoolOtzma SchoolP', 'Charter School', 3199, 323, '20 Payne Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000134, 'Dorot SchoolOtzma SchoolPelech', 'Montessori School', 8776, 629, '42nd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000135, 'Amit Boys SchoolOtzma SchoolPe', 'Montessori School', 4777, 2, '41 Corey Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000136, 'Darca OfekOtzma SchoolPelech S', 'Dance School', 1412, 18, '96 Fariq Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000137, 'Maalot High SchoolOtzma School', 'Vocational School', 736, 871, '10 Winger Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000138, 'Chorev High SchoolOtzma School', 'Continuing Education Program', 5181, 160, '100 Cash Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000139, 'Levona SchoolOtzma SchoolPelec', 'Adult Education Center', 410, 680, '34 Checker');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000140, 'Hadassim SchoolOtzma SchoolPel', 'Science Academy', 4204, 455, '17 Trenton Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000141, 'Horev YeshivaOtzma SchoolPelec', 'Language School', 534, 725, '78 Elche Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000142, 'Horev YeshivaOtzma SchoolPelec', 'Engineering School', 5101, 91, '37 Exeter Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000143, 'Amit RenanimOtzma SchoolPelech', 'STEM School', 2116, 504, '967 Casselberry Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000144, 'Darca MakifOtzma SchoolPelech ', 'Online School', 4144, 721, '54 Ojeda Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000145, 'Amit SiyonOtzma SchoolPelech S', 'Military School', 1823, 931, '8 El-Saher Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000146, 'Otzma SchoolPelech SchoolRamat', 'Bilingual School', 685, 970, '238 De Almeida Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000147, 'Chorev High SchoolOtzma School', 'University', 695, 271, '2 Slidel Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000148, 'Maale SchoolOtzma SchoolPelech', 'Medical School', 1372, 277, '60 MacLachlan Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000149, 'Mikveh ShalomOtzma SchoolPelec', 'Kindergarten', 2561, 160, '95 Yankovic Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000150, 'Horev YeshivaOtzma SchoolPelec', 'Parochial School', 1579, 861, '41 Holliday Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000151, 'Amit ModiinOtzma SchoolPelech ', 'Night School', 3472, 869, '118 Glen Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000152, 'Mesivta SchoolOtzma SchoolPele', 'Alternative School', 1530, 343, '35 Berry Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000153, 'Amit Kfar BatyaOtzma SchoolPel', 'Boarding School', 8640, 312, '17 Jeremy Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000154, 'Etzion SchoolOtzma SchoolPelec', 'International School', 3589, 565, '62 Freiburg Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000155, 'Amit RenanimOtzma SchoolPelech', 'Vocational School', 6921, 166, '281 Jill Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000156, 'Ortam SchoolOtzma SchoolPelech', 'University', 9386, 220, '45 Sayer Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000157, 'Amit SiyonOtzma SchoolPelech S', 'Boarding School', 1781, 693, '23rd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000158, 'Nesher SchoolOtzma SchoolPelec', 'Vocational School', 7207, 2, '1 Tomlin Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000159, 'Mamlachti SchoolOtzma SchoolPe', 'Parochial School', 1561, 416, '93 Maceio Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000160, 'Ben Gurion SchoolOtzma SchoolP', 'Graduate School', 3201, 497, '91st Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000161, 'Barkai SchoolOtzma SchoolPelec', 'Public School', 3262, 144, '5 Lavigne Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000162, 'Neot ShakedOtzma SchoolPelech ', 'Outdoor Education School', 4525, 368, '732 Joaquim Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000163, 'Mamlachti SchoolOtzma SchoolPe', 'Religious School', 3595, 967, '7 Antonio Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000164, 'Elitzur SchoolOtzma SchoolPele', 'Adult Education Center', 6144, 749, '65 O''Neal Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000165, 'Himmelfarb SchoolOtzma SchoolP', 'Early Childhood Education Cent', 4206, 435, '50 Judy Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000166, 'Lev HaTorahOtzma SchoolPelech ', 'International School', 5746, 905, '52 Vance Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000167, 'Amit Boys SchoolOtzma SchoolPe', 'Nursery School', 7556, 12, '7 Robin Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000168, 'Orot YehudaOtzma SchoolPelech ', 'Business School', 7264, 818, '79 Collins Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000169, 'Neot ShakedOtzma SchoolPelech ', 'Magnet School', 8494, 596, '21 Pepper');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000170, 'Hatzav SchoolOtzma SchoolPelec', 'Business School', 122, 935, '60 Birch Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000171, 'Mesivta SchoolOtzma SchoolPele', 'Youth Center', 4307, 564, '68 France Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000172, 'Lev HaTorahOtzma SchoolPelech ', 'Gifted and Talented School', 3137, 907, '22 Sammy Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000173, 'Ortam SchoolOtzma SchoolPelech', 'International School', 1412, 967, '65 Elliott Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000174, 'Herzog High SchoolOtzma School', 'Community College', 3751, 861, '88 Lovitz');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000175, 'Harel High SchoolOtzma SchoolP', 'International School', 3529, 675, '88 Visnjic Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000176, 'Dekel SchoolOtzma SchoolPelech', 'Law School', 9788, 227, '405 McPherson Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000177, 'Amit SiyonOtzma SchoolPelech S', 'Night School', 1872, 122, '74 Shirley Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000178, 'Amit Bar IlanOtzma SchoolPelec', 'College', 4202, 939, '41 Dartmouth Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000179, 'Chorev High SchoolOtzma School', 'Bilingual School', 4934, 793, '999 Bkk Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000180, 'Otzma SchoolPelech SchoolRamat', 'Religious School', 5758, 381, '93 Hayward Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000181, 'Amit Siach SodOtzma SchoolPele', 'University', 9747, 27, '573 Wehrheim Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000182, 'Amit Girls SchoolOtzma SchoolP', 'Charter School', 8419, 682, '24 Meyer Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000183, 'Magen SchoolOtzma SchoolPelech', 'Online School', 1202, 613, '59 Berkley Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000184, 'Nesher SchoolOtzma SchoolPelec', 'Graduate School', 7464, 231, '31 Bolzano Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000185, 'Amit Boys SchoolOtzma SchoolPe', 'STEM School', 9195, 208, '42 Vai Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000186, 'Or Chaim SchoolOtzma SchoolPel', 'Early Childhood Education Cent', 148, 512, '26 Olga Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000187, 'Hadarim SchoolOtzma SchoolPele', 'Technical School', 1265, 462, '11st Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000188, 'Nativ SchoolOtzma SchoolPelech', 'Religious School', 2026, 355, '45 Budapest Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000189, 'Chorev High SchoolOtzma School', 'Medical School', 1347, 948, '97 Macau Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000190, 'Amit SiyonOtzma SchoolPelech S', 'International School', 1428, 358, '66 Nivola Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000191, 'Mikveh IsraelOtzma SchoolPelec', 'Online School', 5431, 308, '146 Arkenstone Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000192, 'Lev HaTorahOtzma SchoolPelech ', 'University', 9897, 454, '30 Rascal Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000193, 'Bialik SchoolOtzma SchoolPelec', 'Montessori School', 9997, 131, '80 Altamonte Springs Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000194, 'Lev HaTorahOtzma SchoolPelech ', 'Business School', 9550, 393, '36 Estevez Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000195, 'Orot YehudaOtzma SchoolPelech ', 'Sports Academy', 1163, 294, '21 Buffalo Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000196, 'Nave YeshivaOtzma SchoolPelech', 'Parochial School', 3848, 907, '30 West Drayton');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000197, 'Orot YehudaOtzma SchoolPelech ', 'Nursery School', 3890, 359, '57 Chur');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000198, 'Nave SchoolOtzma SchoolPelech ', 'Outdoor Education School', 7184, 494, '60 Michelle Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000199, 'Amit ShacharOtzma SchoolPelech', 'Outdoor Education School', 7694, 333, '44 Nara Road');
commit;
prompt 200 records committed...
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000200, 'Elitzur SchoolOtzma SchoolPele', 'Night School', 2451, 37, '10 Benjamin Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000201, 'Levona SchoolOtzma SchoolPelec', 'Middle School', 6920, 924, '12nd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000202, 'Maale GilboaOtzma SchoolPelech', 'Montessori School', 9456, 198, '86 Trieste Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000203, 'Lev HaTorahOtzma SchoolPelech ', 'Technical School', 2720, 888, '87 Hookah Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000204, 'Amit Junior HighOtzma SchoolPe', 'Religious School', 9262, 371, '80 Franks Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000205, 'Amit Junior HighOtzma SchoolPe', 'Continuing Education Program', 7566, 901, '63 Paquin Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000206, 'Etzion SchoolOtzma SchoolPelec', 'Special Education School', 6055, 834, '52 Chambers Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000207, 'Harel High SchoolOtzma SchoolP', 'Sports Academy', 3950, 247, '2 Tualatin');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000208, 'Noam ToraniOtzma SchoolPelech ', 'High School', 3530, 626, '43rd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000209, 'Bnei Akiva Givat ShmuelOtzma S', 'Graduate School', 4029, 305, '6 MacIsaac Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000210, 'Maccabim SchoolOtzma SchoolPel', 'Online School', 7900, 631, '359 O''Connor Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000211, 'Merhavim SchoolOtzma SchoolPel', 'Business School', 5307, 857, '86 Roth Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000212, 'Maale GilboaOtzma SchoolPelech', 'Preschool', 3324, 325, '91 George Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000213, 'Levona SchoolOtzma SchoolPelec', 'Boarding School', 1967, 136, '936 Gordie Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000214, 'Bnei Akiva AmanaOtzma SchoolPe', 'Business School', 3201, 841, '42 Robby Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000215, 'Mesivta SchoolOtzma SchoolPele', 'Homeschooling Program', 7816, 173, '82 Vienna Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000216, 'Or Avner SchoolOtzma SchoolPel', 'After-School Program', 6306, 693, '94 Treat');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000217, 'Orot YehudaOtzma SchoolPelech ', 'Technical Institute', 6874, 689, '15 Bryan Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000218, 'Otzma SchoolPelech SchoolRamat', 'After-School Program', 305, 728, '60 Green Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000219, 'Carmel SchoolOtzma SchoolPelec', 'Early Childhood Education Cent', 5750, 227, '795 Ferrell Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000220, 'Ortam SchoolOtzma SchoolPelech', 'Gifted and Talented School', 9397, 670, '77 Lonnie Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000221, 'Keshet SchoolOtzma SchoolPelec', 'High School', 2310, 422, '71 Boorem Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000222, 'Orot HaLevOtzma SchoolPelech S', 'Outdoor Education School', 6599, 392, '1 Law Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000223, 'Amit Siach SodOtzma SchoolPele', 'Community College', 8764, 260, '10 Cale Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000224, 'Amit Bar IlanOtzma SchoolPelec', 'Sports Academy', 2510, 304, '64 Blackwell Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000225, 'Otzma SchoolPelech SchoolRamat', 'Summer School', 8610, 173, '22 Holy');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000226, 'Chorev High SchoolOtzma School', 'Art School', 281, 35, '39 Nikka Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000227, 'Elitzur SchoolOtzma SchoolPele', 'Parochial School', 2853, 260, '83 Roundtree Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000228, 'Atid High SchoolOtzma SchoolPe', 'Private School', 8223, 687, '41 Gil Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000229, 'Hadarim SchoolOtzma SchoolPele', 'Gifted and Talented School', 3803, 604, '54 Madonna Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000230, 'Noam ToraniOtzma SchoolPelech ', 'Public School', 6502, 566, '73 Mos');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000231, 'Bnot Rachel SchoolOtzma School', 'Graduate School', 6973, 12, '70 Lindsey Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000232, 'Meytar SchoolOtzma SchoolPelec', 'Technical School', 2888, 112, '52 Hauer Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000233, 'Bialik SchoolOtzma SchoolPelec', 'Technical Institute', 729, 814, '890 Rush Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000234, 'Kiryat NoarOtzma SchoolPelech ', 'Engineering School', 5088, 245, '5 Liquid Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000235, 'Amit RenanimOtzma SchoolPelech', 'Art School', 6497, 767, '55 Badalucco Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000236, 'Merhavim SchoolOtzma SchoolPel', 'Continuing Education Program', 376, 397, '462 Gooding Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000237, 'Kiryat NoarOtzma SchoolPelech ', 'Religious School', 2687, 318, '66 Lakewood Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000238, 'Levona SchoolOtzma SchoolPelec', 'Summer School', 1648, 901, '15 Coburn Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000239, 'Keshet SchoolOtzma SchoolPelec', 'Special Education School', 3544, 939, '18 Cruise');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000240, 'Keshet SchoolOtzma SchoolPelec', 'After-School Program', 4950, 253, '26 Costello Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000241, 'Orot YehudaOtzma SchoolPelech ', 'STEM School', 9922, 873, '13 Espoo Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000242, 'Bnei Akiva AmanaOtzma SchoolPe', 'Adult Education Center', 5317, 536, '244 Gordon Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000243, 'Bnei Akiva Givat ShmuelOtzma S', 'University', 2039, 331, '46 Harris');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000244, 'Amit SiyonOtzma SchoolPelech S', 'Middle School', 7352, 608, '14 Nils Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000245, 'Ortam SchoolOtzma SchoolPelech', 'Sports Academy', 4317, 876, '52 Jude Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000246, 'Amit SiyonOtzma SchoolPelech S', 'Bilingual School', 7952, 747, '87 Coyote Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000247, 'Darca MakifOtzma SchoolPelech ', 'Vocational School', 9309, 741, '70 Stony Point Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000248, 'Or Chaim SchoolOtzma SchoolPel', 'Military School', 4788, 403, '563 Reeve Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000249, 'Elitzur SchoolOtzma SchoolPele', 'Language School', 3801, 126, '99 Price Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000250, 'Ortam SchoolOtzma SchoolPelech', 'Montessori School', 6575, 72, '53 Gray Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000251, 'Neot ShakedOtzma SchoolPelech ', 'Middle School', 7251, 927, '57 Ralph Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000252, 'Orot HaLevOtzma SchoolPelech S', 'Boarding School', 3781, 313, '34 George Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000253, 'Herzog High SchoolOtzma School', 'Special Education School', 1655, 932, '3 McCain Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000254, 'Elitzur SchoolOtzma SchoolPele', 'Boarding School', 6759, 809, '40 Bangalore Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000255, 'Nesher SchoolOtzma SchoolPelec', 'International School', 9235, 555, '85 Paris Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000256, 'Meitar SchoolOtzma SchoolPelec', 'After-School Program', 3236, 634, '64 Caviezel Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000257, 'Misgav SchoolOtzma SchoolPelec', 'Online School', 9543, 370, '15 Koeln Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000258, 'Nave YeshivaOtzma SchoolPelech', 'Music School', 8489, 843, '92 Suffern Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000259, 'Keshet SchoolOtzma SchoolPelec', 'Vocational School', 3082, 450, '18 Schneider Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000260, 'Kiryat NoarOtzma SchoolPelech ', 'Elementary School', 6718, 366, '9 Bedfordshire');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000261, 'Amit SiyonOtzma SchoolPelech S', 'College', 2044, 932, '88 Jack');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000262, 'Hadarim SchoolOtzma SchoolPele', 'University', 4411, 328, '40 Trini Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000263, 'Gimnasia SchoolOtzma SchoolPel', 'International School', 2963, 458, '868 Marsden Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000264, 'Kiryat NoarOtzma SchoolPelech ', 'Bilingual School', 9455, 336, '70 Ryder Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000265, 'Mor High SchoolOtzma SchoolPel', 'Magnet School', 2072, 334, '83 Cobbs Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000266, 'Orot YehudaOtzma SchoolPelech ', 'Military School', 2582, 449, '82 Rush Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000267, 'Dorot SchoolOtzma SchoolPelech', 'International School', 8346, 230, '618 Kloten Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000268, 'Bnei Akiva YeshivaOtzma School', 'After-School Program', 3543, 467, '35 Birch Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000269, 'Otzma SchoolPelech SchoolRamat', 'STEM School', 4242, 79, '87 Lapointe Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000270, 'Amit Girls SchoolOtzma SchoolP', 'Technical School', 4661, 990, '19 Mechanicsburg Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000271, 'Netanya SchoolOtzma SchoolPele', 'Technical School', 8928, 812, '10 San Jose Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000272, 'Levona SchoolOtzma SchoolPelec', 'Alternative School', 7029, 791, '27 Chuck Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000273, 'Or Torah SchoolOtzma SchoolPel', 'Elementary School', 722, 269, '64 Woodward');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000274, 'Harel High SchoolOtzma SchoolP', 'Technical School', 7976, 334, '100 Richardson Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000275, 'Neot ShakedOtzma SchoolPelech ', 'Homeschooling Program', 8479, 69, '42 Percy Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000276, 'Netanya SchoolOtzma SchoolPele', 'Homeschooling Program', 9160, 651, '833 Dorval Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000277, 'Keshet SchoolOtzma SchoolPelec', 'Business School', 1424, 48, '86 Carlos Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000278, 'Magen SchoolOtzma SchoolPelech', 'Preschool', 6083, 362, '9 Bacharach Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000279, 'Amit ShakedOtzma SchoolPelech ', 'Gifted and Talented School', 650, 803, '30 Idol Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000280, 'Maccabim SchoolOtzma SchoolPel', 'Summer School', 2843, 30, '100 Dooley Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000281, 'Orot HaLevOtzma SchoolPelech S', 'Language School', 3812, 904, '85 Cochran Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000282, 'Chorev High SchoolOtzma School', 'Kindergarten', 8312, 639, '89 Rickie Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000283, 'Mamlachti SchoolOtzma SchoolPe', 'Graduate School', 5635, 433, '11 Pepper Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000284, 'Mamlachti SchoolOtzma SchoolPe', 'Early Childhood Education Cent', 7517, 882, '30 Paula Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000285, 'Nave SchoolOtzma SchoolPelech ', 'Military School', 1429, 848, '39 Palin Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000286, 'Hadarim SchoolOtzma SchoolPele', 'Summer School', 7159, 154, '92nd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000287, 'Mikveh IsraelOtzma SchoolPelec', 'Law School', 5490, 443, '73 Fort Lewis');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000288, 'Otzma SchoolPelech SchoolRamat', 'Early Childhood Education Cent', 2294, 874, '342 Northbrook Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000289, 'Gimnasia SchoolOtzma SchoolPel', 'Community College', 2568, 298, '21 Apple Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000290, 'Mesivta SchoolOtzma SchoolPele', 'Outdoor Education School', 3368, 416, '73rd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000291, 'Meitar SchoolOtzma SchoolPelec', 'Bilingual School', 5332, 917, '82 Popper Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000292, 'Amit Shavei EfrayimOtzma Schoo', 'Sports Academy', 4523, 786, '41 Gainesville');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000293, 'Mesivta SchoolOtzma SchoolPele', 'Gifted and Talented School', 7898, 984, '49 Madeleine');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000294, 'Hatzav SchoolOtzma SchoolPelec', 'Elementary School', 1077, 855, '44 Katt Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000295, 'Chorev High SchoolOtzma School', 'Community College', 845, 18, '99 Wopat Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000296, 'Bnei Akiva YeshivaOtzma School', 'Science Academy', 2461, 7, '36 Baranski Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000297, 'Amit Junior HighOtzma SchoolPe', 'Boarding School', 5037, 9, '989 Adina Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000298, 'Amit SiyonOtzma SchoolPelech S', 'Music School', 9218, 244, '48 Benjamin Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000299, 'Morasha SchoolOtzma SchoolPele', 'Online School', 4212, 317, '52 Reed Ave');
commit;
prompt 300 records committed...
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000300, 'Barkai SchoolOtzma SchoolPelec', 'Nursery School', 7011, 488, '380 Koblenz');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000301, 'Orot YehuditOtzma SchoolPelech', 'Elementary School', 3317, 296, '64 Patrick');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000302, 'Nave YeshivaOtzma SchoolPelech', 'Technical Institute', 1148, 593, '87 Olympia Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000303, 'Bnei Akiva Givat ShmuelOtzma S', 'Engineering School', 6447, 874, '95 Cumming Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000304, 'Neot ShakedOtzma SchoolPelech ', 'Summer School', 583, 803, '78 Bedford Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000305, 'Bnei Akiva AmanaOtzma SchoolPe', 'Business School', 1255, 313, '55 Roth Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000306, 'Otzma SchoolPelech SchoolRamat', 'Gifted and Talented School', 4959, 43, '976 Ernest Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000307, 'Amit ShakedOtzma SchoolPelech ', 'Business School', 7842, 106, '83 Abraham Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000308, 'Amit ShacharOtzma SchoolPelech', 'College', 3047, 486, '609 Juliana Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000309, 'Orot YehudaOtzma SchoolPelech ', 'After-School Program', 222, 377, '80 Lucien Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000310, 'Dorot SchoolOtzma SchoolPelech', 'Military School', 6008, 979, '33 Quaid Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000311, 'Bnei Akiva DarcaOtzma SchoolPe', 'Youth Center', 9853, 319, '63rd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000312, 'Amit Siach SodOtzma SchoolPele', 'Technical Institute', 295, 595, '32 Rodney Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000313, 'Mikveh IsraelOtzma SchoolPelec', 'Medical School', 7701, 761, '89 Corona Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000314, 'Carmel SchoolOtzma SchoolPelec', 'Montessori School', 3962, 757, '11 Williamstown Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000315, 'Mikveh ShalomOtzma SchoolPelec', 'Vocational School', 6864, 302, '93 Tippe Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000316, 'Noam Bnei AkivaOtzma SchoolPel', 'Community College', 2533, 126, '72 Mirren Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000317, 'Kiryat NoarOtzma SchoolPelech ', 'Online School', 508, 734, '15 Goodall');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000318, 'Mamlachti SchoolOtzma SchoolPe', 'Language School', 3998, 965, '39 Gwyneth Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000319, 'Maale HabsorOtzma SchoolPelech', 'Boarding School', 2979, 810, '517 McCormack Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000320, 'Horev YeshivaOtzma SchoolPelec', 'Early Childhood Education Cent', 5449, 852, '35 Robby Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000321, 'Otzma SchoolPelech SchoolRamat', 'Youth Center', 3814, 454, '23rd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000322, 'Dekel SchoolOtzma SchoolPelech', 'Sports Academy', 378, 657, '84 Derwood Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000323, 'Bnei Akiva DarcaOtzma SchoolPe', 'Nursery School', 2240, 614, '32 Lublin Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000324, 'Otzma SchoolPelech SchoolRamat', 'Summer School', 401, 895, '301 Pigott-Smith Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000325, 'Otzma SchoolPelech SchoolRamat', 'Sports Academy', 1667, 787, '15 Cornell Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000326, 'Carmel SchoolOtzma SchoolPelec', 'Boarding School', 7309, 955, '73rd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000327, 'Dorot SchoolOtzma SchoolPelech', 'Graduate School', 9326, 127, '92nd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000328, 'Amit Boys SchoolOtzma SchoolPe', 'Montessori School', 1151, 911, '248 Stevenson Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000329, 'Amit Junior HighOtzma SchoolPe', 'Technical Institute', 6613, 967, '22 Unionville Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000330, 'Amit ToraniOtzma SchoolPelech ', 'Youth Center', 1999, 601, '6 Collective Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000331, 'Bnot Rachel SchoolOtzma School', 'Religious School', 2522, 6, '11st Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000332, 'Amit ShakedOtzma SchoolPelech ', 'Boarding School', 9075, 819, '90 Davy');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000333, 'Maccabim SchoolOtzma SchoolPel', 'International School', 1416, 871, '59 Ian Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000334, 'Darca MakifOtzma SchoolPelech ', 'Business School', 1023, 969, '641 Taryn Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000335, 'Amit ModiinOtzma SchoolPelech ', 'Military School', 8608, 677, '72 Galecki Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000336, 'Himmelfarb SchoolOtzma SchoolP', 'Outdoor Education School', 6766, 686, '28 Denny Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000337, 'Otzma SchoolPelech SchoolRamat', 'Homeschooling Program', 1727, 782, '831 Gordon Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000338, 'Amit SiyonOtzma SchoolPelech S', 'Middle School', 1023, 861, '83 Rhea Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000339, 'Netanya SchoolOtzma SchoolPele', 'Medical School', 9603, 331, '83 Howie Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000340, 'Merhavim SchoolOtzma SchoolPel', 'Bilingual School', 3616, 224, '82 Rauhofer Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000341, 'Amit Shavei EfrayimOtzma Schoo', 'Technical School', 1800, 864, '69 Kurtwood Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000342, 'Netanya SchoolOtzma SchoolPele', 'Technical School', 66, 309, '94 Maxine Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000343, 'Mesivta SchoolOtzma SchoolPele', 'Preschool', 1079, 901, '37 Leverkusen Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000344, 'Chorev High SchoolOtzma School', 'Online School', 2416, 787, '79 Rippy Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000345, 'Bialik SchoolOtzma SchoolPelec', 'Art School', 5410, 9, '49 Breslin Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000346, 'Amit RenanimOtzma SchoolPelech', 'Nursery School', 5930, 581, '24 Rio Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000347, 'Darca ShomronOtzma SchoolPelec', 'Graduate School', 1346, 847, '635 Buffalo Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000348, 'Mikveh ShalomOtzma SchoolPelec', 'Public School', 6897, 801, '21st Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000349, 'Meytar SchoolOtzma SchoolPelec', 'Community College', 6869, 661, '6 Toshiro Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000350, 'Darca ShomronOtzma SchoolPelec', 'Nursery School', 1580, 850, '5 Neeson Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000351, 'Nativ SchoolOtzma SchoolPelech', 'Technical Institute', 2762, 106, '53rd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000352, 'Amit RenanimOtzma SchoolPelech', 'Private School', 1057, 896, '24 Brickell Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000353, 'Meitar SchoolOtzma SchoolPelec', 'Homeschooling Program', 5073, 542, '13 Raybon Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000354, 'Atid High SchoolOtzma SchoolPe', 'International School', 5118, 134, '42nd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000355, 'Barkai SchoolOtzma SchoolPelec', 'Vocational School', 8192, 707, '20 Nynהshamn Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000356, 'Ben Gurion SchoolOtzma SchoolP', 'Art School', 9354, 460, '70 Beck Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000357, 'Orot YehuditOtzma SchoolPelech', 'Military School', 231, 178, '85 Waite Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000358, 'Amit Junior HighOtzma SchoolPe', 'Technical School', 9145, 376, '80 Jerusalem Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000359, 'Amit Kfar BatyaOtzma SchoolPel', 'Vocational School', 931, 70, '82 Arkenstone Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000360, 'Noam ToraniOtzma SchoolPelech ', 'Summer School', 4066, 76, '87 Osmond');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000361, 'Netanya SchoolOtzma SchoolPele', 'Technical School', 4142, 504, '41 Oshkosh Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000362, 'Amit Girls SchoolOtzma SchoolP', 'Music School', 4630, 814, '84 Van Damme Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000363, 'Maale SchoolOtzma SchoolPelech', 'Parochial School', 2686, 241, '354 Eileen Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000364, 'Maale SchoolOtzma SchoolPelech', 'Law School', 466, 936, '606 Rickman Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000365, 'Atid High SchoolOtzma SchoolPe', 'Summer School', 2012, 952, '77 Sheryl Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000366, 'Amit Girls SchoolOtzma SchoolP', 'Kindergarten', 4391, 330, '48 Tracy Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000367, 'Otzma SchoolPelech SchoolRamat', 'Bilingual School', 8266, 20, '32 Fiennes Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000368, 'Chorev High SchoolOtzma School', 'Online School', 1987, 42, '70 Jessica Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000369, 'Dekel SchoolOtzma SchoolPelech', 'Vocational School', 9617, 756, '70 Fisher');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000370, 'Noam Bnei AkivaOtzma SchoolPel', 'Parochial School', 15, 791, '47 Richie Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000371, 'Amit RenanimOtzma SchoolPelech', 'Music School', 7834, 546, '48 Feliciano');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000372, 'Maalot High SchoolOtzma School', 'International School', 9314, 793, '55 Ebersberg Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000373, 'Amit Boys SchoolOtzma SchoolPe', 'Summer School', 9600, 750, '93rd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000374, 'Amit ShacharOtzma SchoolPelech', 'Boarding School', 8580, 733, '365 Yulin Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000375, 'Nativ SchoolOtzma SchoolPelech', 'Community College', 4593, 928, '53rd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000376, 'Barkai SchoolOtzma SchoolPelec', 'Business School', 2723, 466, '66 Harrison Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000377, 'Nesher SchoolOtzma SchoolPelec', 'Boarding School', 2939, 614, '42nd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000378, 'Or Avner SchoolOtzma SchoolPel', 'Technical School', 2584, 28, '82 Farmington Hills Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000379, 'Amit ModiinOtzma SchoolPelech ', 'Charter School', 4026, 824, '4 Cromwell');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000380, 'Darca AtidOtzma SchoolPelech S', 'International School', 9137, 106, '71 Millie Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000381, 'Levona SchoolOtzma SchoolPelec', 'Charter School', 7409, 13, '49 Postlethwaite Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000382, 'Keshet SchoolOtzma SchoolPelec', 'Night School', 1479, 484, '859 Kelly Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000383, 'Bnei Akiva DarcaOtzma SchoolPe', 'International School', 4268, 611, '324 Santiago Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000384, 'Misgav SchoolOtzma SchoolPelec', 'Montessori School', 9951, 502, '28 Beatty Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000385, 'Amit Siach SodOtzma SchoolPele', 'Engineering School', 4358, 684, '270 Strong Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000386, 'Lev HaTorahOtzma SchoolPelech ', 'International School', 4281, 724, '38 Den Haag Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000387, 'Negev SchoolOtzma SchoolPelech', 'Parochial School', 2791, 581, '118 Child Blvd');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000388, 'Barkai SchoolOtzma SchoolPelec', 'Youth Center', 9401, 457, '175 Gagnon Ave');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000389, 'Morasha SchoolOtzma SchoolPele', 'Military School', 1755, 969, '41st Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000390, 'Ben Gurion SchoolOtzma SchoolP', 'Elementary School', 8163, 772, '68 MacNeil');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000391, 'Amit SiyonOtzma SchoolPelech S', 'Nursery School', 4862, 334, '13 Larnelle Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000392, 'Herzog High SchoolOtzma School', 'Science Academy', 3486, 300, '80 Maceo Road');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000393, 'Or Avner SchoolOtzma SchoolPel', 'University', 3369, 482, '389 Kim');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000394, 'Orot HaLevOtzma SchoolPelech S', 'Business School', 9920, 17, '72nd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000395, 'Hatzav SchoolOtzma SchoolPelec', 'Engineering School', 5995, 984, '32 Diamond Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000396, 'Merhavim SchoolOtzma SchoolPel', 'Homeschooling Program', 3700, 947, '43rd Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000397, 'Orot HaLevOtzma SchoolPelech S', 'Outdoor Education School', 7993, 999, '50 Liquid Drive');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000398, 'Meitar SchoolOtzma SchoolPelec', 'Special Education School', 7840, 952, '429 Milwaukee Street');
insert into ACADEMIC_INSTITUTION (institutionid, name, kind, numofstudents, numofteachers, address)
values (1000000399, 'Or Chaim SchoolOtzma SchoolPel', 'Youth Center', 3300, 139, '97 Negbaur Ave');
commit;
prompt 400 records loaded
prompt Loading TEACHER...
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32200100, 'Ardine', 'Harpur', 'Chemistry', 49, 'F', 9963730341, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32212213, 'Melicent', 'Morgan', 'Physics', 9, 'F', 3549368393, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32224326, 'Sharyl', 'Goadbie', 'Physics', 21, 'F', 2394873808, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32236439, 'Levon', 'Smelley', 'History', 43, 'M', 4699701142, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32248552, 'Emerson', 'Probyn', 'Biology', 13, 'M', 2018303274, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32260665, 'Lurline', 'Roux', 'History', 16, 'F', 6067872554, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32272778, 'Bari', 'Tidbold', 'Math', 32, 'F', 5662063133, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32284891, 'Randolf', 'Piwell', 'Math', 14, 'M', 5238311772, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32297004, 'Jamie', 'Atkyns', 'Arabic', 43, 'M', 9652109079, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32309117, 'Haleigh', 'Rusbridge', 'History', 21, 'F', 7452243530, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32321230, 'Jeana', 'Jenton', 'English', 35, 'F', 7786471610, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32333343, 'Emlen', 'Reffe', 'History', 48, 'M', 7216161693, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32345456, 'Queenie', 'Couttes', 'English', 52, 'F', 3397257816, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32357569, 'Ewen', 'Smerdon', 'Literature', 43, 'M', 4726741925, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32369682, 'Maggie', 'Peers', 'English', 21, 'F', 1331601117, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32381795, 'Sven', 'Gration', 'History', 59, 'M', 8346003457, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32393908, 'Cal', 'Dugget', 'English', 4, 'M', 2268071073, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32406021, 'Noellyn', 'Caghan', 'Chemistry', 38, 'F', 5373173658, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32418134, 'Mickey', 'Linner', 'Literature', 23, 'M', 3335057951, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32430247, 'Antony', 'Isson', 'English', 35, 'M', 1648334777, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32442360, 'Catherina', 'Donnett', 'Hebrew', 37, 'F', 4356188466, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32454473, 'Carey', 'Ilchenko', 'Math', 38, 'M', 4562752870, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32466586, 'Andrea', 'Biesinger', 'Chemistry', 1, 'M', 1353628128, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32478699, 'Hew', 'Thoumas', 'Biology', 47, 'M', 4371461641, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32490812, 'Horace', 'De Brett', 'Hebrew', 38, 'M', 1034790286, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32502925, 'Grant', 'Lynnett', 'Biology', 17, 'M', 4676096556, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32515038, 'Ashley', 'Wraight', 'Biology', 32, 'M', 6997426796, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32527151, 'Cello', 'Tyzack', 'Computer Science', 13, 'M', 5622632200, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32539264, 'Torr', 'Andrivot', 'Hebrew', 21, 'M', 6143227951, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32551377, 'Dorice', 'Gerrans', 'Hebrew', 18, 'F', 5032934301, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32563490, 'Lebbie', 'Tweedell', 'History', 58, 'F', 2561107726, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32575603, 'Karil', 'Linggood', 'Literature', 57, 'F', 2035093697, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32587716, 'Conchita', 'Goadby', 'Arabic', 43, 'F', 7917182400, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32599829, 'Noam', 'Stickins', 'Chemistry', 8, 'M', 4091634884, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32611942, 'Clint', 'Henlon', 'Math', 6, 'M', 1821979278, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32624055, 'Allyn', 'Fitzsymon', 'Physics', 58, 'M', 4051534984, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32636168, 'Gayleen', 'Huntriss', 'Art', 44, 'F', 2208451299, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32648281, 'Shelly', 'Featherstone', 'Math', 70, 'F', 8643063974, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32660394, 'Bartholomew', 'Quickenden', 'Literature', 21, 'M', 7758957375, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32672507, 'Andonis', 'Grishakov', 'Math', 6, 'M', 3303411028, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32684620, 'Rancell', 'Pinney', 'History', 63, 'M', 7443103825, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32696733, 'Wylma', 'Thomazin', 'Physics', 61, 'F', 3753076365, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32708846, 'Kira', 'Wigan', 'Literature', 38, 'F', 1244972953, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32720959, 'Norine', 'Chadburn', 'Arabic', 48, 'F', 5483646131, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32733072, 'Osbert', 'Macvey', 'Arabic', 45, 'M', 1267874742, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32745185, 'Viole', 'Noonan', 'Physics', 1, 'F', 5133957971, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32757298, 'Dorie', 'Giannassi', 'Hebrew', 34, 'M', 4353758534, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32769411, 'Ruthanne', 'Richfield', 'Art', 40, 'F', 8428499856, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32781524, 'Zacharie', 'Willishire', 'History', 51, 'M', 3286490781, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32793637, 'Milena', 'Spurling', 'Arabic', 59, 'F', 8666266524, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32805750, 'Sadye', 'Gentle', 'English', 39, 'F', 6945740272, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32817863, 'Kaila', 'Racher', 'English', 34, 'F', 1568796911, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32829976, 'Rani', 'Remmers', 'Art', 32, 'F', 4016616254, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32842089, 'Taylor', 'Stelljes', 'English', 40, 'M', 2412551006, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32854202, 'Davon', 'Brierley', 'Biology', 40, 'M', 1983442002, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32866315, 'Jordana', 'Cestard', 'Computer Science', 40, 'F', 1743478073, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32878428, 'Alexis', 'McFayden', 'Arabic', 50, 'M', 9716157215, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32890541, 'Brunhilde', 'Gregore', 'Physics', 63, 'F', 1488163766, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32902654, 'Dale', 'McDaid', 'History', 35, 'F', 5342216090, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32914767, 'Allyce', 'O''Noulane', 'Biology', 48, 'F', 4438818258, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32926880, 'Si', 'Bullard', 'Biology', 11, 'M', 2207293224, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32938993, 'Kirstin', 'Mildenhall', 'Chemistry', 28, 'F', 8833371418, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32951106, 'Guthrie', 'Oakman', 'Literature', 49, 'M', 2667033435, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32963219, 'Natala', 'Joy', 'Chemistry', 36, 'F', 8717833813, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32975332, 'Flynn', 'Ponsford', 'Literature', 45, 'M', 1618671770, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32987445, 'Fay', 'Igounet', 'Chemistry', 16, 'F', 4568331286, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (32999558, 'Camella', 'Coit', 'Literature', 49, 'F', 3301983483, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33011671, 'Tobey', 'Row', 'Literature', 64, 'F', 2962852439, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33023784, 'Xavier', 'Anan', 'English', 27, 'M', 8759323002, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33035897, 'Gizela', 'Yarr', 'English', 26, 'F', 4661233120, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33048010, 'Rebeca', 'Larrosa', 'Biology', 49, 'F', 2711732364, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33060123, 'Anna-diana', 'Beardsell', 'Arabic', 55, 'F', 6575892657, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33072236, 'Bethany', 'Itzkovwitch', 'Arabic', 37, 'F', 2855809935, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33084349, 'Jay', 'Russ', 'English', 29, 'M', 5892069089, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33096462, 'Marcelo', 'Greeson', 'Arabic', 37, 'M', 9638302533, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33108575, 'Roxane', 'Simyson', 'Art', 20, 'F', 9871401410, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33120688, 'Lewes', 'McGing', 'Math', 14, 'M', 8511807596, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33132801, 'Niccolo', 'Hann', 'Hebrew', 65, 'M', 9868570782, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33144914, 'Marilin', 'Hurich', 'Arabic', 67, 'F', 5053245444, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33157027, 'Adams', 'Sea', 'Physics', 11, 'M', 8129045664, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33169140, 'Federico', 'Oki', 'Biology', 41, 'M', 8109592815, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33181253, 'Janot', 'Ussher', 'Art', 69, 'F', 3074634479, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33193366, 'Michale', 'Alcide', 'Literature', 35, 'M', 4541671823, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33205479, 'Jard', 'Glennard', 'English', 30, 'M', 5111667542, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33217592, 'Haroun', 'Cawthry', 'English', 24, 'M', 2702244871, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33229705, 'Olly', 'Kalderon', 'Chemistry', 39, 'M', 9153360120, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33241818, 'Debby', 'Crudge', 'Literature', 68, 'F', 9024229298, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33253931, 'Linoel', 'Jouandet', 'English', 67, 'M', 7703452552, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33266044, 'Wynny', 'Gownge', 'Computer Science', 6, 'F', 4816309465, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33278157, 'Kathye', 'Feasley', 'Computer Science', 11, 'F', 7996157688, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33290270, 'Veronica', 'Antcliffe', 'Math', 19, 'F', 5808600614, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33302383, 'Karlens', 'Cello', 'Biology', 16, 'M', 8011181946, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33314496, 'Friederike', 'Mackilpatrick', 'Arabic', 47, 'F', 1701414407, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33326609, 'Konrad', 'Burcombe', 'Math', 23, 'M', 1141620613, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33338722, 'Stacia', 'Andino', 'Biology', 9, 'F', 4663955175, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33350835, 'Magnum', 'Eastlake', 'Chemistry', 64, 'M', 8411370070, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33362948, 'Laure', 'Pratchett', 'Arabic', 9, 'F', 6091180945, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33375061, 'Gustavus', 'Jays', 'Computer Science', 29, 'M', 6407490006, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33387174, 'Melanie', 'Boggon', 'Art', 47, 'F', 9377386986, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33399287, 'Kennedy', 'Sollars', 'Literature', 36, 'M', 5757160430, 3);
commit;
prompt 100 records committed...
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33411400, 'Berrie', 'Maddison', 'Computer Science', 21, 'F', 4131711547, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33423513, 'Coraline', 'Mosdall', 'Computer Science', 15, 'F', 5362162554, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33435626, 'Stafford', 'McLane', 'Literature', 15, 'M', 6416713053, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33447739, 'Zaneta', 'Redmain', 'Art', 16, 'F', 9112888146, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33459852, 'Hillie', 'Shire', 'English', 16, 'M', 7941450382, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33471965, 'Neils', 'Axleby', 'Chemistry', 42, 'M', 9316253705, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33484078, 'Nessa', 'Albery', 'Hebrew', 4, 'F', 9662302597, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33496191, 'Tremain', 'Edgecombe', 'Biology', 64, 'M', 8271153951, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33508304, 'Bruce', 'Grabbam', 'Art', 10, 'M', 2263210843, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33520417, 'Cicely', 'Pirolini', 'History', 13, 'F', 6095826128, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33532530, 'Glenden', 'Faustin', 'English', 63, 'M', 4188497732, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33544643, 'Kean', 'Hember', 'Computer Science', 20, 'M', 8285034388, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33556756, 'Maisie', 'Furbank', 'Physics', 29, 'F', 7056737082, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33568869, 'Celene', 'Sawers', 'Art', 23, 'F', 2259889858, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33580982, 'Emmy', 'Halcro', 'Physics', 37, 'F', 4147747693, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33593095, 'Alma', 'Hirtz', 'Art', 15, 'F', 9042438297, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33605208, 'Lalo', 'MacTeague', 'History', 58, 'M', 7402133701, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33617321, 'Martyn', 'McGeaney', 'Biology', 69, 'M', 9847001733, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33629434, 'Elisabetta', 'Varrow', 'Arabic', 49, 'F', 4799945890, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33641547, 'Ralina', 'Riggulsford', 'Computer Science', 6, 'F', 1782248933, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33653660, 'Benson', 'Durant', 'Computer Science', 29, 'M', 7077208941, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33665773, 'Cacilia', 'Dainton', 'Arabic', 57, 'F', 3084760949, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33677886, 'Vincenty', 'Pancoast', 'Arabic', 46, 'M', 9552259468, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33689999, 'Tull', 'Flight', 'Math', 32, 'M', 8748068258, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33702112, 'Berte', 'Pitney', 'Literature', 69, 'F', 3796953264, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33714225, 'Ianthe', 'Grima', 'Chemistry', 48, 'F', 1313222518, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33726338, 'Freeland', 'Piele', 'Chemistry', 49, 'M', 2243505474, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33738451, 'Jorgan', 'Mathers', 'History', 69, 'M', 7774035874, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33750564, 'Koren', 'Aynold', 'Literature', 4, 'F', 5123552841, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33762677, 'Doy', 'Hallagan', 'Literature', 29, 'M', 9977223145, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33774790, 'Evania', 'Downie', 'Hebrew', 64, 'F', 6598938691, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33786903, 'Kristin', 'Falconar', 'Hebrew', 19, 'F', 3572722111, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33799016, 'Fee', 'Skep', 'Literature', 60, 'M', 2148380112, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33811129, 'Nobe', 'De la Zenne', 'Arabic', 3, 'M', 6797661221, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33823242, 'Baxie', 'Greenig', 'English', 56, 'M', 6442123458, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33835355, 'Gladi', 'Poynor', 'English', 34, 'F', 8394529848, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33847468, 'Giorgia', 'Wrotham', 'Chemistry', 70, 'F', 6734394434, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33859581, 'Robin', 'Hourigan', 'Arabic', 29, 'F', 9384672013, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33871694, 'Ollie', 'Jursch', 'Chemistry', 59, 'M', 3791827425, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33883807, 'Kaylee', 'Greenham', 'Computer Science', 58, 'F', 2245562575, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33895920, 'Giffer', 'Smaridge', 'History', 17, 'M', 9348788657, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33908033, 'Witty', 'Gratrix', 'Biology', 27, 'M', 4187827897, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33920146, 'Hunt', 'Pressnell', 'Biology', 36, 'M', 9593553941, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33932259, 'Alisander', 'Reddan', 'Computer Science', 42, 'M', 5273187129, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33944372, 'Hasheem', 'Lorans', 'English', 37, 'M', 8025295339, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33956485, 'Juana', 'Challinor', 'Math', 12, 'F', 3379231787, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33968598, 'Jacky', 'Bowles', 'Hebrew', 37, 'F', 4495271886, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33980711, 'Tarrance', 'Proschek', 'Biology', 6, 'M', 6318450042, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (33992824, 'Roscoe', 'MacCart', 'History', 9, 'M', 1649247794, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34004937, 'Margi', 'Beange', 'Biology', 47, 'F', 5319091464, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34017050, 'Lammond', 'Leckenby', 'Physics', 9, 'M', 6241151696, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34029163, 'Paige', 'Pol', 'Hebrew', 65, 'F', 4881079409, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34041276, 'Korry', 'Notley', 'Arabic', 56, 'F', 9555434905, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34053389, 'Mathias', 'Emblow', 'Literature', 35, 'M', 6728909263, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34065502, 'Angelo', 'Glendzer', 'Hebrew', 4, 'M', 1865856753, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34077615, 'Cordey', 'Breeton', 'Math', 63, 'F', 5963848932, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34089728, 'Rey', 'Mulrooney', 'Chemistry', 61, 'M', 3827023938, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34101841, 'Lenci', 'Wigsell', 'English', 51, 'M', 9486677739, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34113954, 'Mariel', 'Briance', 'Chemistry', 36, 'F', 3844155169, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34126067, 'Korie', 'Shellshear', 'History', 46, 'F', 4377644853, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34138180, 'Norrie', 'Fallowes', 'Art', 26, 'F', 5846625908, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34150293, 'Brennan', 'McKea', 'Literature', 28, 'M', 1499483934, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34162406, 'Syman', 'Daborne', 'Art', 63, 'M', 1729497460, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34174519, 'Brana', 'Brinkley', 'History', 14, 'F', 6963405626, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34186632, 'Terra', 'Devonport', 'Arabic', 32, 'F', 9334212058, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34198745, 'Sukey', 'Yuill', 'Biology', 13, 'F', 3035294857, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34210858, 'Emmerich', 'Portal', 'Literature', 53, 'M', 8594679067, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34222971, 'Peta', 'Bazoge', 'English', 62, 'F', 5888127647, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34235084, 'Danit', 'Ivanov', 'Arabic', 42, 'F', 2596826405, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34247197, 'Caprice', 'Stanlock', 'History', 51, 'F', 8394511182, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34259310, 'Gabbey', 'O''Lynn', 'History', 34, 'F', 5107601007, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34271423, 'Elsy', 'Plumbridge', 'Computer Science', 6, 'F', 9861290034, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34283536, 'Rick', 'Rothschild', 'Arabic', 34, 'M', 8056393296, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34295649, 'Correy', 'Masey', 'Math', 25, 'M', 6597608262, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34307762, 'Vassili', 'Cowen', 'Chemistry', 44, 'M', 3469129250, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34319875, 'Cletus', 'Gourlay', 'Physics', 63, 'M', 1227211085, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34331988, 'Gabbey', 'Gipson', 'Chemistry', 23, 'F', 1812990267, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34344101, 'Kenny', 'Robardley', 'Art', 25, 'M', 4092142442, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34356214, 'Edith', 'Imlin', 'History', 26, 'F', 7566164763, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34368327, 'Frazer', 'Warlawe', 'Arabic', 35, 'M', 2949760908, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34380440, 'Lucienne', 'Langcastle', 'Math', 8, 'F', 2244978764, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34392553, 'Laverna', 'Doonican', 'Hebrew', 24, 'F', 4975653345, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34404666, 'Desi', 'Werrilow', 'Arabic', 13, 'M', 7624497162, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34416779, 'Caril', 'Esmonde', 'Arabic', 34, 'F', 5286934461, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34428892, 'Salomo', 'Sprigings', 'Biology', 38, 'M', 7117145967, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34441005, 'Rubi', 'Couvert', 'Chemistry', 47, 'F', 4386996730, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34453118, 'Kelli', 'De la Yglesia', 'Hebrew', 17, 'F', 9107147728, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34465231, 'Ethelyn', 'Glayzer', 'Biology', 62, 'F', 6718996842, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34477344, 'Emmett', 'McLaggan', 'Art', 30, 'M', 7876103942, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34489457, 'Dillie', 'Battyll', 'Biology', 65, 'M', 4107879775, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34501570, 'Thurston', 'Balfre', 'Physics', 3, 'M', 9218762061, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34513683, 'Herculie', 'Gateley', 'Biology', 63, 'M', 3445539620, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34525796, 'Baryram', 'Penas', 'Chemistry', 9, 'M', 7191805415, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34537909, 'Annamaria', 'Gheeorghie', 'Hebrew', 1, 'F', 4842182639, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34550022, 'Bondon', 'Cullnean', 'Literature', 28, 'M', 4826617738, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34562135, 'Holly-anne', 'Tugman', 'Chemistry', 20, 'F', 2155600242, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34574248, 'Clim', 'Pankettman', 'Art', 7, 'M', 8118578785, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34586361, 'Gawen', 'Loosley', 'Math', 65, 'M', 6153857880, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34598474, 'Berton', 'Rottgers', 'Math', 1, 'M', 3772888907, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34610587, 'Tyrus', 'Summerlie', 'English', 61, 'M', 9171190668, 4);
commit;
prompt 200 records committed...
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34622700, 'Moses', 'Koopman', 'Biology', 37, 'M', 6487864524, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34634813, 'Gretal', 'Stainburn', 'Physics', 42, 'F', 6314153282, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34646926, 'Deeyn', 'Mokes', 'Hebrew', 21, 'F', 4701111492, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34659039, 'Dorella', 'Megainey', 'Chemistry', 54, 'F', 7131542848, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34671152, 'Tye', 'Loughrey', 'Hebrew', 55, 'M', 7575394005, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34683265, 'Adi', 'Coger', 'Physics', 28, 'F', 5656424049, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34695378, 'Joela', 'Bowler', 'English', 70, 'F', 6153024666, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34707491, 'Emmanuel', 'Cockrem', 'History', 11, 'M', 3698659558, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34719604, 'Nanni', 'Clash', 'Math', 39, 'F', 5428926657, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34731717, 'Clayton', 'Cannop', 'Hebrew', 43, 'M', 4556368119, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34743830, 'Brendin', 'Mosedill', 'Math', 44, 'M', 5569154092, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34755943, 'Dion', 'Haquin', 'Biology', 11, 'M', 5391571506, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34768056, 'Ranice', 'Rozea', 'Physics', 17, 'F', 4412419431, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34780169, 'Aldous', 'Grogor', 'Literature', 11, 'M', 4026275733, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34792282, 'Kelley', 'Jury', 'Math', 8, 'F', 4788022717, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34804395, 'Craggy', 'Doyland', 'English', 36, 'M', 7573332503, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34816508, 'Korey', 'Waldera', 'English', 2, 'M', 8567926360, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34828621, 'Nonie', 'Sigsworth', 'Math', 5, 'F', 5144752870, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34840734, 'Cord', 'Cattell', 'Chemistry', 59, 'M', 6571606282, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34852847, 'Tatiania', 'Friar', 'Art', 17, 'F', 1132462738, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34864960, 'Juliane', 'Velareal', 'Chemistry', 57, 'F', 7949223606, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34877073, 'Lacee', 'Grier', 'Computer Science', 59, 'F', 7714399361, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34889186, 'Gayle', 'Lytell', 'History', 10, 'F', 4459871585, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34901299, 'Cam', 'Jerwood', 'Chemistry', 58, 'M', 6115415148, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34913412, 'Letti', 'Bowhay', 'History', 47, 'F', 7675657438, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34925525, 'Jeri', 'Grisenthwaite', 'Arabic', 48, 'F', 6973619556, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34937638, 'Lindy', 'Brambell', 'Literature', 41, 'M', 6247249349, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34949751, 'Lissie', 'Mattessen', 'Chemistry', 64, 'F', 3605214123, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34961864, 'Billy', 'Spoure', 'Biology', 31, 'M', 1342336717, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34973977, 'Rosella', 'Mundell', 'Literature', 24, 'F', 2499420365, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34986090, 'Andy', 'Alderwick', 'Physics', 47, 'M', 1901892643, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (34998203, 'Guido', 'Phelipeau', 'History', 37, 'M', 7113721057, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35010316, 'Dud', 'Luckett', 'Hebrew', 37, 'M', 6021801657, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35022429, 'Dot', 'Skyme', 'Literature', 27, 'F', 3962479698, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35034542, 'Maddie', 'Maccrae', 'Math', 50, 'F', 5186481303, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35046655, 'Merrick', 'Pennock', 'Literature', 22, 'M', 5857995881, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35058768, 'Dallas', 'Sarson', 'English', 66, 'F', 1161895131, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35070881, 'Terry', 'Blease', 'Physics', 5, 'F', 3852490864, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35082994, 'Salomi', 'Jerrold', 'Math', 50, 'F', 3055802845, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35095107, 'Lyon', 'Parkyn', 'Biology', 26, 'M', 9841702760, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35107220, 'Rosamund', 'Hebborne', 'Hebrew', 52, 'F', 2613231582, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35119333, 'Dorian', 'Custed', 'Literature', 16, 'M', 8385419836, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35131446, 'Troy', 'Laurisch', 'Art', 37, 'M', 3475654869, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35143559, 'Alida', 'Sprules', 'Chemistry', 62, 'F', 7633933840, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35155672, 'Marsiella', 'Heaford', 'Arabic', 69, 'F', 6493225725, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35167785, 'Aurea', 'Conry', 'Biology', 4, 'F', 5039273955, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35179898, 'Zandra', 'Poulglais', 'Biology', 34, 'F', 9907474285, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35192011, 'Alvin', 'Seppey', 'History', 23, 'M', 3358450274, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35204124, 'Rustin', 'Piola', 'Computer Science', 46, 'M', 7553809232, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35216237, 'Tobye', 'Edelman', 'Chemistry', 27, 'F', 2051368167, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35228350, 'Elmo', 'Dawber', 'Math', 36, 'M', 3954639104, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35240463, 'Mendie', 'Smees', 'History', 10, 'M', 1611135205, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35252576, 'Tamera', 'McLarnon', 'Art', 20, 'F', 3621424586, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35264689, 'Nikolaus', 'Quimby', 'History', 2, 'M', 3767018554, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35276802, 'Lee', 'Fussey', 'Chemistry', 30, 'M', 5839034116, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35288915, 'Doti', 'Alebrooke', 'Biology', 11, 'F', 2199245412, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35301028, 'Finlay', 'Herrieven', 'English', 56, 'M', 5242387690, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35313141, 'Clevey', 'De Roos', 'Literature', 44, 'M', 2996378532, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35325254, 'Willard', 'Nealey', 'Hebrew', 57, 'M', 1854621569, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35337367, 'Halie', 'Leethem', 'English', 62, 'F', 4636550131, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35349480, 'Andros', 'Heyworth', 'Art', 14, 'M', 6744732521, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35361593, 'Dorolisa', 'Chesnut', 'Biology', 33, 'F', 3713091012, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35373706, 'Moss', 'Rouby', 'English', 2, 'M', 3374948845, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35385819, 'Christopher', 'L''Episcopio', 'Math', 15, 'M', 8865278418, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35397932, 'Guillermo', 'Petraitis', 'English', 1, 'M', 3847773317, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35410045, 'Otto', 'Cordero', 'History', 41, 'M', 7208483038, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35422158, 'Duncan', 'Bedo', 'History', 60, 'M', 5167154822, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35434271, 'Maura', 'Ikin', 'Literature', 8, 'F', 6435449075, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35446384, 'Danita', 'Fernan', 'Art', 43, 'F', 3358480320, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35458497, 'Katya', 'Messer', 'Physics', 13, 'F', 7377471106, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35470610, 'Natala', 'Whisby', 'Math', 66, 'F', 5209071782, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35482723, 'Tabatha', 'Tolmie', 'English', 25, 'F', 3064382639, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35494836, 'Alyss', 'Cunniffe', 'Chemistry', 22, 'F', 9981958080, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35506949, 'Flossy', 'Tift', 'Literature', 44, 'F', 2216219321, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35519062, 'Yank', 'Schaumann', 'Physics', 31, 'M', 3908378902, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35531175, 'Alvie', 'Ambroziak', 'Arabic', 63, 'M', 5344074099, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35543288, 'Ned', 'Loffhead', 'Chemistry', 8, 'M', 9027026834, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35555401, 'Dorita', 'Parkhouse', 'History', 40, 'F', 1255013897, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35567514, 'Laura', 'Swatland', 'English', 20, 'F', 4269286085, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35579627, 'Laird', 'Sidey', 'Math', 66, 'M', 3581222850, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35591740, 'Kinny', 'Sansome', 'English', 45, 'M', 6964619952, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35603853, 'Opaline', 'Peskin', 'Arabic', 25, 'F', 8708615286, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35615966, 'Esta', 'Langcastle', 'Computer Science', 18, 'F', 7749432864, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35628079, 'Abbie', 'Gland', 'Computer Science', 25, 'M', 4482107373, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35640192, 'Red', 'Enrich', 'History', 23, 'M', 6764391201, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35652305, 'Loria', 'Lomond', 'Math', 52, 'F', 8945944663, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35664418, 'Sterne', 'Saunder', 'Computer Science', 40, 'M', 3727284444, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35676531, 'Dael', 'Bortolotti', 'English', 18, 'M', 1371342224, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35688644, 'Sofia', 'Milby', 'Art', 55, 'F', 9496932087, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35700757, 'Terrance', 'Wilkison', 'Chemistry', 50, 'M', 6048837338, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35712870, 'Anastassia', 'Goulding', 'Chemistry', 39, 'F', 8632057894, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35724983, 'Alf', 'Bird', 'Art', 1, 'M', 2911544390, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35737096, 'Val', 'Havvock', 'Biology', 39, 'M', 7451099256, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35749209, 'Alisha', 'Pinder', 'Literature', 18, 'F', 5612377586, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35761322, 'Pietra', 'MacCallion', 'English', 39, 'F', 8081327113, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35773435, 'Lothaire', 'Jaulme', 'Hebrew', 52, 'M', 6476581485, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35785548, 'Aloin', 'Pluthero', 'Chemistry', 52, 'M', 3788348231, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35797661, 'Karlik', 'Lamb-shine', 'English', 8, 'M', 1336688428, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35809774, 'Ricky', 'Marsie', 'Chemistry', 60, 'M', 2535229606, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35821887, 'Micheline', 'Gors', 'Art', 24, 'F', 4981796798, 6);
commit;
prompt 300 records committed...
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35834000, 'Merle', 'Blower', 'Chemistry', 69, 'M', 1574890009, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35846113, 'Marita', 'Pawel', 'Physics', 5, 'F', 7553305800, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35858226, 'Bel', 'Aronstein', 'Computer Science', 39, 'F', 7022282496, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35870339, 'Elijah', 'Finnemore', 'Hebrew', 33, 'M', 4647327452, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35882452, 'Robinia', 'Dei', 'English', 68, 'F', 1287183809, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35894565, 'Caesar', 'Stern', 'Computer Science', 18, 'M', 2838550006, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35906678, 'Evonne', 'Leele', 'Computer Science', 50, 'F', 5521972875, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35918791, 'Agathe', 'Hurlin', 'Physics', 3, 'F', 4663720340, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35930904, 'Jori', 'Aers', 'Literature', 39, 'F', 8956385377, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35943017, 'Brennan', 'Suffield', 'History', 54, 'M', 6642278357, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35955130, 'Thorpe', 'Aitken', 'Math', 21, 'M', 8554970128, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35967243, 'Casie', 'Freer', 'Chemistry', 33, 'F', 3051624965, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35979356, 'Zea', 'Getty', 'Biology', 70, 'F', 8399853139, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (35991469, 'Ludovika', 'Ilyukhov', 'Physics', 66, 'F', 5245277978, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36003582, 'Rafferty', 'Newbery', 'Literature', 57, 'M', 8815293419, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36015695, 'Bernete', 'Bodley', 'Hebrew', 16, 'F', 3671566933, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36027808, 'Cthrine', 'Shillum', 'Math', 29, 'F', 8841506486, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36039921, 'Mel', 'Coudray', 'Art', 68, 'M', 3381506989, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36052034, 'Knox', 'Jull', 'Literature', 66, 'M', 3071492870, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36064147, 'Wilfrid', 'Kemsley', 'English', 5, 'M', 8217179574, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36076260, 'Kippar', 'Simko', 'Chemistry', 17, 'M', 4562257086, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36088373, 'Grace', 'Prodrick', 'Computer Science', 38, 'F', 5487189197, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36100486, 'Max', 'Oneile', 'Computer Science', 33, 'M', 5194872366, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36112599, 'Heather', 'Tyndall', 'English', 64, 'F', 9861458142, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36124712, 'Creighton', 'Thirst', 'Math', 21, 'M', 8397600586, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36136825, 'Ainslee', 'Wilbor', 'English', 51, 'F', 6163101348, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36148938, 'Blaine', 'Haggus', 'Physics', 39, 'M', 1579999305, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36161051, 'Paola', 'Dockray', 'Biology', 22, 'F', 4023967071, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36173164, 'Alex', 'Darycott', 'Hebrew', 20, 'M', 9632174500, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36185277, 'Wendell', 'Wyatt', 'Physics', 67, 'M', 1537928017, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36197390, 'Bern', 'Rosenboim', 'Literature', 56, 'M', 8423363857, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36209503, 'L;urette', 'Djurdjevic', 'Hebrew', 19, 'F', 1428751524, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36221616, 'Elka', 'Latter', 'Art', 65, 'F', 4359726686, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36233729, 'Jenn', 'Gavan', 'Literature', 15, 'F', 8188102414, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36245842, 'Eve', 'Richemond', 'Hebrew', 15, 'F', 3808730882, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36257955, 'Charissa', 'Maffi', 'History', 55, 'F', 3556297973, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36270068, 'Rivkah', 'Ivanyutin', 'Art', 45, 'F', 5144134853, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36282181, 'Dud', 'Papierz', 'History', 23, 'M', 4774903401, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36294294, 'Vanya', 'Pulham', 'Hebrew', 1, 'F', 2187244250, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36306407, 'Richard', 'Treneman', 'Math', 62, 'M', 3824628813, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36318520, 'Vernice', 'Cundey', 'English', 49, 'F', 1176345838, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36330633, 'Alexio', 'Wayland', 'Biology', 13, 'M', 4208487544, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36342746, 'Merilyn', 'Hackworth', 'Chemistry', 64, 'F', 9316018693, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36354859, 'Debora', 'Bras', 'History', 9, 'F', 4087760357, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36366972, 'Paige', 'Patridge', 'Math', 30, 'M', 5045834098, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36379085, 'Standford', 'Fradgley', 'Computer Science', 4, 'M', 2273899723, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36391198, 'Belita', 'Whyman', 'Computer Science', 43, 'F', 8013046306, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36403311, 'Gary', 'Corby', 'Chemistry', 57, 'M', 5787911991, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36415424, 'Amber', 'Kayzer', 'Hebrew', 11, 'F', 1535937845, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36427537, 'Storm', 'McAuliffe', 'Math', 52, 'F', 1041824523, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36439650, 'Toby', 'Howle', 'Physics', 59, 'M', 5029590534, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36451763, 'Victoir', 'McBlain', 'Biology', 58, 'M', 6648767591, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36463876, 'Verla', 'Shapira', 'Chemistry', 5, 'F', 1638118562, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36475989, 'Eustacia', 'Outhwaite', 'Math', 31, 'F', 9364938773, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36488102, 'Andreas', 'Blewmen', 'Physics', 14, 'M', 1871157342, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36500215, 'Marcy', 'Mattessen', 'Chemistry', 41, 'F', 4412959011, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36512328, 'Abramo', 'Prandin', 'Literature', 54, 'M', 9042119709, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36524441, 'Roley', 'Vickers', 'Physics', 65, 'M', 4235188054, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36536554, 'Bernette', 'Ranken', 'Math', 26, 'F', 5807597445, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36548667, 'Patsy', 'Scrine', 'English', 63, 'M', 6881164305, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36560780, 'Christoforo', 'Chander', 'Physics', 10, 'M', 6743450262, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36572893, 'Shari', 'Newall', 'Chemistry', 39, 'F', 8893991834, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36585006, 'Morganica', 'Tant', 'Biology', 32, 'F', 4021487882, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36597119, 'Fabian', 'Bolderstone', 'Physics', 2, 'M', 3177426052, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36609232, 'Dorey', 'McIlharga', 'Literature', 47, 'F', 5455541205, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36621345, 'Timotheus', 'Crews', 'History', 67, 'M', 5425038185, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36633458, 'Marlena', 'Nordass', 'Computer Science', 5, 'F', 8753625739, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36645571, 'Clim', 'Blemings', 'Chemistry', 23, 'M', 5725965202, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36657684, 'Ario', 'Bick', 'Biology', 36, 'M', 3474291498, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36669797, 'Bekki', 'Bumby', 'Computer Science', 19, 'F', 2429728611, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36681910, 'Darelle', 'Lucks', 'Chemistry', 8, 'F', 3028130843, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36694023, 'Beverley', 'Tunnicliffe', 'Art', 10, 'F', 5395633039, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36706136, 'Marissa', 'Waymont', 'Art', 54, 'F', 7979450740, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36718249, 'Nap', 'Gadman', 'Physics', 15, 'M', 4143471493, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36730362, 'Mabelle', 'Muzzini', 'Physics', 67, 'F', 2175482271, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36742475, 'Biddie', 'Akred', 'Math', 28, 'F', 4707957818, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36754588, 'Araldo', 'Dysart', 'Art', 58, 'M', 8873832164, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36766701, 'Gianna', 'Georg', 'Math', 64, 'F', 7058507864, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36778814, 'Chucho', 'Briiginshaw', 'History', 21, 'M', 6489865172, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36790927, 'Morlee', 'Stidson', 'Art', 57, 'M', 1892911249, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36803040, 'Lanie', 'Arnoldi', 'Literature', 46, 'F', 1195524560, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36815153, 'Editha', 'Absolon', 'Biology', 58, 'F', 2593944703, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36827266, 'Lucio', 'Hubber', 'Computer Science', 50, 'M', 1479165120, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36839379, 'Tallie', 'Valde', 'Hebrew', 58, 'F', 7375600654, 6);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36851492, 'Sybil', 'Been', 'Biology', 38, 'F', 4985831756, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36863605, 'Winfield', 'Greggersen', 'Hebrew', 48, 'M', 2445861645, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36875718, 'Vic', 'Parcell', 'Math', 68, 'M', 5105955836, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36887831, 'Pablo', 'Medcraft', 'English', 30, 'M', 7722713134, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36899944, 'Ali', 'Devany', 'Literature', 53, 'F', 4484493580, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36912057, 'Camel', 'Stredwick', 'Arabic', 62, 'F', 6053024815, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36924170, 'Royce', 'Willbond', 'Literature', 41, 'M', 7366235128, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36936283, 'Bond', 'Mcimmie', 'Computer Science', 25, 'M', 5675046266, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36948396, 'Nelie', 'Oloshkin', 'English', 60, 'F', 4151565320, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36960509, 'Consalve', 'Peyzer', 'Arabic', 28, 'M', 3886348093, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36972622, 'Raul', 'Keener', 'History', 36, 'M', 2291924209, 2);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36984735, 'Faulkner', 'Georgeou', 'Physics', 62, 'M', 1175290745, 4);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (36996848, 'Idalia', 'Bigglestone', 'Literature', 44, 'F', 1339315778, 3);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (37008961, 'Billye', 'Linzey', 'Art', 54, 'F', 7544333636, 5);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (37021074, 'Anselm', 'Lownds', 'Chemistry', 54, 'M', 9382891830, 1);
insert into TEACHER (id, firstname, lastname, proffassion, seniority, gender, phone, freeday)
values (37033187, 'Marnia', 'Thraves', 'History', 47, 'F', 1855964411, 6);
commit;
prompt 400 records loaded
prompt Loading TRAINING...
insert into TRAINING (trainingid, location, training_date, name)
values (100, 'Crowne Plaza Jerusalem', to_date('02-08-2022', 'dd-mm-yyyy'), 'Literature training');
insert into TRAINING (trainingid, location, training_date, name)
values (101, 'St. Andrew’s Guesthouse', to_date('24-05-2025', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (102, 'Ramada Jerusalem Hotel', to_date('07-10-2024', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (103, 'King David Hotel', to_date('09-09-2023', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (104, 'Dan Panorama Jerusalem', to_date('17-02-2032', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (105, 'Mamilla Hotel', to_date('13-12-2032', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (106, 'Jerusalem Gardens Hotel', to_date('21-05-2033', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (107, 'Prima Kings Hotel', to_date('01-08-2025', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (108, 'Hansen House', to_date('16-09-2029', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (109, 'Notre Dame of Jerusalem Center', to_date('22-05-2020', 'dd-mm-yyyy'), 'Computer training');
insert into TRAINING (trainingid, location, training_date, name)
values (110, 'Ritz Hotel Jerusalem', to_date('21-07-2031', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (111, 'Hansen House', to_date('28-05-2020', 'dd-mm-yyyy'), 'Fall training');
insert into TRAINING (trainingid, location, training_date, name)
values (112, 'Jerusalem Cinematheque', to_date('09-04-2031', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (113, 'Shalom Hartman Institute', to_date('04-03-2031', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (114, 'The Post Hostel', to_date('26-11-2027', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (115, 'Orient Jerusalem', to_date('25-03-2025', 'dd-mm-yyyy'), 'Literature training');
insert into TRAINING (trainingid, location, training_date, name)
values (116, 'Inbal Jerusalem Hotel', to_date('15-10-2028', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (117, 'Paamonim Hotel Jerusalem', to_date('02-10-2022', 'dd-mm-yyyy'), 'Arabic training');
insert into TRAINING (trainingid, location, training_date, name)
values (118, 'Notre Dame of Jerusalem Center', to_date('08-01-2030', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (119, 'St. Andrew’s Guesthouse', to_date('18-11-2030', 'dd-mm-yyyy'), 'Mathematics training');
insert into TRAINING (trainingid, location, training_date, name)
values (120, 'Hansen House', to_date('04-12-2032', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (121, 'American Colony Hotel', to_date('14-05-2020', 'dd-mm-yyyy'), 'Fall training');
insert into TRAINING (trainingid, location, training_date, name)
values (122, 'Mount Scopus Hotel', to_date('16-11-2025', 'dd-mm-yyyy'), 'Science training');
insert into TRAINING (trainingid, location, training_date, name)
values (123, 'Mount Scopus Hotel', to_date('02-07-2020', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (124, 'St. Andrew’s Guesthouse', to_date('22-07-2028', 'dd-mm-yyyy'), 'End of year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (125, 'Shalom Hartman Institute', to_date('27-09-2024', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (126, 'Inbal Jerusalem Hotel', to_date('30-05-2021', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (127, 'Legacy Hotel Jerusalem', to_date('08-11-2033', 'dd-mm-yyyy'), 'Summer training');
insert into TRAINING (trainingid, location, training_date, name)
values (128, 'Mount Scopus Hotel', to_date('27-08-2033', 'dd-mm-yyyy'), 'Hanukkah conference');
insert into TRAINING (trainingid, location, training_date, name)
values (129, 'Khan Theatre', to_date('13-09-2032', 'dd-mm-yyyy'), 'Chemistry training');
insert into TRAINING (trainingid, location, training_date, name)
values (130, 'Crowne Plaza Jerusalem', to_date('17-05-2025', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (131, 'Van Leer Institute', to_date('12-08-2023', 'dd-mm-yyyy'), 'End of year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (132, 'Jerusalem Gardens Hotel', to_date('21-12-2030', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (133, 'Ramada Jerusalem Hotel', to_date('13-08-2031', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (134, 'Mount Zion Hotel', to_date('20-07-2023', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (135, 'Van Leer Institute', to_date('05-05-2025', 'dd-mm-yyyy'), 'End of year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (136, 'Jerusalem Hotel', to_date('26-04-2026', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (137, 'Prima Kings Hotel', to_date('28-07-2033', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (138, 'Paamonim Hotel Jerusalem', to_date('05-03-2032', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (139, 'Legacy Hotel Jerusalem', to_date('30-11-2032', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (140, 'Jerusalem Gardens Hotel', to_date('01-05-2030', 'dd-mm-yyyy'), 'Science training');
insert into TRAINING (trainingid, location, training_date, name)
values (141, 'Inbal Jerusalem Hotel', to_date('13-10-2029', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (142, 'Hansen House', to_date('25-01-2025', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (143, 'Mount Scopus Hotel', to_date('06-05-2031', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (144, 'Mamilla Hotel', to_date('14-10-2021', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (145, 'Dan Panorama Jerusalem', to_date('01-11-2020', 'dd-mm-yyyy'), 'Summer training');
insert into TRAINING (trainingid, location, training_date, name)
values (146, 'Inbal Jerusalem Hotel', to_date('03-03-2033', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (147, 'Eldan Hotel', to_date('24-03-2028', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (148, 'Dan Panorama Jerusalem', to_date('06-05-2028', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (149, 'Waldorf Astoria Jerusalem', to_date('18-04-2020', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (150, 'Mount Scopus Hotel', to_date('17-04-2029', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (151, 'Legacy Hotel Jerusalem', to_date('02-05-2026', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (152, 'Mamilla Hotel', to_date('20-10-2024', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (153, 'Mount Scopus Hotel', to_date('10-03-2030', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (154, 'Dan Boutique Jerusalem', to_date('19-03-2023', 'dd-mm-yyyy'), 'Summer training');
insert into TRAINING (trainingid, location, training_date, name)
values (155, 'Jerusalem Hotel', to_date('30-04-2024', 'dd-mm-yyyy'), 'Computer training');
insert into TRAINING (trainingid, location, training_date, name)
values (156, 'Jerusalem Hotel', to_date('15-01-2020', 'dd-mm-yyyy'), 'Literature training');
insert into TRAINING (trainingid, location, training_date, name)
values (157, 'The Post Hostel', to_date('11-12-2029', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (158, 'Dan Panorama Jerusalem', to_date('13-02-2024', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (159, 'Van Leer Institute', to_date('01-03-2033', 'dd-mm-yyyy'), 'Chemistry training');
insert into TRAINING (trainingid, location, training_date, name)
values (160, 'Paamonim Hotel Jerusalem', to_date('18-01-2027', 'dd-mm-yyyy'), 'Arabic training');
insert into TRAINING (trainingid, location, training_date, name)
values (161, 'Notre Dame of Jerusalem Center', to_date('27-04-2029', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (162, 'American Colony Hotel', to_date('01-04-2023', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (163, 'American Colony Hotel', to_date('22-10-2022', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (164, 'St. Andrew’s Guesthouse', to_date('18-12-2027', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (165, 'Crowne Plaza Jerusalem', to_date('22-01-2029', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (166, 'Dan Boutique Jerusalem', to_date('06-12-2033', 'dd-mm-yyyy'), 'Hanukkah conference');
insert into TRAINING (trainingid, location, training_date, name)
values (167, 'Prima Kings Hotel', to_date('07-03-2027', 'dd-mm-yyyy'), 'Computer training');
insert into TRAINING (trainingid, location, training_date, name)
values (168, 'Paamonim Hotel Jerusalem', to_date('12-08-2023', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (169, 'Dan Boutique Jerusalem', to_date('24-10-2022', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (170, 'Mamilla Hotel', to_date('20-10-2031', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (171, 'Mount Scopus Hotel', to_date('12-03-2023', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (172, 'Ramada Jerusalem Hotel', to_date('28-07-2023', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (173, 'Prima Kings Hotel', to_date('02-03-2027', 'dd-mm-yyyy'), 'End of year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (174, 'Crowne Plaza Jerusalem', to_date('21-04-2027', 'dd-mm-yyyy'), 'Hanukkah conference');
insert into TRAINING (trainingid, location, training_date, name)
values (175, 'National Hotel Jerusalem', to_date('17-04-2024', 'dd-mm-yyyy'), 'Chemistry training');
insert into TRAINING (trainingid, location, training_date, name)
values (176, 'Dan Panorama Jerusalem', to_date('22-02-2025', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (177, 'The Hebrew University', to_date('09-12-2031', 'dd-mm-yyyy'), 'Winter training');
insert into TRAINING (trainingid, location, training_date, name)
values (178, 'Jerusalem Hotel', to_date('05-09-2023', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (179, 'The Hebrew University', to_date('08-07-2021', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (180, 'The Post Hostel', to_date('13-04-2020', 'dd-mm-yyyy'), 'Chemistry training');
insert into TRAINING (trainingid, location, training_date, name)
values (181, 'Hansen House', to_date('19-04-2032', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (182, 'Hansen House', to_date('22-08-2021', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (183, 'Dan Panorama Jerusalem', to_date('14-11-2023', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (184, 'Mount Zion Hotel', to_date('28-01-2027', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (185, 'Paamonim Hotel Jerusalem', to_date('05-02-2029', 'dd-mm-yyyy'), 'Arabic training');
insert into TRAINING (trainingid, location, training_date, name)
values (186, 'Jerusalem Gardens Hotel', to_date('08-01-2028', 'dd-mm-yyyy'), 'Hanukkah conference');
insert into TRAINING (trainingid, location, training_date, name)
values (187, 'Aish HaTorah Center', to_date('25-04-2024', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (188, 'Orient Jerusalem', to_date('13-12-2024', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (189, 'Mount Zion Hotel', to_date('09-12-2025', 'dd-mm-yyyy'), 'Fall training');
insert into TRAINING (trainingid, location, training_date, name)
values (190, 'Ramada Jerusalem Hotel', to_date('28-07-2031', 'dd-mm-yyyy'), 'Literature training');
insert into TRAINING (trainingid, location, training_date, name)
values (191, 'Ritz Hotel Jerusalem', to_date('19-03-2031', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (192, 'Crowne Plaza Jerusalem', to_date('08-12-2020', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (193, 'Prima Park Hotel', to_date('15-10-2029', 'dd-mm-yyyy'), 'Literature training');
insert into TRAINING (trainingid, location, training_date, name)
values (194, 'Hansen House', to_date('26-10-2026', 'dd-mm-yyyy'), 'Arabic training');
insert into TRAINING (trainingid, location, training_date, name)
values (195, 'Ritz Hotel Jerusalem', to_date('06-12-2023', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (196, 'Jerusalem Cinematheque', to_date('31-10-2024', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (197, 'American Colony Hotel', to_date('21-11-2031', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (198, 'Harmony Hotel', to_date('10-05-2028', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (199, 'Crowne Plaza Jerusalem', to_date('17-01-2033', 'dd-mm-yyyy'), 'End of year conference');
commit;
prompt 100 records committed...
insert into TRAINING (trainingid, location, training_date, name)
values (200, 'ICC Jerusalem', to_date('05-10-2022', 'dd-mm-yyyy'), 'Computer training');
insert into TRAINING (trainingid, location, training_date, name)
values (201, 'ICC Jerusalem', to_date('19-05-2033', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (202, 'Harmony Hotel', to_date('27-03-2029', 'dd-mm-yyyy'), 'Winter training');
insert into TRAINING (trainingid, location, training_date, name)
values (203, 'Shalom Hartman Institute', to_date('25-09-2031', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (204, 'Hansen House', to_date('12-10-2030', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (205, 'Waldorf Astoria Jerusalem', to_date('31-05-2030', 'dd-mm-yyyy'), 'Holocaust Day');
insert into TRAINING (trainingid, location, training_date, name)
values (206, 'St. Andrew’s Guesthouse', to_date('05-12-2024', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (207, 'Waldorf Astoria Jerusalem', to_date('16-02-2026', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (208, 'Ritz Hotel Jerusalem', to_date('28-02-2033', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (209, 'Eldan Hotel', to_date('20-12-2025', 'dd-mm-yyyy'), 'Winter training');
insert into TRAINING (trainingid, location, training_date, name)
values (210, 'Waldorf Astoria Jerusalem', to_date('12-02-2026', 'dd-mm-yyyy'), 'Summer training');
insert into TRAINING (trainingid, location, training_date, name)
values (211, 'Prima Park Hotel', to_date('16-10-2032', 'dd-mm-yyyy'), 'Mathematics training');
insert into TRAINING (trainingid, location, training_date, name)
values (212, 'Jerusalem Cinematheque', to_date('20-07-2029', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (213, 'Crowne Plaza Jerusalem', to_date('06-04-2032', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (214, 'Khan Theatre', to_date('05-05-2033', 'dd-mm-yyyy'), 'Winter training');
insert into TRAINING (trainingid, location, training_date, name)
values (215, 'Waldorf Astoria Jerusalem', to_date('02-09-2031', 'dd-mm-yyyy'), 'Chemistry training');
insert into TRAINING (trainingid, location, training_date, name)
values (216, 'Dan Boutique Jerusalem', to_date('26-06-2027', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (217, 'Dan Panorama Jerusalem', to_date('09-08-2027', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (218, 'Prima Park Hotel', to_date('20-12-2024', 'dd-mm-yyyy'), 'Hanukkah conference');
insert into TRAINING (trainingid, location, training_date, name)
values (219, 'Prima Kings Hotel', to_date('12-06-2028', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (220, 'Notre Dame of Jerusalem Center', to_date('30-06-2025', 'dd-mm-yyyy'), 'Science training');
insert into TRAINING (trainingid, location, training_date, name)
values (221, 'Notre Dame of Jerusalem Center', to_date('09-03-2029', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (222, 'Eldan Hotel', to_date('30-08-2020', 'dd-mm-yyyy'), 'Winter training');
insert into TRAINING (trainingid, location, training_date, name)
values (223, 'Khan Theatre', to_date('19-09-2033', 'dd-mm-yyyy'), 'Winter training');
insert into TRAINING (trainingid, location, training_date, name)
values (224, 'The Post Hostel', to_date('10-08-2032', 'dd-mm-yyyy'), 'Literature training');
insert into TRAINING (trainingid, location, training_date, name)
values (225, 'Khan Theatre', to_date('01-11-2028', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (226, 'Jerusalem Hotel', to_date('20-01-2023', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (227, 'Prima Park Hotel', to_date('05-05-2021', 'dd-mm-yyyy'), 'Science training');
insert into TRAINING (trainingid, location, training_date, name)
values (228, 'Shalom Hartman Institute', to_date('06-07-2031', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (229, 'Dan Boutique Jerusalem', to_date('17-04-2033', 'dd-mm-yyyy'), 'Computer training');
insert into TRAINING (trainingid, location, training_date, name)
values (230, 'Waldorf Astoria Jerusalem', to_date('30-08-2032', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (231, 'Van Leer Institute', to_date('04-01-2024', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (232, 'King David Hotel', to_date('13-05-2023', 'dd-mm-yyyy'), 'Fall training');
insert into TRAINING (trainingid, location, training_date, name)
values (233, 'Inbal Jerusalem Hotel', to_date('26-03-2028', 'dd-mm-yyyy'), 'Arabic training');
insert into TRAINING (trainingid, location, training_date, name)
values (234, 'Ramada Jerusalem Hotel', to_date('01-07-2024', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (235, 'Waldorf Astoria Jerusalem', to_date('24-08-2026', 'dd-mm-yyyy'), 'Summer training');
insert into TRAINING (trainingid, location, training_date, name)
values (236, 'Jerusalem Gardens Hotel', to_date('29-07-2022', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (237, 'Van Leer Institute', to_date('03-09-2028', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (238, 'Paamonim Hotel Jerusalem', to_date('10-05-2027', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (239, 'Van Leer Institute', to_date('21-09-2033', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (240, 'Prima Park Hotel', to_date('10-01-2022', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (241, 'Orient Jerusalem', to_date('09-07-2029', 'dd-mm-yyyy'), 'Winter training');
insert into TRAINING (trainingid, location, training_date, name)
values (242, 'Mamilla Hotel', to_date('17-09-2027', 'dd-mm-yyyy'), 'Literature training');
insert into TRAINING (trainingid, location, training_date, name)
values (243, 'Paamonim Hotel Jerusalem', to_date('06-05-2027', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (244, 'King David Hotel', to_date('10-02-2027', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (245, 'Inbal Jerusalem Hotel', to_date('06-03-2027', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (246, 'Khan Theatre', to_date('08-01-2032', 'dd-mm-yyyy'), 'End of year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (247, 'Orient Jerusalem', to_date('21-06-2025', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (248, 'YMCA Three Arches Hotel', to_date('26-09-2020', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (249, 'Prima Kings Hotel', to_date('14-10-2023', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (250, 'Shalom Hartman Institute', to_date('27-10-2022', 'dd-mm-yyyy'), 'Summer training');
insert into TRAINING (trainingid, location, training_date, name)
values (251, 'Beit Shmuel', to_date('20-10-2026', 'dd-mm-yyyy'), 'Fall training');
insert into TRAINING (trainingid, location, training_date, name)
values (252, 'Beit Shmuel', to_date('05-02-2027', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (253, 'Aish HaTorah Center', to_date('10-03-2022', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (254, 'Waldorf Astoria Jerusalem', to_date('14-11-2025', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (255, 'King David Hotel', to_date('02-05-2024', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (256, 'Notre Dame of Jerusalem Center', to_date('26-12-2020', 'dd-mm-yyyy'), 'Summer training');
insert into TRAINING (trainingid, location, training_date, name)
values (257, 'Ritz Hotel Jerusalem', to_date('02-11-2021', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (258, 'Inbal Jerusalem Hotel', to_date('26-12-2024', 'dd-mm-yyyy'), 'Chemistry training');
insert into TRAINING (trainingid, location, training_date, name)
values (259, 'American Colony Hotel', to_date('15-11-2024', 'dd-mm-yyyy'), 'Winter training');
insert into TRAINING (trainingid, location, training_date, name)
values (260, 'Ritz Hotel Jerusalem', to_date('16-02-2024', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (261, 'Waldorf Astoria Jerusalem', to_date('20-04-2028', 'dd-mm-yyyy'), 'Computer training');
insert into TRAINING (trainingid, location, training_date, name)
values (262, 'Mamilla Hotel', to_date('13-01-2026', 'dd-mm-yyyy'), 'Arabic training');
insert into TRAINING (trainingid, location, training_date, name)
values (263, 'King David Hotel', to_date('19-06-2033', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (264, 'The Hebrew University', to_date('15-10-2027', 'dd-mm-yyyy'), 'Fall training');
insert into TRAINING (trainingid, location, training_date, name)
values (265, 'Inbal Jerusalem Hotel', to_date('29-06-2020', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (266, 'Jerusalem Cinematheque', to_date('29-12-2023', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (267, 'Hansen House', to_date('06-02-2032', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (268, 'American Colony Hotel', to_date('08-12-2032', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (269, 'Dan Boutique Jerusalem', to_date('14-08-2023', 'dd-mm-yyyy'), 'Science training');
insert into TRAINING (trainingid, location, training_date, name)
values (270, 'Notre Dame of Jerusalem Center', to_date('15-12-2030', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (271, 'National Hotel Jerusalem', to_date('09-07-2022', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (272, 'Prima Park Hotel', to_date('09-09-2028', 'dd-mm-yyyy'), 'Literature training');
insert into TRAINING (trainingid, location, training_date, name)
values (273, 'Legacy Hotel Jerusalem', to_date('28-09-2031', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (274, 'YMCA Three Arches Hotel', to_date('03-02-2033', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (275, 'Prima Kings Hotel', to_date('01-06-2028', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (276, 'Ramada Jerusalem Hotel', to_date('18-01-2031', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (277, 'Eldan Hotel', to_date('24-07-2022', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (278, 'Jerusalem Hotel', to_date('01-12-2031', 'dd-mm-yyyy'), 'Chemistry training');
insert into TRAINING (trainingid, location, training_date, name)
values (279, 'Crowne Plaza Jerusalem', to_date('28-12-2029', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (280, 'Waldorf Astoria Jerusalem', to_date('25-02-2027', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (281, 'The Hebrew University', to_date('30-11-2023', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (282, 'Legacy Hotel Jerusalem', to_date('29-01-2028', 'dd-mm-yyyy'), 'Computer training');
insert into TRAINING (trainingid, location, training_date, name)
values (283, 'Harmony Hotel', to_date('24-12-2022', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (284, 'Orient Jerusalem', to_date('22-02-2029', 'dd-mm-yyyy'), 'Arabic training');
insert into TRAINING (trainingid, location, training_date, name)
values (285, 'Ritz Hotel Jerusalem', to_date('09-11-2030', 'dd-mm-yyyy'), 'Chemistry training');
insert into TRAINING (trainingid, location, training_date, name)
values (286, 'Mount Scopus Hotel', to_date('10-12-2021', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (287, 'ICC Jerusalem', to_date('22-02-2031', 'dd-mm-yyyy'), 'Fall training');
insert into TRAINING (trainingid, location, training_date, name)
values (288, 'Mount Zion Hotel', to_date('04-04-2020', 'dd-mm-yyyy'), 'Summer training');
insert into TRAINING (trainingid, location, training_date, name)
values (289, 'Shalom Hartman Institute', to_date('15-06-2021', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (290, 'Legacy Hotel Jerusalem', to_date('10-10-2031', 'dd-mm-yyyy'), 'End of year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (291, 'King David Hotel', to_date('23-12-2026', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (292, 'American Colony Hotel', to_date('26-03-2024', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (293, 'Eldan Hotel', to_date('05-10-2026', 'dd-mm-yyyy'), 'Mathematics training');
insert into TRAINING (trainingid, location, training_date, name)
values (294, 'Dan Boutique Jerusalem', to_date('23-07-2029', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (295, 'The Post Hostel', to_date('22-11-2031', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (296, 'Mamilla Hotel', to_date('24-07-2028', 'dd-mm-yyyy'), 'Computer training');
insert into TRAINING (trainingid, location, training_date, name)
values (297, 'YMCA Three Arches Hotel', to_date('17-10-2031', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (298, 'Paamonim Hotel Jerusalem', to_date('10-06-2033', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (299, 'Aish HaTorah Center', to_date('17-08-2031', 'dd-mm-yyyy'), 'Purim conference');
commit;
prompt 200 records committed...
insert into TRAINING (trainingid, location, training_date, name)
values (300, 'Khan Theatre', to_date('08-02-2024', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (301, 'Notre Dame of Jerusalem Center', to_date('15-01-2022', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (302, 'Crowne Plaza Jerusalem', to_date('10-06-2020', 'dd-mm-yyyy'), 'Summer training');
insert into TRAINING (trainingid, location, training_date, name)
values (303, 'King David Hotel', to_date('13-09-2026', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (304, 'Dan Panorama Jerusalem', to_date('16-01-2034', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (305, 'Orient Jerusalem', to_date('17-02-2028', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (306, 'Mamilla Hotel', to_date('11-11-2027', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (307, 'The Hebrew University', to_date('11-05-2030', 'dd-mm-yyyy'), 'Hanukkah conference');
insert into TRAINING (trainingid, location, training_date, name)
values (308, 'Mount Scopus Hotel', to_date('09-04-2027', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (309, 'Inbal Jerusalem Hotel', to_date('13-04-2026', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (310, 'Prima Park Hotel', to_date('03-05-2029', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (311, 'Mamilla Hotel', to_date('27-10-2021', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (312, 'Mamilla Hotel', to_date('16-07-2021', 'dd-mm-yyyy'), 'Summer training');
insert into TRAINING (trainingid, location, training_date, name)
values (313, 'Waldorf Astoria Jerusalem', to_date('08-11-2022', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (314, 'Ramada Jerusalem Hotel', to_date('29-10-2028', 'dd-mm-yyyy'), 'Hanukkah conference');
insert into TRAINING (trainingid, location, training_date, name)
values (315, 'Legacy Hotel Jerusalem', to_date('10-01-2034', 'dd-mm-yyyy'), 'Mathematics training');
insert into TRAINING (trainingid, location, training_date, name)
values (316, 'Beit Shmuel', to_date('04-03-2029', 'dd-mm-yyyy'), 'Mathematics training');
insert into TRAINING (trainingid, location, training_date, name)
values (317, 'Crowne Plaza Jerusalem', to_date('18-04-2030', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (318, 'Mamilla Hotel', to_date('26-01-2030', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (319, 'Van Leer Institute', to_date('01-04-2031', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (320, 'Ritz Hotel Jerusalem', to_date('16-03-2030', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (321, 'King David Hotel', to_date('22-05-2021', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (322, 'Hansen House', to_date('02-03-2020', 'dd-mm-yyyy'), 'Science training');
insert into TRAINING (trainingid, location, training_date, name)
values (323, 'Legacy Hotel Jerusalem', to_date('11-10-2030', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (324, 'Jerusalem Hotel', to_date('20-05-2032', 'dd-mm-yyyy'), 'Fall training');
insert into TRAINING (trainingid, location, training_date, name)
values (325, 'Ramada Jerusalem Hotel', to_date('26-08-2029', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (326, 'Harmony Hotel', to_date('16-02-2030', 'dd-mm-yyyy'), 'Summer training');
insert into TRAINING (trainingid, location, training_date, name)
values (327, 'Notre Dame of Jerusalem Center', to_date('28-05-2033', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (328, 'Dan Panorama Jerusalem', to_date('24-12-2030', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (329, 'ICC Jerusalem', to_date('30-03-2024', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (330, 'Mamilla Hotel', to_date('20-08-2021', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (331, 'Jerusalem Gardens Hotel', to_date('04-06-2032', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (332, 'Hansen House', to_date('26-11-2029', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (333, 'Jerusalem Gardens Hotel', to_date('20-09-2033', 'dd-mm-yyyy'), 'Hanukkah conference');
insert into TRAINING (trainingid, location, training_date, name)
values (334, 'Ritz Hotel Jerusalem', to_date('22-03-2027', 'dd-mm-yyyy'), 'End of year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (335, 'Shalom Hartman Institute', to_date('10-07-2030', 'dd-mm-yyyy'), 'Arabic training');
insert into TRAINING (trainingid, location, training_date, name)
values (336, 'St. Andrew’s Guesthouse', to_date('25-04-2030', 'dd-mm-yyyy'), 'Arabic training');
insert into TRAINING (trainingid, location, training_date, name)
values (337, 'National Hotel Jerusalem', to_date('21-06-2031', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (338, 'Prima Park Hotel', to_date('04-05-2032', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (339, 'Dan Panorama Jerusalem', to_date('21-05-2027', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (340, 'Prima Kings Hotel', to_date('16-02-2027', 'dd-mm-yyyy'), 'Chemistry training');
insert into TRAINING (trainingid, location, training_date, name)
values (341, 'Khan Theatre', to_date('16-12-2024', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (342, 'Ramada Jerusalem Hotel', to_date('30-09-2022', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (343, 'Ramada Jerusalem Hotel', to_date('05-05-2023', 'dd-mm-yyyy'), 'Literature training');
insert into TRAINING (trainingid, location, training_date, name)
values (344, 'Beit Shmuel', to_date('11-02-2025', 'dd-mm-yyyy'), 'Mathematics training');
insert into TRAINING (trainingid, location, training_date, name)
values (345, 'Inbal Jerusalem Hotel', to_date('21-01-2032', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (346, 'Notre Dame of Jerusalem Center', to_date('19-09-2020', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (347, 'Ritz Hotel Jerusalem', to_date('20-10-2022', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (348, 'Mount Scopus Hotel', to_date('28-03-2028', 'dd-mm-yyyy'), 'Mathematics training');
insert into TRAINING (trainingid, location, training_date, name)
values (349, 'Paamonim Hotel Jerusalem', to_date('19-08-2029', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (350, 'YMCA Three Arches Hotel', to_date('04-11-2028', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (351, 'Beit Shmuel', to_date('21-01-2026', 'dd-mm-yyyy'), 'Computer training');
insert into TRAINING (trainingid, location, training_date, name)
values (352, 'YMCA Three Arches Hotel', to_date('21-06-2027', 'dd-mm-yyyy'), 'Summer training');
insert into TRAINING (trainingid, location, training_date, name)
values (353, 'Aish HaTorah Center', to_date('26-11-2031', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (354, 'Notre Dame of Jerusalem Center', to_date('05-07-2025', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (355, 'Prima Kings Hotel', to_date('01-02-2030', 'dd-mm-yyyy'), 'Holocaust Day');
insert into TRAINING (trainingid, location, training_date, name)
values (356, 'Jerusalem Hotel', to_date('26-03-2025', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (357, 'Prima Park Hotel', to_date('22-12-2032', 'dd-mm-yyyy'), 'Science training');
insert into TRAINING (trainingid, location, training_date, name)
values (358, 'Aish HaTorah Center', to_date('26-03-2024', 'dd-mm-yyyy'), 'Summer training');
insert into TRAINING (trainingid, location, training_date, name)
values (359, 'YMCA Three Arches Hotel', to_date('28-09-2032', 'dd-mm-yyyy'), 'End of year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (360, 'Paamonim Hotel Jerusalem', to_date('30-10-2021', 'dd-mm-yyyy'), 'Chemistry training');
insert into TRAINING (trainingid, location, training_date, name)
values (361, 'Harmony Hotel', to_date('10-07-2032', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (362, 'Paamonim Hotel Jerusalem', to_date('17-01-2020', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (363, 'Waldorf Astoria Jerusalem', to_date('01-01-2026', 'dd-mm-yyyy'), 'Arabic training');
insert into TRAINING (trainingid, location, training_date, name)
values (364, 'Eldan Hotel', to_date('18-10-2030', 'dd-mm-yyyy'), 'Summer training');
insert into TRAINING (trainingid, location, training_date, name)
values (365, 'Ritz Hotel Jerusalem', to_date('13-02-2033', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (366, 'Prima Kings Hotel', to_date('09-11-2028', 'dd-mm-yyyy'), 'Holocaust Day');
insert into TRAINING (trainingid, location, training_date, name)
values (367, 'YMCA Three Arches Hotel', to_date('21-12-2032', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (368, 'Ramada Jerusalem Hotel', to_date('13-11-2026', 'dd-mm-yyyy'), 'Holocaust Day');
insert into TRAINING (trainingid, location, training_date, name)
values (369, 'Hansen House', to_date('16-09-2022', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (370, 'Aish HaTorah Center', to_date('22-09-2024', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (371, 'Jerusalem Hotel', to_date('15-09-2031', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (372, 'The Hebrew University', to_date('11-06-2021', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (373, 'Mount Zion Hotel', to_date('08-11-2028', 'dd-mm-yyyy'), 'Hanukkah conference');
insert into TRAINING (trainingid, location, training_date, name)
values (374, 'Inbal Jerusalem Hotel', to_date('21-05-2020', 'dd-mm-yyyy'), 'Hanukkah conference');
insert into TRAINING (trainingid, location, training_date, name)
values (375, 'Mamilla Hotel', to_date('25-02-2026', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (376, 'American Colony Hotel', to_date('23-10-2025', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (377, 'Mount Scopus Hotel', to_date('03-12-2024', 'dd-mm-yyyy'), 'Science training');
insert into TRAINING (trainingid, location, training_date, name)
values (378, 'Jerusalem Cinematheque', to_date('29-08-2024', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (379, 'Prima Park Hotel', to_date('14-03-2026', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (380, 'King David Hotel', to_date('22-01-2034', 'dd-mm-yyyy'), 'Chemistry training');
insert into TRAINING (trainingid, location, training_date, name)
values (381, 'Jerusalem Cinematheque', to_date('16-07-2026', 'dd-mm-yyyy'), 'Mathematics training');
insert into TRAINING (trainingid, location, training_date, name)
values (382, 'Khan Theatre', to_date('14-03-2029', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (383, 'Dan Boutique Jerusalem', to_date('26-10-2023', 'dd-mm-yyyy'), 'Arabic training');
insert into TRAINING (trainingid, location, training_date, name)
values (384, 'Jerusalem Gardens Hotel', to_date('23-03-2022', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (385, 'YMCA Three Arches Hotel', to_date('11-01-2021', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (386, 'Crowne Plaza Jerusalem', to_date('25-02-2028', 'dd-mm-yyyy'), 'Computer training');
insert into TRAINING (trainingid, location, training_date, name)
values (387, 'ICC Jerusalem', to_date('30-04-2030', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (388, 'ICC Jerusalem', to_date('05-07-2023', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (389, 'The Post Hostel', to_date('22-11-2026', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (390, 'King David Hotel', to_date('21-09-2033', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (391, 'Jerusalem Gardens Hotel', to_date('08-03-2028', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (392, 'Jerusalem Gardens Hotel', to_date('14-07-2021', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (393, 'Mamilla Hotel', to_date('29-04-2029', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (394, 'Hansen House', to_date('06-03-2031', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (395, 'Dan Panorama Jerusalem', to_date('18-03-2026', 'dd-mm-yyyy'), 'Computer training');
insert into TRAINING (trainingid, location, training_date, name)
values (396, 'Mount Scopus Hotel', to_date('26-10-2022', 'dd-mm-yyyy'), 'End of year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (397, 'Waldorf Astoria Jerusalem', to_date('11-06-2022', 'dd-mm-yyyy'), 'Mathematics training');
insert into TRAINING (trainingid, location, training_date, name)
values (398, 'YMCA Three Arches Hotel', to_date('19-07-2030', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (399, 'Shalom Hartman Institute', to_date('07-10-2029', 'dd-mm-yyyy'), 'Purim conference');
commit;
prompt 300 records committed...
insert into TRAINING (trainingid, location, training_date, name)
values (400, 'Crowne Plaza Jerusalem', to_date('29-04-2029', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (401, 'The Post Hostel', to_date('05-07-2027', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (402, 'Mount Zion Hotel', to_date('05-08-2021', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (403, 'Inbal Jerusalem Hotel', to_date('19-10-2026', 'dd-mm-yyyy'), 'Arabic training');
insert into TRAINING (trainingid, location, training_date, name)
values (404, 'Mamilla Hotel', to_date('09-08-2032', 'dd-mm-yyyy'), 'Holocaust Day');
insert into TRAINING (trainingid, location, training_date, name)
values (405, 'Mount Scopus Hotel', to_date('02-05-2022', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (406, 'American Colony Hotel', to_date('21-06-2028', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (407, 'Ritz Hotel Jerusalem', to_date('06-10-2028', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (408, 'Orient Jerusalem', to_date('01-12-2029', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (409, 'Waldorf Astoria Jerusalem', to_date('25-03-2028', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (410, 'Van Leer Institute', to_date('13-10-2021', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (411, 'American Colony Hotel', to_date('08-06-2024', 'dd-mm-yyyy'), 'Arabic training');
insert into TRAINING (trainingid, location, training_date, name)
values (412, 'Aish HaTorah Center', to_date('10-03-2020', 'dd-mm-yyyy'), 'Science training');
insert into TRAINING (trainingid, location, training_date, name)
values (413, 'Waldorf Astoria Jerusalem', to_date('13-09-2028', 'dd-mm-yyyy'), 'Fall training');
insert into TRAINING (trainingid, location, training_date, name)
values (414, 'Jerusalem Gardens Hotel', to_date('20-03-2021', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (415, 'Notre Dame of Jerusalem Center', to_date('28-11-2031', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (416, 'Jerusalem Hotel', to_date('06-02-2029', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (417, 'Harmony Hotel', to_date('29-07-2026', 'dd-mm-yyyy'), 'Computer training');
insert into TRAINING (trainingid, location, training_date, name)
values (418, 'Legacy Hotel Jerusalem', to_date('30-11-2025', 'dd-mm-yyyy'), 'Literature training');
insert into TRAINING (trainingid, location, training_date, name)
values (419, 'Dan Panorama Jerusalem', to_date('24-06-2030', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (420, 'Inbal Jerusalem Hotel', to_date('11-09-2024', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (421, 'Van Leer Institute', to_date('12-08-2033', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (422, 'ICC Jerusalem', to_date('30-06-2021', 'dd-mm-yyyy'), 'Computer training');
insert into TRAINING (trainingid, location, training_date, name)
values (423, 'Harmony Hotel', to_date('14-02-2033', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (424, 'Khan Theatre', to_date('20-12-2032', 'dd-mm-yyyy'), 'Fall training');
insert into TRAINING (trainingid, location, training_date, name)
values (425, 'Crowne Plaza Jerusalem', to_date('28-01-2027', 'dd-mm-yyyy'), 'Computer training');
insert into TRAINING (trainingid, location, training_date, name)
values (426, 'The Post Hostel', to_date('03-03-2029', 'dd-mm-yyyy'), 'Holocaust Day');
insert into TRAINING (trainingid, location, training_date, name)
values (427, 'Jerusalem Cinematheque', to_date('05-09-2023', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (428, 'Ramada Jerusalem Hotel', to_date('29-08-2021', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (429, 'Khan Theatre', to_date('30-12-2029', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (430, 'Orient Jerusalem', to_date('29-08-2031', 'dd-mm-yyyy'), 'Literature training');
insert into TRAINING (trainingid, location, training_date, name)
values (431, 'Inbal Jerusalem Hotel', to_date('19-04-2022', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (432, 'Jerusalem Hotel', to_date('08-07-2020', 'dd-mm-yyyy'), 'Winter training');
insert into TRAINING (trainingid, location, training_date, name)
values (433, 'Waldorf Astoria Jerusalem', to_date('23-10-2024', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (434, 'Harmony Hotel', to_date('14-03-2027', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (435, 'Beit Shmuel', to_date('10-01-2027', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (436, 'Dan Boutique Jerusalem', to_date('04-09-2024', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (437, 'Inbal Jerusalem Hotel', to_date('28-09-2026', 'dd-mm-yyyy'), 'Science training');
insert into TRAINING (trainingid, location, training_date, name)
values (438, 'Notre Dame of Jerusalem Center', to_date('20-04-2022', 'dd-mm-yyyy'), 'End of year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (439, 'Mount Scopus Hotel', to_date('01-12-2030', 'dd-mm-yyyy'), 'Hanukkah conference');
insert into TRAINING (trainingid, location, training_date, name)
values (440, 'YMCA Three Arches Hotel', to_date('19-12-2032', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (441, 'Ramada Jerusalem Hotel', to_date('15-09-2029', 'dd-mm-yyyy'), 'Holocaust Day');
insert into TRAINING (trainingid, location, training_date, name)
values (442, 'Beit Shmuel', to_date('09-06-2033', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (443, 'Van Leer Institute', to_date('29-03-2025', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (444, 'Aish HaTorah Center', to_date('03-03-2030', 'dd-mm-yyyy'), 'Science training');
insert into TRAINING (trainingid, location, training_date, name)
values (445, 'Paamonim Hotel Jerusalem', to_date('13-03-2030', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (446, 'Legacy Hotel Jerusalem', to_date('11-10-2023', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (447, 'Prima Kings Hotel', to_date('08-03-2032', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (448, 'Crowne Plaza Jerusalem', to_date('04-12-2033', 'dd-mm-yyyy'), 'Mathematics training');
insert into TRAINING (trainingid, location, training_date, name)
values (449, 'Aish HaTorah Center', to_date('26-07-2032', 'dd-mm-yyyy'), 'Fall training');
insert into TRAINING (trainingid, location, training_date, name)
values (450, 'Aish HaTorah Center', to_date('10-10-2023', 'dd-mm-yyyy'), 'Hanukkah conference');
insert into TRAINING (trainingid, location, training_date, name)
values (451, 'Ritz Hotel Jerusalem', to_date('28-04-2020', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (452, 'American Colony Hotel', to_date('08-10-2024', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (453, 'St. Andrew’s Guesthouse', to_date('30-05-2032', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (454, 'Ritz Hotel Jerusalem', to_date('23-01-2027', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (455, 'Van Leer Institute', to_date('15-10-2033', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (456, 'Jerusalem Cinematheque', to_date('11-02-2030', 'dd-mm-yyyy'), 'Biology training');
insert into TRAINING (trainingid, location, training_date, name)
values (457, 'Dan Panorama Jerusalem', to_date('23-12-2024', 'dd-mm-yyyy'), 'Winter training');
insert into TRAINING (trainingid, location, training_date, name)
values (458, 'Hansen House', to_date('31-01-2027', 'dd-mm-yyyy'), 'Art training');
insert into TRAINING (trainingid, location, training_date, name)
values (459, 'The Post Hostel', to_date('31-05-2021', 'dd-mm-yyyy'), 'Hanukkah conference');
insert into TRAINING (trainingid, location, training_date, name)
values (460, 'Inbal Jerusalem Hotel', to_date('14-04-2033', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (461, 'ICC Jerusalem', to_date('02-06-2033', 'dd-mm-yyyy'), 'Mathematics training');
insert into TRAINING (trainingid, location, training_date, name)
values (462, 'Waldorf Astoria Jerusalem', to_date('12-04-2028', 'dd-mm-yyyy'), 'Intermediate training');
insert into TRAINING (trainingid, location, training_date, name)
values (463, 'Notre Dame of Jerusalem Center', to_date('24-05-2029', 'dd-mm-yyyy'), 'Chemistry training');
insert into TRAINING (trainingid, location, training_date, name)
values (464, 'Beit Shmuel', to_date('26-10-2020', 'dd-mm-yyyy'), 'Hanukkah conference');
insert into TRAINING (trainingid, location, training_date, name)
values (465, 'The Post Hostel', to_date('15-04-2027', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (466, 'Prima Park Hotel', to_date('14-03-2021', 'dd-mm-yyyy'), 'Hanukkah conference');
insert into TRAINING (trainingid, location, training_date, name)
values (467, 'Jerusalem Gardens Hotel', to_date('29-10-2027', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (468, 'Ritz Hotel Jerusalem', to_date('13-04-2031', 'dd-mm-yyyy'), 'Spring training');
insert into TRAINING (trainingid, location, training_date, name)
values (469, 'Jerusalem Cinematheque', to_date('21-06-2030', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (470, 'National Hotel Jerusalem', to_date('11-03-2029', 'dd-mm-yyyy'), 'Winter training');
insert into TRAINING (trainingid, location, training_date, name)
values (471, 'Orient Jerusalem', to_date('10-12-2022', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (472, 'Dan Panorama Jerusalem', to_date('03-12-2021', 'dd-mm-yyyy'), 'Chemistry training');
insert into TRAINING (trainingid, location, training_date, name)
values (473, 'Waldorf Astoria Jerusalem', to_date('07-10-2028', 'dd-mm-yyyy'), 'Summer training');
insert into TRAINING (trainingid, location, training_date, name)
values (474, 'Mamilla Hotel', to_date('20-10-2033', 'dd-mm-yyyy'), 'English training');
insert into TRAINING (trainingid, location, training_date, name)
values (475, 'National Hotel Jerusalem', to_date('17-06-2027', 'dd-mm-yyyy'), 'Winter training');
insert into TRAINING (trainingid, location, training_date, name)
values (476, 'Orient Jerusalem', to_date('19-01-2024', 'dd-mm-yyyy'), 'New year conference');
insert into TRAINING (trainingid, location, training_date, name)
values (477, 'National Hotel Jerusalem', to_date('21-04-2033', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (478, 'The Hebrew University', to_date('02-05-2030', 'dd-mm-yyyy'), 'Sukkot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (479, 'Crowne Plaza Jerusalem', to_date('30-10-2020', 'dd-mm-yyyy'), 'Holocaust Day');
insert into TRAINING (trainingid, location, training_date, name)
values (480, 'Prima Park Hotel', to_date('01-04-2020', 'dd-mm-yyyy'), 'Holocaust Day');
insert into TRAINING (trainingid, location, training_date, name)
values (481, 'Dan Boutique Jerusalem', to_date('27-12-2029', 'dd-mm-yyyy'), 'Physics training');
insert into TRAINING (trainingid, location, training_date, name)
values (482, 'Harmony Hotel', to_date('08-05-2022', 'dd-mm-yyyy'), 'Fall training');
insert into TRAINING (trainingid, location, training_date, name)
values (483, 'Ritz Hotel Jerusalem', to_date('06-01-2030', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (484, 'Aish HaTorah Center', to_date('06-06-2029', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (485, 'YMCA Three Arches Hotel', to_date('28-06-2031', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (486, 'Ramada Jerusalem Hotel', to_date('02-03-2022', 'dd-mm-yyyy'), 'Fall training');
insert into TRAINING (trainingid, location, training_date, name)
values (487, 'Legacy Hotel Jerusalem', to_date('15-06-2021', 'dd-mm-yyyy'), 'Science training');
insert into TRAINING (trainingid, location, training_date, name)
values (488, 'American Colony Hotel', to_date('23-09-2032', 'dd-mm-yyyy'), 'Purim conference');
insert into TRAINING (trainingid, location, training_date, name)
values (489, 'King David Hotel', to_date('29-08-2022', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (490, 'Legacy Hotel Jerusalem', to_date('10-06-2024', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (491, 'Ritz Hotel Jerusalem', to_date('19-04-2030', 'dd-mm-yyyy'), 'Mathematics training');
insert into TRAINING (trainingid, location, training_date, name)
values (492, 'Legacy Hotel Jerusalem', to_date('05-02-2023', 'dd-mm-yyyy'), 'Passover conference');
insert into TRAINING (trainingid, location, training_date, name)
values (493, 'American Colony Hotel', to_date('19-10-2022', 'dd-mm-yyyy'), 'Hebrew training');
insert into TRAINING (trainingid, location, training_date, name)
values (494, 'Jerusalem Gardens Hotel', to_date('14-08-2029', 'dd-mm-yyyy'), 'Science training');
insert into TRAINING (trainingid, location, training_date, name)
values (495, 'American Colony Hotel', to_date('21-12-2020', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (496, 'Paamonim Hotel Jerusalem', to_date('04-09-2030', 'dd-mm-yyyy'), 'Arabic training');
insert into TRAINING (trainingid, location, training_date, name)
values (497, 'Van Leer Institute', to_date('20-11-2022', 'dd-mm-yyyy'), 'Shavuot conference');
insert into TRAINING (trainingid, location, training_date, name)
values (498, 'Ritz Hotel Jerusalem', to_date('31-08-2020', 'dd-mm-yyyy'), 'Mid-semester conference');
insert into TRAINING (trainingid, location, training_date, name)
values (499, 'Ritz Hotel Jerusalem', to_date('16-10-2029', 'dd-mm-yyyy'), 'Mathematics training');
commit;
prompt 400 records loaded
prompt Loading PARTICIPANT...
insert into PARTICIPANT (id, trainingid)
values (32696733, 463);
insert into PARTICIPANT (id, trainingid)
values (34065502, 134);
insert into PARTICIPANT (id, trainingid)
values (36488102, 191);
insert into PARTICIPANT (id, trainingid)
values (33750564, 113);
insert into PARTICIPANT (id, trainingid)
values (36451763, 462);
insert into PARTICIPANT (id, trainingid)
values (34368327, 129);
insert into PARTICIPANT (id, trainingid)
values (35555401, 105);
insert into PARTICIPANT (id, trainingid)
values (36245842, 456);
insert into PARTICIPANT (id, trainingid)
values (33217592, 101);
insert into PARTICIPANT (id, trainingid)
values (36185277, 206);
insert into PARTICIPANT (id, trainingid)
values (34659039, 409);
insert into PARTICIPANT (id, trainingid)
values (33423513, 461);
insert into PARTICIPANT (id, trainingid)
values (33956485, 256);
insert into PARTICIPANT (id, trainingid)
values (32236439, 441);
insert into PARTICIPANT (id, trainingid)
values (36536554, 279);
insert into PARTICIPANT (id, trainingid)
values (36173164, 181);
insert into PARTICIPANT (id, trainingid)
values (34041276, 237);
insert into PARTICIPANT (id, trainingid)
values (34574248, 434);
insert into PARTICIPANT (id, trainingid)
values (34792282, 453);
insert into PARTICIPANT (id, trainingid)
values (36694023, 264);
insert into PARTICIPANT (id, trainingid)
values (36221616, 109);
insert into PARTICIPANT (id, trainingid)
values (35785548, 458);
insert into PARTICIPANT (id, trainingid)
values (35119333, 368);
insert into PARTICIPANT (id, trainingid)
values (33290270, 215);
insert into PARTICIPANT (id, trainingid)
values (32502925, 431);
insert into PARTICIPANT (id, trainingid)
values (36984735, 236);
insert into PARTICIPANT (id, trainingid)
values (34283536, 311);
insert into PARTICIPANT (id, trainingid)
values (34973977, 284);
insert into PARTICIPANT (id, trainingid)
values (36064147, 226);
insert into PARTICIPANT (id, trainingid)
values (36161051, 136);
insert into PARTICIPANT (id, trainingid)
values (34634813, 202);
insert into PARTICIPANT (id, trainingid)
values (36064147, 178);
insert into PARTICIPANT (id, trainingid)
values (32309117, 376);
insert into PARTICIPANT (id, trainingid)
values (35095107, 398);
insert into PARTICIPANT (id, trainingid)
values (35894565, 200);
insert into PARTICIPANT (id, trainingid)
values (33471965, 197);
insert into PARTICIPANT (id, trainingid)
values (33157027, 435);
insert into PARTICIPANT (id, trainingid)
values (35519062, 386);
insert into PARTICIPANT (id, trainingid)
values (33302383, 330);
insert into PARTICIPANT (id, trainingid)
values (33375061, 395);
insert into PARTICIPANT (id, trainingid)
values (35967243, 477);
insert into PARTICIPANT (id, trainingid)
values (34501570, 254);
insert into PARTICIPANT (id, trainingid)
values (36621345, 342);
insert into PARTICIPANT (id, trainingid)
values (32793637, 167);
insert into PARTICIPANT (id, trainingid)
values (32454473, 360);
insert into PARTICIPANT (id, trainingid)
values (33423513, 253);
insert into PARTICIPANT (id, trainingid)
values (32527151, 190);
insert into PARTICIPANT (id, trainingid)
values (34126067, 263);
insert into PARTICIPANT (id, trainingid)
values (33593095, 422);
insert into PARTICIPANT (id, trainingid)
values (36282181, 452);
insert into PARTICIPANT (id, trainingid)
values (35797661, 337);
insert into PARTICIPANT (id, trainingid)
values (34634813, 420);
insert into PARTICIPANT (id, trainingid)
values (33072236, 397);
insert into PARTICIPANT (id, trainingid)
values (32636168, 487);
insert into PARTICIPANT (id, trainingid)
values (35301028, 286);
insert into PARTICIPANT (id, trainingid)
values (34283536, 230);
insert into PARTICIPANT (id, trainingid)
values (35313141, 159);
insert into PARTICIPANT (id, trainingid)
values (32951106, 137);
insert into PARTICIPANT (id, trainingid)
values (33641547, 136);
insert into PARTICIPANT (id, trainingid)
values (33060123, 420);
insert into PARTICIPANT (id, trainingid)
values (36403311, 290);
insert into PARTICIPANT (id, trainingid)
values (35119333, 321);
insert into PARTICIPANT (id, trainingid)
values (35010316, 363);
insert into PARTICIPANT (id, trainingid)
values (32260665, 170);
insert into PARTICIPANT (id, trainingid)
values (35821887, 472);
insert into PARTICIPANT (id, trainingid)
values (33726338, 124);
insert into PARTICIPANT (id, trainingid)
values (34537909, 222);
insert into PARTICIPANT (id, trainingid)
values (34755943, 445);
insert into PARTICIPANT (id, trainingid)
values (34925525, 105);
insert into PARTICIPANT (id, trainingid)
values (33290270, 245);
insert into PARTICIPANT (id, trainingid)
values (33350835, 383);
insert into PARTICIPANT (id, trainingid)
values (34755943, 158);
insert into PARTICIPANT (id, trainingid)
values (32272778, 353);
insert into PARTICIPANT (id, trainingid)
values (36270068, 470);
insert into PARTICIPANT (id, trainingid)
values (35846113, 181);
insert into PARTICIPANT (id, trainingid)
values (35712870, 359);
insert into PARTICIPANT (id, trainingid)
values (34925525, 406);
insert into PARTICIPANT (id, trainingid)
values (35143559, 377);
insert into PARTICIPANT (id, trainingid)
values (33895920, 299);
insert into PARTICIPANT (id, trainingid)
values (33362948, 443);
insert into PARTICIPANT (id, trainingid)
values (32454473, 379);
insert into PARTICIPANT (id, trainingid)
values (32502925, 453);
insert into PARTICIPANT (id, trainingid)
values (36136825, 475);
insert into PARTICIPANT (id, trainingid)
values (36669797, 390);
insert into PARTICIPANT (id, trainingid)
values (35591740, 427);
insert into PARTICIPANT (id, trainingid)
values (36112599, 446);
insert into PARTICIPANT (id, trainingid)
values (35821887, 229);
insert into PARTICIPANT (id, trainingid)
values (34562135, 224);
insert into PARTICIPANT (id, trainingid)
values (33859581, 489);
insert into PARTICIPANT (id, trainingid)
values (33665773, 143);
insert into PARTICIPANT (id, trainingid)
values (33556756, 221);
insert into PARTICIPANT (id, trainingid)
values (34368327, 304);
insert into PARTICIPANT (id, trainingid)
values (32357569, 253);
insert into PARTICIPANT (id, trainingid)
values (34453118, 161);
insert into PARTICIPANT (id, trainingid)
values (32309117, 232);
insert into PARTICIPANT (id, trainingid)
values (36439650, 429);
insert into PARTICIPANT (id, trainingid)
values (36730362, 153);
insert into PARTICIPANT (id, trainingid)
values (32575603, 380);
insert into PARTICIPANT (id, trainingid)
values (34113954, 167);
insert into PARTICIPANT (id, trainingid)
values (36936283, 180);
commit;
prompt 100 records committed...
insert into PARTICIPANT (id, trainingid)
values (34768056, 187);
insert into PARTICIPANT (id, trainingid)
values (32248552, 387);
insert into PARTICIPANT (id, trainingid)
values (33302383, 485);
insert into PARTICIPANT (id, trainingid)
values (34416779, 481);
insert into PARTICIPANT (id, trainingid)
values (32866315, 155);
insert into PARTICIPANT (id, trainingid)
values (33484078, 350);
insert into PARTICIPANT (id, trainingid)
values (35579627, 459);
insert into PARTICIPANT (id, trainingid)
values (35761322, 384);
insert into PARTICIPANT (id, trainingid)
values (35870339, 133);
insert into PARTICIPANT (id, trainingid)
values (36197390, 321);
insert into PARTICIPANT (id, trainingid)
values (34937638, 253);
insert into PARTICIPANT (id, trainingid)
values (36681910, 283);
insert into PARTICIPANT (id, trainingid)
values (33169140, 361);
insert into PARTICIPANT (id, trainingid)
values (33702112, 356);
insert into PARTICIPANT (id, trainingid)
values (35688644, 427);
insert into PARTICIPANT (id, trainingid)
values (35482723, 347);
insert into PARTICIPANT (id, trainingid)
values (34949751, 164);
insert into PARTICIPANT (id, trainingid)
values (34416779, 267);
insert into PARTICIPANT (id, trainingid)
values (32502925, 469);
insert into PARTICIPANT (id, trainingid)
values (36052034, 186);
insert into PARTICIPANT (id, trainingid)
values (32212213, 296);
insert into PARTICIPANT (id, trainingid)
values (34150293, 195);
insert into PARTICIPANT (id, trainingid)
values (35422158, 351);
insert into PARTICIPANT (id, trainingid)
values (35494836, 134);
insert into PARTICIPANT (id, trainingid)
values (36015695, 304);
insert into PARTICIPANT (id, trainingid)
values (36015695, 410);
insert into PARTICIPANT (id, trainingid)
values (33532530, 307);
insert into PARTICIPANT (id, trainingid)
values (35070881, 166);
insert into PARTICIPANT (id, trainingid)
values (35773435, 123);
insert into PARTICIPANT (id, trainingid)
values (35422158, 335);
insert into PARTICIPANT (id, trainingid)
values (32720959, 441);
insert into PARTICIPANT (id, trainingid)
values (35688644, 428);
insert into PARTICIPANT (id, trainingid)
values (36585006, 295);
insert into PARTICIPANT (id, trainingid)
values (33302383, 393);
insert into PARTICIPANT (id, trainingid)
values (36863605, 157);
insert into PARTICIPANT (id, trainingid)
values (32454473, 202);
insert into PARTICIPANT (id, trainingid)
values (35155672, 412);
insert into PARTICIPANT (id, trainingid)
values (33871694, 286);
insert into PARTICIPANT (id, trainingid)
values (35410045, 211);
insert into PARTICIPANT (id, trainingid)
values (32575603, 494);
insert into PARTICIPANT (id, trainingid)
values (35870339, 181);
insert into PARTICIPANT (id, trainingid)
values (36597119, 490);
insert into PARTICIPANT (id, trainingid)
values (35991469, 198);
insert into PARTICIPANT (id, trainingid)
values (33593095, 246);
insert into PARTICIPANT (id, trainingid)
values (34671152, 319);
insert into PARTICIPANT (id, trainingid)
values (37033187, 179);
insert into PARTICIPANT (id, trainingid)
values (35591740, 252);
insert into PARTICIPANT (id, trainingid)
values (34634813, 166);
insert into PARTICIPANT (id, trainingid)
values (33253931, 473);
insert into PARTICIPANT (id, trainingid)
values (36342746, 380);
insert into PARTICIPANT (id, trainingid)
values (36899944, 178);
insert into PARTICIPANT (id, trainingid)
values (37008961, 200);
insert into PARTICIPANT (id, trainingid)
values (35652305, 160);
insert into PARTICIPANT (id, trainingid)
values (35458497, 338);
insert into PARTICIPANT (id, trainingid)
values (32200100, 409);
insert into PARTICIPANT (id, trainingid)
values (34259310, 211);
insert into PARTICIPANT (id, trainingid)
values (36451763, 334);
insert into PARTICIPANT (id, trainingid)
values (33132801, 325);
insert into PARTICIPANT (id, trainingid)
values (32381795, 384);
insert into PARTICIPANT (id, trainingid)
values (35204124, 295);
insert into PARTICIPANT (id, trainingid)
values (34901299, 384);
insert into PARTICIPANT (id, trainingid)
values (32745185, 457);
insert into PARTICIPANT (id, trainingid)
values (34489457, 356);
insert into PARTICIPANT (id, trainingid)
values (32793637, 312);
insert into PARTICIPANT (id, trainingid)
values (35834000, 146);
insert into PARTICIPANT (id, trainingid)
values (33762677, 345);
insert into PARTICIPANT (id, trainingid)
values (34392553, 220);
insert into PARTICIPANT (id, trainingid)
values (34998203, 257);
insert into PARTICIPANT (id, trainingid)
values (32890541, 151);
insert into PARTICIPANT (id, trainingid)
values (36681910, 372);
insert into PARTICIPANT (id, trainingid)
values (36161051, 171);
insert into PARTICIPANT (id, trainingid)
values (36681910, 238);
insert into PARTICIPANT (id, trainingid)
values (36742475, 490);
insert into PARTICIPANT (id, trainingid)
values (32720959, 189);
insert into PARTICIPANT (id, trainingid)
values (33786903, 381);
insert into PARTICIPANT (id, trainingid)
values (34174519, 493);
insert into PARTICIPANT (id, trainingid)
values (32212213, 308);
insert into PARTICIPANT (id, trainingid)
values (35979356, 441);
insert into PARTICIPANT (id, trainingid)
values (33302383, 109);
insert into PARTICIPANT (id, trainingid)
values (34077615, 222);
insert into PARTICIPANT (id, trainingid)
values (33811129, 319);
insert into PARTICIPANT (id, trainingid)
values (32527151, 115);
insert into PARTICIPANT (id, trainingid)
values (32720959, 227);
insert into PARTICIPANT (id, trainingid)
values (36924170, 456);
insert into PARTICIPANT (id, trainingid)
values (36124712, 357);
insert into PARTICIPANT (id, trainingid)
values (35058768, 315);
insert into PARTICIPANT (id, trainingid)
values (32563490, 379);
insert into PARTICIPANT (id, trainingid)
values (34537909, 135);
insert into PARTICIPANT (id, trainingid)
values (33653660, 333);
insert into PARTICIPANT (id, trainingid)
values (34925525, 461);
insert into PARTICIPANT (id, trainingid)
values (33459852, 360);
insert into PARTICIPANT (id, trainingid)
values (35422158, 226);
insert into PARTICIPANT (id, trainingid)
values (32418134, 238);
insert into PARTICIPANT (id, trainingid)
values (35628079, 114);
insert into PARTICIPANT (id, trainingid)
values (35082994, 120);
insert into PARTICIPANT (id, trainingid)
values (36064147, 259);
insert into PARTICIPANT (id, trainingid)
values (33980711, 354);
insert into PARTICIPANT (id, trainingid)
values (36948396, 422);
insert into PARTICIPANT (id, trainingid)
values (36839379, 397);
insert into PARTICIPANT (id, trainingid)
values (34889186, 485);
commit;
prompt 200 records committed...
insert into PARTICIPANT (id, trainingid)
values (35591740, 101);
insert into PARTICIPANT (id, trainingid)
values (32708846, 401);
insert into PARTICIPANT (id, trainingid)
values (34973977, 372);
insert into PARTICIPANT (id, trainingid)
values (35615966, 466);
insert into PARTICIPANT (id, trainingid)
values (36621345, 302);
insert into PARTICIPANT (id, trainingid)
values (36694023, 426);
insert into PARTICIPANT (id, trainingid)
values (35943017, 348);
insert into PARTICIPANT (id, trainingid)
values (35179898, 487);
insert into PARTICIPANT (id, trainingid)
values (36851492, 479);
insert into PARTICIPANT (id, trainingid)
values (34949751, 160);
insert into PARTICIPANT (id, trainingid)
values (32369682, 257);
insert into PARTICIPANT (id, trainingid)
values (34937638, 190);
insert into PARTICIPANT (id, trainingid)
values (36282181, 368);
insert into PARTICIPANT (id, trainingid)
values (34174519, 105);
insert into PARTICIPANT (id, trainingid)
values (33932259, 387);
insert into PARTICIPANT (id, trainingid)
values (36500215, 439);
insert into PARTICIPANT (id, trainingid)
values (36475989, 465);
insert into PARTICIPANT (id, trainingid)
values (36415424, 369);
insert into PARTICIPANT (id, trainingid)
values (36718249, 346);
insert into PARTICIPANT (id, trainingid)
values (36585006, 404);
insert into PARTICIPANT (id, trainingid)
values (33641547, 392);
insert into PARTICIPANT (id, trainingid)
values (32309117, 274);
insert into PARTICIPANT (id, trainingid)
values (32854202, 230);
insert into PARTICIPANT (id, trainingid)
values (35506949, 273);
insert into PARTICIPANT (id, trainingid)
values (32696733, 289);
insert into PARTICIPANT (id, trainingid)
values (36948396, 374);
insert into PARTICIPANT (id, trainingid)
values (36233729, 441);
insert into PARTICIPANT (id, trainingid)
values (35119333, 391);
insert into PARTICIPANT (id, trainingid)
values (33750564, 435);
insert into PARTICIPANT (id, trainingid)
values (32902654, 107);
insert into PARTICIPANT (id, trainingid)
values (36984735, 109);
insert into PARTICIPANT (id, trainingid)
values (35834000, 421);
insert into PARTICIPANT (id, trainingid)
values (34622700, 288);
insert into PARTICIPANT (id, trainingid)
values (33326609, 266);
insert into PARTICIPANT (id, trainingid)
values (35119333, 150);
insert into PARTICIPANT (id, trainingid)
values (32648281, 126);
insert into PARTICIPANT (id, trainingid)
values (34889186, 156);
insert into PARTICIPANT (id, trainingid)
values (32781524, 305);
insert into PARTICIPANT (id, trainingid)
values (36766701, 146);
insert into PARTICIPANT (id, trainingid)
values (34586361, 189);
insert into PARTICIPANT (id, trainingid)
values (36585006, 285);
insert into PARTICIPANT (id, trainingid)
values (34731717, 455);
insert into PARTICIPANT (id, trainingid)
values (32684620, 254);
insert into PARTICIPANT (id, trainingid)
values (34755943, 244);
insert into PARTICIPANT (id, trainingid)
values (36730362, 185);
insert into PARTICIPANT (id, trainingid)
values (34356214, 279);
insert into PARTICIPANT (id, trainingid)
values (36354859, 131);
insert into PARTICIPANT (id, trainingid)
values (32793637, 137);
insert into PARTICIPANT (id, trainingid)
values (35943017, 163);
insert into PARTICIPANT (id, trainingid)
values (34574248, 444);
insert into PARTICIPANT (id, trainingid)
values (36379085, 492);
insert into PARTICIPANT (id, trainingid)
values (36984735, 418);
insert into PARTICIPANT (id, trainingid)
values (33968598, 301);
insert into PARTICIPANT (id, trainingid)
values (36803040, 121);
insert into PARTICIPANT (id, trainingid)
values (32769411, 492);
insert into PARTICIPANT (id, trainingid)
values (36439650, 447);
insert into PARTICIPANT (id, trainingid)
values (36463876, 439);
insert into PARTICIPANT (id, trainingid)
values (35676531, 407);
insert into PARTICIPANT (id, trainingid)
values (36003582, 130);
insert into PARTICIPANT (id, trainingid)
values (35373706, 135);
insert into PARTICIPANT (id, trainingid)
values (34186632, 404);
insert into PARTICIPANT (id, trainingid)
values (32236439, 178);
insert into PARTICIPANT (id, trainingid)
values (33677886, 477);
insert into PARTICIPANT (id, trainingid)
values (33096462, 103);
insert into PARTICIPANT (id, trainingid)
values (32212213, 441);
insert into PARTICIPANT (id, trainingid)
values (36560780, 361);
insert into PARTICIPANT (id, trainingid)
values (36173164, 136);
insert into PARTICIPANT (id, trainingid)
values (32248552, 269);
insert into PARTICIPANT (id, trainingid)
values (36972622, 292);
insert into PARTICIPANT (id, trainingid)
values (35555401, 232);
insert into PARTICIPANT (id, trainingid)
values (36609232, 321);
insert into PARTICIPANT (id, trainingid)
values (36403311, 463);
insert into PARTICIPANT (id, trainingid)
values (35179898, 480);
insert into PARTICIPANT (id, trainingid)
values (32442360, 143);
insert into PARTICIPANT (id, trainingid)
values (35373706, 160);
insert into PARTICIPANT (id, trainingid)
values (32248552, 258);
insert into PARTICIPANT (id, trainingid)
values (32393908, 234);
insert into PARTICIPANT (id, trainingid)
values (36996848, 269);
insert into PARTICIPANT (id, trainingid)
values (37021074, 229);
insert into PARTICIPANT (id, trainingid)
values (33762677, 438);
insert into PARTICIPANT (id, trainingid)
values (34949751, 428);
insert into PARTICIPANT (id, trainingid)
values (35446384, 183);
insert into PARTICIPANT (id, trainingid)
values (34174519, 303);
insert into PARTICIPANT (id, trainingid)
values (33568869, 477);
insert into PARTICIPANT (id, trainingid)
values (33411400, 349);
insert into PARTICIPANT (id, trainingid)
values (36936283, 456);
insert into PARTICIPANT (id, trainingid)
values (36560780, 142);
insert into PARTICIPANT (id, trainingid)
values (35615966, 461);
insert into PARTICIPANT (id, trainingid)
values (35979356, 292);
insert into PARTICIPANT (id, trainingid)
values (36803040, 280);
insert into PARTICIPANT (id, trainingid)
values (33702112, 494);
insert into PARTICIPANT (id, trainingid)
values (33726338, 214);
insert into PARTICIPANT (id, trainingid)
values (35591740, 375);
insert into PARTICIPANT (id, trainingid)
values (32224326, 319);
insert into PARTICIPANT (id, trainingid)
values (36657684, 323);
insert into PARTICIPANT (id, trainingid)
values (32805750, 468);
insert into PARTICIPANT (id, trainingid)
values (36681910, 387);
insert into PARTICIPANT (id, trainingid)
values (36839379, 379);
insert into PARTICIPANT (id, trainingid)
values (34101841, 267);
insert into PARTICIPANT (id, trainingid)
values (35264689, 445);
commit;
prompt 300 records committed...
insert into PARTICIPANT (id, trainingid)
values (34973977, 250);
insert into PARTICIPANT (id, trainingid)
values (36524441, 314);
insert into PARTICIPANT (id, trainingid)
values (37033187, 320);
insert into PARTICIPANT (id, trainingid)
values (36209503, 270);
insert into PARTICIPANT (id, trainingid)
values (32769411, 316);
insert into PARTICIPANT (id, trainingid)
values (36124712, 143);
insert into PARTICIPANT (id, trainingid)
values (33048010, 134);
insert into PARTICIPANT (id, trainingid)
values (32200100, 208);
insert into PARTICIPANT (id, trainingid)
values (36270068, 282);
insert into PARTICIPANT (id, trainingid)
values (32745185, 205);
insert into PARTICIPANT (id, trainingid)
values (34150293, 352);
insert into PARTICIPANT (id, trainingid)
values (34053389, 327);
insert into PARTICIPANT (id, trainingid)
values (35131446, 338);
insert into PARTICIPANT (id, trainingid)
values (36463876, 129);
insert into PARTICIPANT (id, trainingid)
values (33956485, 162);
insert into PARTICIPANT (id, trainingid)
values (35058768, 181);
insert into PARTICIPANT (id, trainingid)
values (36778814, 128);
insert into PARTICIPANT (id, trainingid)
values (36936283, 236);
insert into PARTICIPANT (id, trainingid)
values (34307762, 277);
insert into PARTICIPANT (id, trainingid)
values (36439650, 126);
insert into PARTICIPANT (id, trainingid)
values (34392553, 349);
insert into PARTICIPANT (id, trainingid)
values (36887831, 162);
insert into PARTICIPANT (id, trainingid)
values (34671152, 143);
insert into PARTICIPANT (id, trainingid)
values (33144914, 253);
insert into PARTICIPANT (id, trainingid)
values (34586361, 166);
insert into PARTICIPANT (id, trainingid)
values (36221616, 308);
insert into PARTICIPANT (id, trainingid)
values (32648281, 167);
insert into PARTICIPANT (id, trainingid)
values (32636168, 153);
insert into PARTICIPANT (id, trainingid)
values (33290270, 454);
insert into PARTICIPANT (id, trainingid)
values (34622700, 114);
insert into PARTICIPANT (id, trainingid)
values (35773435, 175);
insert into PARTICIPANT (id, trainingid)
values (34077615, 302);
insert into PARTICIPANT (id, trainingid)
values (36742475, 471);
insert into PARTICIPANT (id, trainingid)
values (33290270, 356);
insert into PARTICIPANT (id, trainingid)
values (35967243, 489);
insert into PARTICIPANT (id, trainingid)
values (35579627, 272);
insert into PARTICIPANT (id, trainingid)
values (35531175, 345);
insert into PARTICIPANT (id, trainingid)
values (35664418, 274);
insert into PARTICIPANT (id, trainingid)
values (34113954, 435);
insert into PARTICIPANT (id, trainingid)
values (35761322, 168);
insert into PARTICIPANT (id, trainingid)
values (33496191, 193);
insert into PARTICIPANT (id, trainingid)
values (32805750, 318);
insert into PARTICIPANT (id, trainingid)
values (36899944, 273);
insert into PARTICIPANT (id, trainingid)
values (34356214, 493);
insert into PARTICIPANT (id, trainingid)
values (34501570, 269);
insert into PARTICIPANT (id, trainingid)
values (36270068, 125);
insert into PARTICIPANT (id, trainingid)
values (35906678, 153);
insert into PARTICIPANT (id, trainingid)
values (36851492, 429);
insert into PARTICIPANT (id, trainingid)
values (35579627, 127);
insert into PARTICIPANT (id, trainingid)
values (32587716, 116);
insert into PARTICIPANT (id, trainingid)
values (36645571, 492);
insert into PARTICIPANT (id, trainingid)
values (33859581, 155);
insert into PARTICIPANT (id, trainingid)
values (36076260, 413);
insert into PARTICIPANT (id, trainingid)
values (33641547, 321);
insert into PARTICIPANT (id, trainingid)
values (35785548, 185);
insert into PARTICIPANT (id, trainingid)
values (32951106, 377);
insert into PARTICIPANT (id, trainingid)
values (33895920, 489);
insert into PARTICIPANT (id, trainingid)
values (34235084, 428);
insert into PARTICIPANT (id, trainingid)
values (33823242, 233);
insert into PARTICIPANT (id, trainingid)
values (36318520, 296);
insert into PARTICIPANT (id, trainingid)
values (32805750, 270);
insert into PARTICIPANT (id, trainingid)
values (36439650, 258);
insert into PARTICIPANT (id, trainingid)
values (34719604, 395);
insert into PARTICIPANT (id, trainingid)
values (36790927, 391);
insert into PARTICIPANT (id, trainingid)
values (36803040, 296);
insert into PARTICIPANT (id, trainingid)
values (34344101, 264);
insert into PARTICIPANT (id, trainingid)
values (32563490, 475);
insert into PARTICIPANT (id, trainingid)
values (36318520, 420);
insert into PARTICIPANT (id, trainingid)
values (36657684, 453);
insert into PARTICIPANT (id, trainingid)
values (33605208, 222);
insert into PARTICIPANT (id, trainingid)
values (35591740, 312);
insert into PARTICIPANT (id, trainingid)
values (34646926, 333);
insert into PARTICIPANT (id, trainingid)
values (35070881, 140);
insert into PARTICIPANT (id, trainingid)
values (36209503, 264);
insert into PARTICIPANT (id, trainingid)
values (36585006, 122);
insert into PARTICIPANT (id, trainingid)
values (32284891, 301);
insert into PARTICIPANT (id, trainingid)
values (34755943, 116);
insert into PARTICIPANT (id, trainingid)
values (36609232, 460);
insert into PARTICIPANT (id, trainingid)
values (35555401, 221);
insert into PARTICIPANT (id, trainingid)
values (32200100, 136);
insert into PARTICIPANT (id, trainingid)
values (35410045, 453);
insert into PARTICIPANT (id, trainingid)
values (36076260, 485);
insert into PARTICIPANT (id, trainingid)
values (33714225, 159);
insert into PARTICIPANT (id, trainingid)
values (36924170, 388);
insert into PARTICIPANT (id, trainingid)
values (35737096, 326);
insert into PARTICIPANT (id, trainingid)
values (35143559, 231);
insert into PARTICIPANT (id, trainingid)
values (33714225, 410);
insert into PARTICIPANT (id, trainingid)
values (32575603, 162);
insert into PARTICIPANT (id, trainingid)
values (36899944, 259);
insert into PARTICIPANT (id, trainingid)
values (34174519, 440);
insert into PARTICIPANT (id, trainingid)
values (34235084, 133);
insert into PARTICIPANT (id, trainingid)
values (32587716, 363);
insert into PARTICIPANT (id, trainingid)
values (35494836, 406);
insert into PARTICIPANT (id, trainingid)
values (35410045, 360);
insert into PARTICIPANT (id, trainingid)
values (33362948, 161);
insert into PARTICIPANT (id, trainingid)
values (35737096, 363);
insert into PARTICIPANT (id, trainingid)
values (34852847, 444);
insert into PARTICIPANT (id, trainingid)
values (36875718, 424);
insert into PARTICIPANT (id, trainingid)
values (35834000, 409);
commit;
prompt 399 records loaded
prompt Loading PUPIL...
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749715, 'Stephen', 'Hall', to_date('18-07-2016', 'dd-mm-yyyy'), 'D5', 'M', 585779127, 1000000060, 'Peanuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749716, 'Charlize', 'Peebles', to_date('20-06-1986', 'dd-mm-yyyy'), 'A7', 'F', 543462156, 1000000396, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749717, 'Stevie', 'Tankard', to_date('05-01-1994', 'dd-mm-yyyy'), 'D1', 'M', 502101987, 1000000044, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749718, 'Nickel', 'Caldwell', to_date('30-06-1989', 'dd-mm-yyyy'), 'H4', 'F', 553496669, 1000000195, 'Tree Nuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749719, 'Spike', 'Janssen', to_date('27-03-2022', 'dd-mm-yyyy'), 'G7', 'F', 502778139, 1000000368, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749720, 'Suzi', 'MacIsaac', to_date('27-05-1995', 'dd-mm-yyyy'), 'J4', 'F', 526555133, 1000000142, 'Peanuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749721, 'Hilton', 'Cross', to_date('21-03-2024', 'dd-mm-yyyy'), 'L5', 'M', 513196675, 1000000189, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749722, 'Ahmad', 'Sayer', to_date('20-03-2008', 'dd-mm-yyyy'), 'B4', 'F', 572348964, 1000000200, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749723, 'Lisa', 'Mattea', to_date('30-06-2021', 'dd-mm-yyyy'), 'J9', 'F', 502193231, 1000000269, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749724, 'Sydney', 'Scheider', to_date('09-11-2010', 'dd-mm-yyyy'), 'C4', 'F', 546889553, 1000000282, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749725, 'Lloyd', 'Bates', to_date('27-11-2004', 'dd-mm-yyyy'), 'F3', 'M', 582338300, 1000000061, 'Gluten');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749726, 'Nik', 'Tanon', to_date('05-11-2022', 'dd-mm-yyyy'), 'J6', 'F', 573280866, 1000000194, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749727, 'Lennie', 'Chestnut', to_date('30-10-2021', 'dd-mm-yyyy'), 'L5', 'M', 566653468, 1000000331, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749728, 'Hope', 'Shue', to_date('10-08-2017', 'dd-mm-yyyy'), 'E2', 'F', 528955483, 1000000386, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749729, 'Julianne', 'Cagle', to_date('19-05-2012', 'dd-mm-yyyy'), 'J9', 'M', 544321687, 1000000337, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749730, 'Helen', 'urban', to_date('14-11-1995', 'dd-mm-yyyy'), 'C3', 'F', 542218204, 1000000094, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749731, 'Judge', 'McIntyre', to_date('30-07-1990', 'dd-mm-yyyy'), 'K1', 'F', 559388042, 1000000219, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749732, 'Rosanne', 'Blossoms', to_date('19-10-2023', 'dd-mm-yyyy'), 'J2', 'M', 585333434, 1000000040, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749733, 'Susan', 'Frakes', to_date('12-11-1987', 'dd-mm-yyyy'), 'H2', 'F', 537276568, 1000000265, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749734, 'Thelma', 'Robards', to_date('14-12-2010', 'dd-mm-yyyy'), 'F9', 'M', 578381810, 1000000257, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749735, 'Vin', 'Lynskey', to_date('03-03-2013', 'dd-mm-yyyy'), 'J4', 'F', 575113730, 1000000363, 'Shellfish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749736, 'Larnelle', 'Beckinsale', to_date('19-04-1982', 'dd-mm-yyyy'), 'G5', 'F', 572030478, 1000000298, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749737, 'Larnelle', 'Dreyfuss', to_date('25-05-2013', 'dd-mm-yyyy'), 'L1', 'F', 524912631, 1000000098, 'Fish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749738, 'Cledus', 'McGregor', to_date('12-10-1990', 'dd-mm-yyyy'), 'G3', 'F', 502022563, 1000000280, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749739, 'Alfie', 'Suchet', to_date('26-02-2012', 'dd-mm-yyyy'), 'K6', 'F', 545696449, 1000000390, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749740, 'Nora', 'Crowe', to_date('27-07-1984', 'dd-mm-yyyy'), 'B3', 'M', 534907192, 1000000289, 'Peanuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749741, 'Guy', 'Fariq', to_date('25-04-2008', 'dd-mm-yyyy'), 'H8', 'F', 543187435, 1000000038, 'Dairy');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749742, 'Marley', 'Crow', to_date('02-04-2019', 'dd-mm-yyyy'), 'C4', 'F', 531114446, 1000000173, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749743, 'Dabney', 'Bush', to_date('18-07-2023', 'dd-mm-yyyy'), 'B2', 'F', 561821613, 1000000045, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749744, 'Daryle', 'Shannon', to_date('28-05-1992', 'dd-mm-yyyy'), 'A2', 'M', 589242296, 1000000010, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749745, 'Geoffrey', 'Caviezel', to_date('11-05-1999', 'dd-mm-yyyy'), 'E4', 'F', 565131538, 1000000345, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749746, 'Lily', 'Barrymore', to_date('19-12-1982', 'dd-mm-yyyy'), 'A3', 'F', 541177482, 1000000118, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749747, 'Geoffrey', 'Mulroney', to_date('27-05-2009', 'dd-mm-yyyy'), 'C3', 'M', 501032636, 1000000275, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749748, 'Maxine', 'Pony', to_date('15-04-1985', 'dd-mm-yyyy'), 'F4', 'F', 549731852, 1000000304, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749749, 'Carrie-Anne', 'Garofalo', to_date('24-05-1993', 'dd-mm-yyyy'), 'A5', 'M', 579815238, 1000000140, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749750, 'Natasha', 'Ramirez', to_date('03-11-2015', 'dd-mm-yyyy'), 'L1', 'M', 514652427, 1000000026, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749751, 'Wade', 'Richardson', to_date('20-08-2020', 'dd-mm-yyyy'), 'B8', 'M', 534746994, 1000000381, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749752, 'Shelby', 'Dushku', to_date('25-12-1988', 'dd-mm-yyyy'), 'E7', 'M', 505469925, 1000000226, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749753, 'Ruth', 'Watson', to_date('28-05-2005', 'dd-mm-yyyy'), 'L8', 'F', 571691282, 1000000006, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749754, 'Regina', 'Ryder', to_date('14-09-1994', 'dd-mm-yyyy'), 'L9', 'F', 527499099, 1000000164, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749755, 'Anthony', 'Palminteri', to_date('21-07-2022', 'dd-mm-yyyy'), 'D7', 'F', 585109185, 1000000150, 'Wheat');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749756, 'Natasha', 'Barkin', to_date('29-09-1995', 'dd-mm-yyyy'), 'F1', 'M', 513707550, 1000000167, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749757, 'Eliza', 'Hector', to_date('23-08-2004', 'dd-mm-yyyy'), 'J1', 'F', 567797931, 1000000028, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749758, 'Allan', 'White', to_date('08-05-1992', 'dd-mm-yyyy'), 'C6', 'F', 551940215, 1000000334, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749759, 'Harold', 'McGinley', to_date('19-11-1996', 'dd-mm-yyyy'), 'D9', 'M', 503789988, 1000000015, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749760, 'Hugh', 'De Niro', to_date('26-01-2020', 'dd-mm-yyyy'), 'E3', 'M', 511436898, 1000000089, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749761, 'Nicole', 'Coltrane', to_date('06-12-1997', 'dd-mm-yyyy'), 'E9', 'M', 525556750, 1000000022, 'Eggs');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749762, 'Drew', 'Kennedy', to_date('04-08-2002', 'dd-mm-yyyy'), 'K1', 'M', 512522606, 1000000085, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749763, 'Suzanne', 'Rizzo', to_date('28-01-2011', 'dd-mm-yyyy'), 'E1', 'F', 513091379, 1000000240, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749764, 'Jeremy', 'Green', to_date('12-05-2011', 'dd-mm-yyyy'), 'I6', 'M', 587097521, 1000000154, 'Gluten');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749765, 'Alessandro', 'Valentin', to_date('10-11-1990', 'dd-mm-yyyy'), 'F3', 'F', 546149502, 1000000363, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749766, 'Trini', 'Ruffalo', to_date('04-11-2020', 'dd-mm-yyyy'), 'I6', 'M', 545917697, 1000000152, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749767, 'Tia', 'Doucette', to_date('05-01-2001', 'dd-mm-yyyy'), 'H4', 'M', 582966492, 1000000187, 'Shellfish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749768, 'Lara', 'Evett', to_date('22-01-2023', 'dd-mm-yyyy'), 'E6', 'F', 524951525, 1000000091, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749769, 'Mary Beth', 'Davies', to_date('26-07-2023', 'dd-mm-yyyy'), 'I7', 'F', 581708516, 1000000389, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749770, 'Solomon', 'Arkin', to_date('05-02-2018', 'dd-mm-yyyy'), 'A3', 'F', 514133111, 1000000046, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749771, 'Nicky', 'Janney', to_date('18-05-2003', 'dd-mm-yyyy'), 'A6', 'F', 543813992, 1000000288, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749772, 'Roddy', 'Dzundza', to_date('08-07-1981', 'dd-mm-yyyy'), 'J4', 'M', 539924582, 1000000007, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749773, 'Nickel', 'Rowlands', to_date('16-08-1999', 'dd-mm-yyyy'), 'B5', 'M', 586804903, 1000000062, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749774, 'Phil', 'Warden', to_date('14-05-2024', 'dd-mm-yyyy'), 'D5', 'F', 582057291, 1000000089, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749775, 'Adina', 'Shocked', to_date('22-04-1983', 'dd-mm-yyyy'), 'H1', 'M', 528156234, 1000000236, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749776, 'Ronny', 'Melvin', to_date('18-03-2010', 'dd-mm-yyyy'), 'B3', 'F', 582959626, 1000000079, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749777, 'Jody', 'Craddock', to_date('27-03-2016', 'dd-mm-yyyy'), 'H4', 'M', 563969011, 1000000038, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749778, 'Edgar', 'Chilton', to_date('05-03-2015', 'dd-mm-yyyy'), 'K3', 'F', 531508994, 1000000398, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749779, 'Nelly', 'Lange', to_date('24-09-2015', 'dd-mm-yyyy'), 'H8', 'M', 567560592, 1000000128, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749780, 'Machine', 'Feuerstein', to_date('22-07-2007', 'dd-mm-yyyy'), 'C6', 'M', 557180119, 1000000377, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749781, 'Madeleine', 'Ellis', to_date('08-06-2002', 'dd-mm-yyyy'), 'F5', 'M', 551227465, 1000000012, 'Gluten');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749782, 'Elijah', 'Whitley', to_date('03-05-2017', 'dd-mm-yyyy'), 'E9', 'M', 536213555, 1000000396, 'Peanuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749783, 'Joseph', 'Gandolfini', to_date('20-05-1988', 'dd-mm-yyyy'), 'E8', 'M', 516413321, 1000000255, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749784, 'Bridget', 'Makowicz', to_date('29-12-1989', 'dd-mm-yyyy'), 'D9', 'M', 509409770, 1000000088, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749785, 'Curt', 'O''Neal', to_date('08-06-2018', 'dd-mm-yyyy'), 'B9', 'M', 516891197, 1000000175, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749786, 'Charlton', 'Carlyle', to_date('15-05-2016', 'dd-mm-yyyy'), 'L1', 'F', 525377770, 1000000212, 'Fish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749787, 'Bernard', 'Van Shelton', to_date('13-05-2007', 'dd-mm-yyyy'), 'F4', 'M', 501405336, 1000000268, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749788, 'Latin', 'Cromwell', to_date('02-10-2009', 'dd-mm-yyyy'), 'E5', 'M', 509845566, 1000000262, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749789, 'Kris', 'Dillon', to_date('07-08-2000', 'dd-mm-yyyy'), 'K9', 'F', 548078821, 1000000372, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749790, 'Keanu', 'Fariq', to_date('11-02-2015', 'dd-mm-yyyy'), 'E4', 'M', 563785299, 1000000116, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749791, 'Pierce', 'Patton', to_date('22-10-1983', 'dd-mm-yyyy'), 'A6', 'F', 518839282, 1000000261, 'Fish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749792, 'Mitchell', 'Crudup', to_date('23-03-1980', 'dd-mm-yyyy'), 'C5', 'M', 507931006, 1000000208, 'Latex');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749793, 'Pat', 'Mac', to_date('24-01-2016', 'dd-mm-yyyy'), 'F2', 'M', 575709737, 1000000175, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749794, 'Ray', 'Starr', to_date('13-07-1981', 'dd-mm-yyyy'), 'B7', 'M', 506584445, 1000000316, 'Fish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749795, 'Tobey', 'Lynne', to_date('19-02-2005', 'dd-mm-yyyy'), 'I7', 'F', 559117264, 1000000016, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749796, 'Tia', 'Beck', to_date('12-11-2019', 'dd-mm-yyyy'), 'C5', 'M', 554726397, 1000000144, 'Dairy');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749797, 'Edward', 'Coughlan', to_date('07-08-2011', 'dd-mm-yyyy'), 'A4', 'F', 517951332, 1000000139, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749798, 'Glenn', 'Schwimmer', to_date('21-01-2013', 'dd-mm-yyyy'), 'I8', 'M', 504190192, 1000000261, 'Latex');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749799, 'Boz', 'Harary', to_date('07-09-1991', 'dd-mm-yyyy'), 'H8', 'F', 554018619, 1000000210, 'Latex');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749800, 'Talvin', 'Mac', to_date('18-12-2023', 'dd-mm-yyyy'), 'G5', 'M', 525323100, 1000000332, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749801, 'Jody', 'Abraham', to_date('05-08-2009', 'dd-mm-yyyy'), 'H5', 'F', 523354667, 1000000269, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749802, 'Henry', 'Gilley', to_date('01-06-1988', 'dd-mm-yyyy'), 'D5', 'F', 534972378, 1000000280, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749803, 'Judi', 'Bening', to_date('15-06-1997', 'dd-mm-yyyy'), 'J2', 'F', 586627100, 1000000036, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749804, 'Raul', 'Davis', to_date('07-02-1987', 'dd-mm-yyyy'), 'E2', 'F', 547098600, 1000000242, 'Peanuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749805, 'Ritchie', 'Johnson', to_date('19-05-1980', 'dd-mm-yyyy'), 'H3', 'M', 589163004, 1000000319, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749806, 'Gabriel', 'Pepper', to_date('08-08-1990', 'dd-mm-yyyy'), 'I1', 'F', 573651873, 1000000369, 'Fish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749807, 'Danny', 'Marx', to_date('16-07-1989', 'dd-mm-yyyy'), 'B4', 'F', 542016850, 1000000035, 'Shellfish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749808, 'Jeremy', 'Murdock', to_date('09-10-1985', 'dd-mm-yyyy'), 'I8', 'F', 536859265, 1000000386, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749809, 'Meg', 'Hornsby', to_date('24-02-2010', 'dd-mm-yyyy'), 'D3', 'M', 584527569, 1000000301, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749810, 'Radney', 'Goodall', to_date('14-07-1993', 'dd-mm-yyyy'), 'D8', 'F', 519576641, 1000000182, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749811, 'Maria', 'Salt', to_date('12-10-1997', 'dd-mm-yyyy'), 'J1', 'F', 539056545, 1000000210, 'Eggs');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749812, 'Maceo', 'Berkeley', to_date('11-04-1987', 'dd-mm-yyyy'), 'K1', 'M', 518167674, 1000000166, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749813, 'Hope', 'Lipnicki', to_date('09-12-2015', 'dd-mm-yyyy'), 'B1', 'M', 571614912, 1000000046, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749814, 'Humberto', 'Lapointe', to_date('10-11-1984', 'dd-mm-yyyy'), 'I7', 'F', 539299559, 1000000092, 'none');
commit;
prompt 100 records committed...
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749815, 'Dom', 'Shannon', to_date('15-10-1980', 'dd-mm-yyyy'), 'A4', 'F', 586941061, 1000000203, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749816, 'Amy', 'Ifans', to_date('05-01-2018', 'dd-mm-yyyy'), 'G7', 'F', 573401400, 1000000337, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749817, 'Matthew', 'LaBelle', to_date('10-01-2005', 'dd-mm-yyyy'), 'F8', 'M', 565840243, 1000000103, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749818, 'Shelby', 'LaBelle', to_date('23-04-2018', 'dd-mm-yyyy'), 'I7', 'M', 581129873, 1000000201, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749819, 'Nathan', 'Tomei', to_date('31-10-2010', 'dd-mm-yyyy'), 'H2', 'F', 535310077, 1000000178, 'Latex');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749820, 'Ozzy', 'Latifah', to_date('06-11-1989', 'dd-mm-yyyy'), 'K3', 'M', 506340102, 1000000164, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749821, 'Janice', 'Gaynor', to_date('11-01-2019', 'dd-mm-yyyy'), 'L3', 'F', 555711123, 1000000011, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749822, 'Trick', 'Morrison', to_date('16-04-2011', 'dd-mm-yyyy'), 'C9', 'M', 577580155, 1000000248, 'Latex');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749823, 'Amanda', 'Hauer', to_date('13-05-2012', 'dd-mm-yyyy'), 'K7', 'F', 578062947, 1000000368, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749824, 'Roberta', 'Mathis', to_date('20-10-2006', 'dd-mm-yyyy'), 'B6', 'M', 576327821, 1000000293, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749825, 'Terrence', 'Elizabeth', to_date('27-07-1981', 'dd-mm-yyyy'), 'J4', 'F', 559015877, 1000000341, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749826, 'Jimmy', 'Madsen', to_date('09-06-2004', 'dd-mm-yyyy'), 'J3', 'F', 509880648, 1000000086, 'Eggs');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749827, 'Reese', 'Dench', to_date('17-06-1990', 'dd-mm-yyyy'), 'E5', 'M', 511229248, 1000000020, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749828, 'Chalee', 'Harper', to_date('01-09-1983', 'dd-mm-yyyy'), 'I8', 'M', 515307342, 1000000345, 'Gluten');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749829, 'Beth', 'O''Donnell', to_date('09-01-1991', 'dd-mm-yyyy'), 'A2', 'M', 569341114, 1000000113, 'Wheat');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749830, 'Mae', 'Blackmore', to_date('22-05-2009', 'dd-mm-yyyy'), 'J8', 'M', 532982864, 1000000312, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749831, 'Malcolm', 'Balk', to_date('31-01-2006', 'dd-mm-yyyy'), 'G3', 'F', 507504363, 1000000115, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749832, 'Donna', 'Sevenfold', to_date('18-05-1999', 'dd-mm-yyyy'), 'H7', 'F', 514273499, 1000000055, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749833, 'Thora', 'Hawn', to_date('17-06-2009', 'dd-mm-yyyy'), 'E6', 'F', 543152720, 1000000371, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749834, 'Sammy', 'Clooney', to_date('21-08-2005', 'dd-mm-yyyy'), 'J1', 'F', 522724324, 1000000138, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749835, 'Barry', 'Molina', to_date('26-07-2011', 'dd-mm-yyyy'), 'E5', 'F', 559309479, 1000000291, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749836, 'Tramaine', 'Nicks', to_date('24-06-2016', 'dd-mm-yyyy'), 'E1', 'F', 525942309, 1000000227, 'Peanuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749837, 'Ryan', 'Mahood', to_date('27-10-2000', 'dd-mm-yyyy'), 'E2', 'M', 508924700, 1000000134, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749838, 'Gloria', 'Kudrow', to_date('14-05-1991', 'dd-mm-yyyy'), 'H1', 'F', 511076295, 1000000025, 'Soy');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749839, 'Clay', 'Klugh', to_date('04-01-1982', 'dd-mm-yyyy'), 'A1', 'F', 553485370, 1000000072, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749840, 'Marianne', 'Jane', to_date('26-06-2011', 'dd-mm-yyyy'), 'K5', 'F', 583682790, 1000000147, 'Latex');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749841, 'Mitchell', 'Dreyfuss', to_date('10-01-1981', 'dd-mm-yyyy'), 'H7', 'F', 566050255, 1000000382, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749842, 'Olga', 'Ricci', to_date('17-01-2004', 'dd-mm-yyyy'), 'J2', 'M', 552646413, 1000000029, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749843, 'Mos', 'Tate', to_date('20-11-1988', 'dd-mm-yyyy'), 'L4', 'M', 582979355, 1000000085, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749844, 'Garry', 'Gill', to_date('04-11-2014', 'dd-mm-yyyy'), 'E2', 'F', 551008361, 1000000037, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749845, 'Ricardo', 'Theron', to_date('14-09-1987', 'dd-mm-yyyy'), 'F8', 'F', 561519450, 1000000194, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749846, 'Leo', 'McGinley', to_date('20-05-1993', 'dd-mm-yyyy'), 'C2', 'M', 507858072, 1000000069, 'Soy');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749847, 'Deborah', 'Foley', to_date('08-08-2006', 'dd-mm-yyyy'), 'E2', 'M', 521134780, 1000000126, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749848, 'Vienna', 'Guzman', to_date('25-06-2015', 'dd-mm-yyyy'), 'H6', 'F', 539174673, 1000000094, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749849, 'Dick', 'Guinness', to_date('22-03-1988', 'dd-mm-yyyy'), 'K3', 'F', 562597868, 1000000098, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749850, 'Veruca', 'Teng', to_date('31-07-2018', 'dd-mm-yyyy'), 'D7', 'M', 548478433, 1000000335, 'Dairy');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749851, 'Rebecca', 'Gertner', to_date('02-03-2010', 'dd-mm-yyyy'), 'G2', 'M', 516442427, 1000000373, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749852, 'Chris', 'Hewett', to_date('20-02-2007', 'dd-mm-yyyy'), 'I1', 'F', 558680780, 1000000213, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749853, 'Owen', 'Valentin', to_date('08-12-2022', 'dd-mm-yyyy'), 'D1', 'M', 588990611, 1000000299, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749854, 'Carole', 'Shand', to_date('14-05-2007', 'dd-mm-yyyy'), 'H7', 'F', 549416948, 1000000199, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749855, 'Beverley', 'Macy', to_date('17-01-1999', 'dd-mm-yyyy'), 'J4', 'F', 585863205, 1000000144, 'Latex');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749856, 'Reese', 'Burmester', to_date('02-03-2020', 'dd-mm-yyyy'), 'L7', 'M', 526720483, 1000000051, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749857, 'Andy', 'Osborne', to_date('05-10-2001', 'dd-mm-yyyy'), 'J7', 'M', 575226025, 1000000388, 'Tree Nuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749858, 'Lin', 'Senior', to_date('20-11-2015', 'dd-mm-yyyy'), 'G4', 'F', 562966269, 1000000289, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749859, 'Vern', 'Rossellini', to_date('10-10-1993', 'dd-mm-yyyy'), 'G4', 'M', 575081506, 1000000072, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749860, 'Buddy', 'Emmett', to_date('07-07-1993', 'dd-mm-yyyy'), 'D3', 'F', 509880762, 1000000098, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749861, 'Bonnie', 'Tucker', to_date('30-12-2006', 'dd-mm-yyyy'), 'H1', 'M', 578243532, 1000000138, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749862, 'Ned', 'Griffith', to_date('18-04-1982', 'dd-mm-yyyy'), 'J7', 'M', 503907407, 1000000276, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749863, 'Nicole', 'Reeves', to_date('24-07-2018', 'dd-mm-yyyy'), 'K1', 'F', 538298604, 1000000258, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749864, 'Brooke', 'Macht', to_date('22-12-2019', 'dd-mm-yyyy'), 'G9', 'M', 553634143, 1000000235, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749865, 'Seth', 'Weber', to_date('08-01-2009', 'dd-mm-yyyy'), 'I9', 'M', 532419936, 1000000398, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749866, 'Miranda', 'Hatfield', to_date('25-03-2024', 'dd-mm-yyyy'), 'E1', 'F', 544151034, 1000000204, 'Shellfish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749867, 'Wes', 'Collette', to_date('13-03-2005', 'dd-mm-yyyy'), 'G7', 'M', 579425460, 1000000346, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749868, 'Forest', 'Glenn', to_date('15-07-1996', 'dd-mm-yyyy'), 'F7', 'F', 565421894, 1000000179, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749869, 'Natalie', 'Spiner', to_date('12-06-2003', 'dd-mm-yyyy'), 'B5', 'M', 551518581, 1000000300, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749870, 'Taylor', 'Khan', to_date('29-12-1983', 'dd-mm-yyyy'), 'B2', 'M', 504836780, 1000000254, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749871, 'Ryan', 'Miles', to_date('10-08-2009', 'dd-mm-yyyy'), 'G3', 'F', 585784327, 1000000128, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749872, 'Dwight', 'Lovitz', to_date('20-05-1991', 'dd-mm-yyyy'), 'I3', 'F', 578374904, 1000000377, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749873, 'Ryan', 'Harry', to_date('17-11-1987', 'dd-mm-yyyy'), 'J7', 'F', 572295735, 1000000127, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749874, 'Larnelle', 'Foley', to_date('09-07-2005', 'dd-mm-yyyy'), 'H7', 'F', 557062427, 1000000022, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749875, 'Rueben', 'Scott', to_date('09-12-1986', 'dd-mm-yyyy'), 'B5', 'M', 522678510, 1000000337, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749876, 'Machine', 'Connelly', to_date('05-03-1981', 'dd-mm-yyyy'), 'E5', 'M', 583969146, 1000000241, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749877, 'Emmylou', 'Davis', to_date('11-06-2008', 'dd-mm-yyyy'), 'L6', 'F', 561748574, 1000000166, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749878, 'Parker', 'Brando', to_date('17-01-2024', 'dd-mm-yyyy'), 'H6', 'M', 586664850, 1000000236, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749879, 'Jann', 'DiFranco', to_date('10-07-1983', 'dd-mm-yyyy'), 'H7', 'M', 516439667, 1000000013, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749880, 'Campbell', 'Elliott', to_date('17-02-1981', 'dd-mm-yyyy'), 'C6', 'F', 514162575, 1000000247, 'Fish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749881, 'Brittany', 'Wong', to_date('31-05-1983', 'dd-mm-yyyy'), 'E7', 'M', 509239147, 1000000192, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749882, 'Norm', 'Ontiveros', to_date('07-04-2019', 'dd-mm-yyyy'), 'I1', 'M', 554724595, 1000000031, 'Fish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749883, 'Alicia', 'Branagh', to_date('08-11-2013', 'dd-mm-yyyy'), 'H8', 'F', 515812029, 1000000239, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749884, 'Hookah', 'Malkovich', to_date('22-12-1999', 'dd-mm-yyyy'), 'K8', 'M', 513810350, 1000000284, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749885, 'Tilda', 'Sainte-Marie', to_date('16-01-2001', 'dd-mm-yyyy'), 'L8', 'F', 524978688, 1000000180, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749886, 'Scott', 'Sandoval', to_date('24-09-2002', 'dd-mm-yyyy'), 'E4', 'F', 562715964, 1000000344, 'Shellfish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749887, 'Hilary', 'Tsettos', to_date('04-12-2013', 'dd-mm-yyyy'), 'A5', 'F', 566782902, 1000000377, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749888, 'Vertical', 'Lipnicki', to_date('27-03-2019', 'dd-mm-yyyy'), 'G8', 'M', 546405256, 1000000006, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749889, 'Gavin', 'Fichtner', to_date('14-08-2020', 'dd-mm-yyyy'), 'H4', 'M', 565606660, 1000000003, 'Tree Nuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749890, 'Clarence', 'Rhames', to_date('05-03-2011', 'dd-mm-yyyy'), 'J3', 'M', 547474487, 1000000174, 'Fish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749891, 'First', 'Rizzo', to_date('14-05-2006', 'dd-mm-yyyy'), 'J2', 'M', 588218837, 1000000317, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749892, 'Wade', 'Hart', to_date('24-02-1985', 'dd-mm-yyyy'), 'G4', 'M', 584440186, 1000000237, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749893, 'Chantי', 'Macy', to_date('27-05-2007', 'dd-mm-yyyy'), 'D5', 'M', 563848892, 1000000300, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749894, 'Carl', 'Blackwell', to_date('29-04-1988', 'dd-mm-yyyy'), 'J1', 'M', 501403641, 1000000067, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749895, 'Natalie', 'Heron', to_date('17-05-2001', 'dd-mm-yyyy'), 'L2', 'F', 515916842, 1000000328, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749896, 'Shawn', 'Mraz', to_date('23-04-1990', 'dd-mm-yyyy'), 'C3', 'F', 505939578, 1000000187, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749897, 'Arnold', 'Arnold', to_date('28-06-1986', 'dd-mm-yyyy'), 'G8', 'F', 521489201, 1000000178, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749898, 'Kyra', 'Elizabeth', to_date('05-09-1982', 'dd-mm-yyyy'), 'K6', 'F', 516592717, 1000000041, 'Eggs');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749899, 'Lynette', 'Tempest', to_date('04-08-2013', 'dd-mm-yyyy'), 'I3', 'F', 536930000, 1000000386, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749900, 'Judi', 'Freeman', to_date('20-04-1988', 'dd-mm-yyyy'), 'E1', 'F', 502956667, 1000000041, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749901, 'Toshiro', 'Navarro', to_date('16-12-2000', 'dd-mm-yyyy'), 'I3', 'F', 566138861, 1000000044, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749902, 'Armin', 'Snow', to_date('05-09-1987', 'dd-mm-yyyy'), 'B1', 'F', 544767681, 1000000342, 'Tree Nuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749903, 'Nik', 'Thomas', to_date('04-12-2007', 'dd-mm-yyyy'), 'F6', 'F', 502276881, 1000000126, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749904, 'Natalie', 'Gore', to_date('02-01-1997', 'dd-mm-yyyy'), 'D1', 'F', 555083434, 1000000152, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749905, 'Sally', 'Richards', to_date('03-05-2015', 'dd-mm-yyyy'), 'F2', 'F', 568538302, 1000000011, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749906, 'Isaiah', 'Root', to_date('08-07-2007', 'dd-mm-yyyy'), 'I7', 'F', 578246925, 1000000070, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749907, 'Gaby', 'Curfman', to_date('10-11-1998', 'dd-mm-yyyy'), 'G8', 'M', 511394123, 1000000309, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749908, 'Irene', 'Ferrer', to_date('15-07-2022', 'dd-mm-yyyy'), 'L4', 'M', 502270124, 1000000125, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749909, 'Lindsay', 'Gleeson', to_date('05-06-1994', 'dd-mm-yyyy'), 'G1', 'F', 544375404, 1000000363, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749910, 'Jeroen', 'Herrmann', to_date('22-08-2008', 'dd-mm-yyyy'), 'B4', 'M', 523323776, 1000000299, 'Tree Nuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749911, 'Tramaine', 'Kier', to_date('31-01-2005', 'dd-mm-yyyy'), 'G4', 'F', 538941539, 1000000144, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749912, 'Lorraine', 'Llewelyn', to_date('25-06-2014', 'dd-mm-yyyy'), 'E3', 'M', 502501211, 1000000321, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749913, 'Delbert', 'Scaggs', to_date('08-05-1998', 'dd-mm-yyyy'), 'D1', 'F', 579854776, 1000000031, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749914, 'Nicky', 'Kelly', to_date('16-06-2006', 'dd-mm-yyyy'), 'D5', 'F', 552747633, 1000000280, 'none');
commit;
prompt 200 records committed...
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749915, 'Vertical', 'Chestnut', to_date('06-03-2017', 'dd-mm-yyyy'), 'H3', 'F', 556819152, 1000000053, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749916, 'Marlon', 'Schneider', to_date('13-05-1996', 'dd-mm-yyyy'), 'F1', 'F', 564124686, 1000000109, 'Wheat');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749917, 'Dabney', 'Davidtz', to_date('09-04-2012', 'dd-mm-yyyy'), 'L4', 'M', 514502381, 1000000285, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749918, 'Viggo', 'Madonna', to_date('23-02-2014', 'dd-mm-yyyy'), 'C9', 'M', 545225618, 1000000395, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749919, 'Adina', 'Burstyn', to_date('21-10-2013', 'dd-mm-yyyy'), 'B6', 'M', 576505509, 1000000151, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749920, 'Bridget', 'Lapointe', to_date('25-06-1992', 'dd-mm-yyyy'), 'E4', 'M', 517881530, 1000000169, 'Latex');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749921, 'Julianne', 'Akins', to_date('18-09-1996', 'dd-mm-yyyy'), 'K8', 'M', 506939888, 1000000024, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749922, 'Ben', 'Firth', to_date('10-11-1991', 'dd-mm-yyyy'), 'G4', 'M', 574116605, 1000000071, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749923, 'Wesley', 'Howard', to_date('27-01-1984', 'dd-mm-yyyy'), 'F7', 'F', 515076666, 1000000259, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749924, 'Andrae', 'Baez', to_date('22-03-2006', 'dd-mm-yyyy'), 'K8', 'F', 584932271, 1000000025, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749925, 'Ewan', 'Collette', to_date('02-02-1988', 'dd-mm-yyyy'), 'L9', 'M', 545613128, 1000000287, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749926, 'Suzy', 'Checker', to_date('18-03-1990', 'dd-mm-yyyy'), 'I6', 'F', 509739510, 1000000019, 'Peanuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749927, 'Tracy', 'Fehr', to_date('30-08-2013', 'dd-mm-yyyy'), 'H8', 'F', 584515207, 1000000257, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749928, 'Roscoe', 'Holeman', to_date('08-09-2004', 'dd-mm-yyyy'), 'D5', 'F', 575427475, 1000000150, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749929, 'Dorry', 'Parker', to_date('22-05-2001', 'dd-mm-yyyy'), 'L5', 'M', 508709025, 1000000294, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749930, 'Heath', 'Heatherly', to_date('30-05-1981', 'dd-mm-yyyy'), 'G1', 'F', 506967709, 1000000291, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749931, 'Brendan', 'Cage', to_date('24-04-2014', 'dd-mm-yyyy'), 'H4', 'F', 524168679, 1000000144, 'Latex');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749932, 'Peter', 'Rizzo', to_date('04-01-2009', 'dd-mm-yyyy'), 'L5', 'F', 583419065, 1000000329, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749933, 'Shelby', 'Perry', to_date('16-04-1987', 'dd-mm-yyyy'), 'J7', 'M', 562745379, 1000000296, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749934, 'Sheryl', 'Tomei', to_date('05-07-1994', 'dd-mm-yyyy'), 'J1', 'M', 576031472, 1000000070, 'Tree Nuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749935, 'Sophie', 'Close', to_date('03-09-2021', 'dd-mm-yyyy'), 'F8', 'M', 574466816, 1000000309, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749936, 'Marianne', 'Fichtner', to_date('04-07-2000', 'dd-mm-yyyy'), 'C8', 'M', 551159331, 1000000158, 'Soy');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749937, 'Sean', 'Meniketti', to_date('26-02-2018', 'dd-mm-yyyy'), 'I5', 'M', 527567872, 1000000098, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749938, 'Edie', 'Renfro', to_date('10-05-1981', 'dd-mm-yyyy'), 'I7', 'F', 584700272, 1000000109, 'Fish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749939, 'Pablo', 'Hanks', to_date('15-02-1996', 'dd-mm-yyyy'), 'D3', 'M', 528256931, 1000000342, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749940, 'Saul', 'Chaplin', to_date('02-10-1986', 'dd-mm-yyyy'), 'A1', 'F', 532084511, 1000000189, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749941, 'Laurie', 'Chandler', to_date('03-11-1998', 'dd-mm-yyyy'), 'H7', 'F', 583738685, 1000000254, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749942, 'Nickel', 'Lorenz', to_date('19-07-2007', 'dd-mm-yyyy'), 'G1', 'F', 566266855, 1000000101, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749943, 'Tyrone', 'Def', to_date('28-10-1984', 'dd-mm-yyyy'), 'J4', 'M', 558366835, 1000000358, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749944, 'Guy', 'Warwick', to_date('13-06-2004', 'dd-mm-yyyy'), 'F9', 'F', 561029817, 1000000260, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749945, 'Lois', 'Beals', to_date('25-08-1988', 'dd-mm-yyyy'), 'A3', 'M', 525551079, 1000000360, 'Shellfish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749946, 'Patricia', 'Fender', to_date('30-09-1994', 'dd-mm-yyyy'), 'G2', 'F', 576004944, 1000000070, 'Eggs');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749947, 'Tom', 'Paltrow', to_date('18-03-2002', 'dd-mm-yyyy'), 'K2', 'M', 506254689, 1000000131, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749948, 'Morris', 'Curtis-Hall', to_date('17-07-1980', 'dd-mm-yyyy'), 'F8', 'F', 522472786, 1000000399, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749949, 'Jena', 'Archer', to_date('24-10-2007', 'dd-mm-yyyy'), 'B9', 'M', 516154339, 1000000074, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749950, 'Eugene', 'Cohn', to_date('15-10-1986', 'dd-mm-yyyy'), 'J3', 'M', 505022447, 1000000368, 'Fish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749951, 'Lea', 'Nunn', to_date('11-02-2020', 'dd-mm-yyyy'), 'K6', 'F', 569855124, 1000000196, 'Soy');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749952, 'Graham', 'Nunn', to_date('07-12-2006', 'dd-mm-yyyy'), 'L8', 'M', 559851820, 1000000127, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749953, 'Minnie', 'Tempest', to_date('08-03-1992', 'dd-mm-yyyy'), 'L8', 'F', 509523436, 1000000251, 'Eggs');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749954, 'Salma', 'Davies', to_date('28-03-2010', 'dd-mm-yyyy'), 'G9', 'F', 504682053, 1000000157, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749955, 'Kay', 'Monk', to_date('24-09-1980', 'dd-mm-yyyy'), 'K1', 'F', 565981043, 1000000350, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749956, 'Nikka', 'Eldard', to_date('13-11-1993', 'dd-mm-yyyy'), 'L9', 'M', 513256796, 1000000091, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749957, 'Regina', 'Hawthorne', to_date('10-11-1992', 'dd-mm-yyyy'), 'K8', 'F', 516257797, 1000000353, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749958, 'Lenny', 'Cartlidge', to_date('14-04-1990', 'dd-mm-yyyy'), 'F5', 'F', 559011082, 1000000272, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749959, 'Thelma', 'Bruce', to_date('06-07-2023', 'dd-mm-yyyy'), 'K7', 'M', 573890451, 1000000107, 'Gluten');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749960, 'Clarence', 'Phoenix', to_date('20-04-1991', 'dd-mm-yyyy'), 'H8', 'M', 556038630, 1000000231, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749961, 'Cheech', 'Salonga', to_date('21-08-2016', 'dd-mm-yyyy'), 'C1', 'M', 514443545, 1000000265, 'Peanuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749962, 'Illeana', 'Oldman', to_date('26-11-2015', 'dd-mm-yyyy'), 'I5', 'F', 571772469, 1000000103, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749963, 'Karon', 'Finn', to_date('10-03-2016', 'dd-mm-yyyy'), 'J7', 'M', 515877703, 1000000140, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749964, 'Aida', 'Broadbent', to_date('21-08-1987', 'dd-mm-yyyy'), 'A1', 'F', 571134650, 1000000130, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749965, 'Johnette', 'Giraldo', to_date('03-02-1982', 'dd-mm-yyyy'), 'B7', 'F', 504063597, 1000000322, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749966, 'Joan', 'Armstrong', to_date('14-12-2013', 'dd-mm-yyyy'), 'L1', 'F', 572118754, 1000000067, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749967, 'Albertina', 'Capshaw', to_date('15-04-1982', 'dd-mm-yyyy'), 'A4', 'F', 515998542, 1000000314, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749968, 'Carole', 'Posey', to_date('02-02-2008', 'dd-mm-yyyy'), 'A9', 'M', 539156673, 1000000262, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749969, 'Kathleen', 'Hidalgo', to_date('02-03-2010', 'dd-mm-yyyy'), 'H3', 'F', 533689988, 1000000256, 'Shellfish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749970, 'Rosanna', 'Olin', to_date('01-08-1993', 'dd-mm-yyyy'), 'L9', 'M', 528000959, 1000000396, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749971, 'Walter', 'Downie', to_date('23-09-2003', 'dd-mm-yyyy'), 'H5', 'F', 523288296, 1000000226, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749972, 'Courtney', 'Steiger', to_date('24-06-2011', 'dd-mm-yyyy'), 'L5', 'F', 553538650, 1000000303, 'Dairy');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749973, 'Gabriel', 'Kotto', to_date('18-05-1989', 'dd-mm-yyyy'), 'K4', 'F', 564442787, 1000000387, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749974, 'Arturo', 'Bello', to_date('23-04-1987', 'dd-mm-yyyy'), 'J7', 'M', 577754220, 1000000149, 'Fish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749975, 'Ned', 'Cetera', to_date('11-02-2012', 'dd-mm-yyyy'), 'K5', 'F', 509082622, 1000000322, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749976, 'Geggy', 'Shatner', to_date('19-03-1985', 'dd-mm-yyyy'), 'D7', 'F', 586290750, 1000000361, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749977, 'Brad', 'Polito', to_date('05-04-1991', 'dd-mm-yyyy'), 'B8', 'M', 575450005, 1000000050, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749978, 'Taye', 'Kapanka', to_date('28-09-1982', 'dd-mm-yyyy'), 'B1', 'F', 518532050, 1000000106, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749979, 'Casey', 'Weaver', to_date('22-04-1982', 'dd-mm-yyyy'), 'F7', 'F', 563300159, 1000000049, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749980, 'Annie', 'Arkin', to_date('28-11-1981', 'dd-mm-yyyy'), 'A3', 'M', 528156776, 1000000118, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749981, 'Delroy', 'Leachman', to_date('18-01-2009', 'dd-mm-yyyy'), 'E3', 'M', 535292840, 1000000196, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749982, 'Neil', 'Santa Rosa', to_date('25-08-2016', 'dd-mm-yyyy'), 'K3', 'M', 545511114, 1000000133, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749983, 'Diane', 'Whitford', to_date('23-06-1985', 'dd-mm-yyyy'), 'D5', 'M', 513796468, 1000000049, 'Wheat');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749984, 'Ellen', 'Matthau', to_date('27-09-1985', 'dd-mm-yyyy'), 'E5', 'F', 537221765, 1000000281, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749985, 'Joe', 'Garofalo', to_date('17-10-1994', 'dd-mm-yyyy'), 'K3', 'F', 548170661, 1000000113, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749986, 'Rueben', 'Bridges', to_date('02-06-1991', 'dd-mm-yyyy'), 'C5', 'F', 527038384, 1000000319, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749987, 'Ned', 'Stamp', to_date('26-09-2014', 'dd-mm-yyyy'), 'I3', 'F', 521148643, 1000000239, 'Tree Nuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749988, 'Lucy', 'Snider', to_date('14-02-1997', 'dd-mm-yyyy'), 'D1', 'M', 513266667, 1000000245, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749989, 'Avril', 'Spiner', to_date('12-01-1980', 'dd-mm-yyyy'), 'J3', 'F', 558770081, 1000000031, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749990, 'Charlton', 'Ceasar', to_date('10-01-1986', 'dd-mm-yyyy'), 'J1', 'M', 568142554, 1000000015, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749991, 'Claire', 'Tillis', to_date('03-12-1996', 'dd-mm-yyyy'), 'B5', 'M', 558479953, 1000000038, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749992, 'Wayman', 'Reilly', to_date('05-08-2023', 'dd-mm-yyyy'), 'B4', 'M', 573416962, 1000000052, 'Gluten');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749993, 'Humberto', 'Winans', to_date('08-07-1987', 'dd-mm-yyyy'), 'H8', 'M', 564072520, 1000000263, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749994, 'Bonnie', 'Fiennes', to_date('01-03-2021', 'dd-mm-yyyy'), 'L3', 'M', 505081583, 1000000205, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749995, 'Michelle', 'Begley', to_date('07-11-2014', 'dd-mm-yyyy'), 'A6', 'F', 521183905, 1000000151, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749996, 'Rick', 'Torino', to_date('18-04-1987', 'dd-mm-yyyy'), 'I8', 'M', 586882107, 1000000224, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749997, 'Janice', 'Holliday', to_date('03-04-1986', 'dd-mm-yyyy'), 'L5', 'F', 561584606, 1000000308, 'Wheat');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749998, 'Thomas', 'Murray', to_date('19-11-1983', 'dd-mm-yyyy'), 'G1', 'M', 561848253, 1000000028, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238749999, 'Greg', 'Hawke', to_date('08-04-2019', 'dd-mm-yyyy'), 'C6', 'F', 529657091, 1000000165, 'Dairy');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750000, 'Nikka', 'Vai', to_date('14-07-2015', 'dd-mm-yyyy'), 'D7', 'F', 511832663, 1000000122, 'Eggs');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750001, 'Selma', 'Underwood', to_date('18-10-2019', 'dd-mm-yyyy'), 'J2', 'F', 564725816, 1000000345, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750002, 'Lea', 'Ricci', to_date('19-07-1983', 'dd-mm-yyyy'), 'G1', 'F', 536805604, 1000000321, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750003, 'Faye', 'Hoskins', to_date('20-03-2011', 'dd-mm-yyyy'), 'I4', 'M', 579400205, 1000000067, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750004, 'Rosco', 'Flanagan', to_date('30-05-1990', 'dd-mm-yyyy'), 'G8', 'M', 559712010, 1000000235, 'Fish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750005, 'Cole', 'Duvall', to_date('12-09-1981', 'dd-mm-yyyy'), 'F5', 'F', 533357706, 1000000078, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750006, 'Lesley', 'Cantrell', to_date('27-07-1998', 'dd-mm-yyyy'), 'G6', 'F', 561874128, 1000000198, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750007, 'Kazem', 'de Lancie', to_date('20-04-1996', 'dd-mm-yyyy'), 'L7', 'F', 542096589, 1000000365, 'Tree Nuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750008, 'Dustin', 'Studi', to_date('11-10-2002', 'dd-mm-yyyy'), 'J2', 'M', 547529494, 1000000293, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750009, 'Maxine', 'MacLachlan', to_date('26-12-1990', 'dd-mm-yyyy'), 'C9', 'M', 558689126, 1000000027, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750010, 'Lili', 'Mitra', to_date('15-07-1997', 'dd-mm-yyyy'), 'B9', 'M', 583942599, 1000000183, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750011, 'Liam', 'Hersh', to_date('04-02-2002', 'dd-mm-yyyy'), 'G8', 'M', 508527705, 1000000018, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750012, 'Sal', 'Phillippe', to_date('29-01-1986', 'dd-mm-yyyy'), 'G1', 'F', 521931903, 1000000131, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750013, 'Selma', 'Linney', to_date('12-08-2018', 'dd-mm-yyyy'), 'D8', 'M', 523041786, 1000000148, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750014, 'Anna', 'Palminteri', to_date('12-09-1994', 'dd-mm-yyyy'), 'B3', 'F', 547424407, 1000000117, 'none');
commit;
prompt 300 records committed...
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750015, 'Shannon', 'Gibbons', to_date('13-02-2016', 'dd-mm-yyyy'), 'J7', 'M', 532434888, 1000000143, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750016, 'Regina', 'Ryan', to_date('21-07-2019', 'dd-mm-yyyy'), 'K3', 'F', 569100130, 1000000252, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750017, 'Terrence', 'Weber', to_date('28-11-2006', 'dd-mm-yyyy'), 'D1', 'M', 581210541, 1000000122, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750018, 'Chaka', 'Gere', to_date('15-03-2000', 'dd-mm-yyyy'), 'J4', 'F', 544131277, 1000000377, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750019, 'Neve', 'Favreau', to_date('24-01-1980', 'dd-mm-yyyy'), 'C6', 'F', 575686765, 1000000022, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750020, 'Hex', 'Crouch', to_date('02-01-1999', 'dd-mm-yyyy'), 'I4', 'F', 562767913, 1000000189, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750021, 'Rich', 'Davidson', to_date('08-05-2000', 'dd-mm-yyyy'), 'I7', 'F', 538402789, 1000000280, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750022, 'Derrick', 'Spears', to_date('11-07-2014', 'dd-mm-yyyy'), 'I9', 'M', 588886243, 1000000109, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750023, 'Franco', 'Church', to_date('13-10-1986', 'dd-mm-yyyy'), 'J6', 'M', 579361714, 1000000204, 'Gluten');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750024, 'Debbie', 'Dupree', to_date('26-11-2008', 'dd-mm-yyyy'), 'F9', 'F', 502909520, 1000000285, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750025, 'Machine', 'Mortensen', to_date('03-02-1995', 'dd-mm-yyyy'), 'H4', 'M', 543991337, 1000000361, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750026, 'Christina', 'Stoltz', to_date('08-03-2005', 'dd-mm-yyyy'), 'A4', 'F', 533547760, 1000000074, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750027, 'Dennis', 'Candy', to_date('22-09-1992', 'dd-mm-yyyy'), 'I9', 'M', 508604739, 1000000273, 'Eggs');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750028, 'Franz', 'Atkins', to_date('28-10-1982', 'dd-mm-yyyy'), 'K5', 'M', 532893248, 1000000229, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750029, 'Catherine', 'Donovan', to_date('21-11-1981', 'dd-mm-yyyy'), 'J8', 'M', 581565120, 1000000246, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750030, 'Illeana', 'Dysart', to_date('31-12-1992', 'dd-mm-yyyy'), 'F6', 'F', 552366819, 1000000008, 'Gluten');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750031, 'Petula', 'Jovovich', to_date('24-05-2015', 'dd-mm-yyyy'), 'B5', 'M', 549368125, 1000000332, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750032, 'Dom', 'Conlee', to_date('12-03-2008', 'dd-mm-yyyy'), 'B7', 'M', 572147626, 1000000112, 'Dairy');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750033, 'Jim', 'Cockburn', to_date('06-02-2001', 'dd-mm-yyyy'), 'D2', 'F', 544012149, 1000000386, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750034, 'Neil', 'Campbell', to_date('28-10-1985', 'dd-mm-yyyy'), 'D2', 'M', 532848946, 1000000232, 'Shellfish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750035, 'Edgar', 'Brooks', to_date('04-03-2017', 'dd-mm-yyyy'), 'J1', 'F', 552395271, 1000000242, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750036, 'Elvis', 'Applegate', to_date('10-02-2018', 'dd-mm-yyyy'), 'D9', 'F', 558637182, 1000000144, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750037, 'Merrill', 'Hershey', to_date('04-12-1994', 'dd-mm-yyyy'), 'L5', 'M', 587619061, 1000000182, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750038, 'Renee', 'Keen', to_date('23-02-1998', 'dd-mm-yyyy'), 'K2', 'M', 512542960, 1000000113, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750039, 'Ricky', 'Tate', to_date('07-08-2022', 'dd-mm-yyyy'), 'L6', 'F', 561057052, 1000000365, 'Gluten');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750040, 'Rob', 'Field', to_date('02-07-1981', 'dd-mm-yyyy'), 'F4', 'F', 523694658, 1000000075, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750041, 'Anita', 'Botti', to_date('23-06-2009', 'dd-mm-yyyy'), 'B5', 'F', 514421641, 1000000068, 'Gluten');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750042, 'Giancarlo', 'Ramirez', to_date('08-10-2005', 'dd-mm-yyyy'), 'G1', 'F', 583428363, 1000000032, 'Dairy');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750043, 'Belinda', 'McGill', to_date('12-01-2004', 'dd-mm-yyyy'), 'B8', 'F', 507900097, 1000000202, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750044, 'Ron', 'Trejo', to_date('05-11-2023', 'dd-mm-yyyy'), 'D3', 'F', 538006543, 1000000069, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750045, 'Geena', 'Horizon', to_date('08-05-2020', 'dd-mm-yyyy'), 'E1', 'F', 526290701, 1000000183, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750046, 'Demi', 'Candy', to_date('11-03-2007', 'dd-mm-yyyy'), 'L5', 'F', 538823240, 1000000139, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750047, 'Rascal', 'Winstone', to_date('05-01-2016', 'dd-mm-yyyy'), 'J2', 'M', 542016356, 1000000045, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750048, 'Cuba', 'Rubinek', to_date('02-09-2010', 'dd-mm-yyyy'), 'C9', 'F', 542798805, 1000000127, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750049, 'Laura', 'Osbourne', to_date('31-12-2000', 'dd-mm-yyyy'), 'F6', 'M', 528487681, 1000000163, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750050, 'Mickey', 'Crudup', to_date('09-09-2018', 'dd-mm-yyyy'), 'B2', 'M', 571984535, 1000000370, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750051, 'Aida', 'Piven', to_date('21-02-2002', 'dd-mm-yyyy'), 'L3', 'M', 525593335, 1000000159, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750052, 'Tzi', 'Kramer', to_date('13-06-2005', 'dd-mm-yyyy'), 'J9', 'M', 572519691, 1000000393, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750053, 'Rowan', 'Chao', to_date('02-02-2019', 'dd-mm-yyyy'), 'D4', 'F', 571674353, 1000000110, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750054, 'Tal', 'Maguire', to_date('16-01-2019', 'dd-mm-yyyy'), 'H8', 'F', 555822595, 1000000213, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750055, 'Amanda', 'Pony', to_date('27-05-1999', 'dd-mm-yyyy'), 'K5', 'F', 562254364, 1000000031, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750056, 'Pelvic', 'Hewitt', to_date('02-11-1999', 'dd-mm-yyyy'), 'D7', 'F', 571566473, 1000000367, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750057, 'Freda', 'Thompson', to_date('01-11-2023', 'dd-mm-yyyy'), 'K6', 'F', 548611006, 1000000382, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750058, 'Maxine', 'Easton', to_date('10-06-2004', 'dd-mm-yyyy'), 'A4', 'M', 581401836, 1000000029, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750059, 'Pat', 'Hawkins', to_date('28-12-2007', 'dd-mm-yyyy'), 'J1', 'F', 544048286, 1000000263, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750060, 'Heath', 'Kadison', to_date('31-03-1994', 'dd-mm-yyyy'), 'I9', 'F', 585853010, 1000000031, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750061, 'Neil', 'Plimpton', to_date('27-04-2021', 'dd-mm-yyyy'), 'K7', 'F', 547027476, 1000000067, 'Peanuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750062, 'Annie', 'Lithgow', to_date('05-12-2013', 'dd-mm-yyyy'), 'D2', 'M', 517149428, 1000000354, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750063, 'Lisa', 'Pony', to_date('13-01-2007', 'dd-mm-yyyy'), 'D2', 'F', 548197926, 1000000102, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750064, 'Adam', 'Paquin', to_date('27-06-2005', 'dd-mm-yyyy'), 'H5', 'F', 552265016, 1000000152, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750065, 'Ed', 'Hong', to_date('12-09-2011', 'dd-mm-yyyy'), 'B3', 'F', 557401403, 1000000318, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750066, 'Edgar', 'O''Keefe', to_date('04-10-1996', 'dd-mm-yyyy'), 'G1', 'F', 541943852, 1000000312, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750067, 'Randy', 'Cervine', to_date('25-09-1984', 'dd-mm-yyyy'), 'B4', 'F', 589966731, 1000000209, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750068, 'Dennis', 'Donovan', to_date('02-09-1989', 'dd-mm-yyyy'), 'F6', 'M', 579299885, 1000000288, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750069, 'Jason', 'Shalhoub', to_date('10-03-2007', 'dd-mm-yyyy'), 'C9', 'M', 567628098, 1000000143, 'Peanuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750070, 'Ron', 'Hauser', to_date('23-06-1982', 'dd-mm-yyyy'), 'B1', 'M', 537505223, 1000000330, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750071, 'Annette', 'Visnjic', to_date('10-03-1996', 'dd-mm-yyyy'), 'G5', 'M', 586252952, 1000000156, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750072, 'King', 'Prinze', to_date('06-01-1991', 'dd-mm-yyyy'), 'L4', 'F', 503437974, 1000000155, 'Wheat');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750073, 'Boz', 'McLean', to_date('04-04-2016', 'dd-mm-yyyy'), 'I2', 'M', 587816374, 1000000392, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750074, 'Buddy', 'Callow', to_date('26-07-2002', 'dd-mm-yyyy'), 'I2', 'M', 588759240, 1000000058, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750075, 'Fred', 'Def', to_date('03-05-2006', 'dd-mm-yyyy'), 'G8', 'F', 537770727, 1000000127, 'Tree Nuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750076, 'Harris', 'Lipnicki', to_date('01-04-1993', 'dd-mm-yyyy'), 'I3', 'M', 554042193, 1000000379, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750077, 'Geraldine', 'Biggs', to_date('05-11-2023', 'dd-mm-yyyy'), 'C2', 'F', 559694739, 1000000242, 'Peanuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750078, 'Charlize', 'Lillard', to_date('29-04-2024', 'dd-mm-yyyy'), 'L1', 'M', 515096650, 1000000074, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750079, 'Teri', 'Wells', to_date('31-03-1998', 'dd-mm-yyyy'), 'D8', 'F', 507927467, 1000000092, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750080, 'Derek', 'Zane', to_date('31-05-1984', 'dd-mm-yyyy'), 'C4', 'F', 587832804, 1000000006, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750081, 'Forest', 'Myles', to_date('15-08-2008', 'dd-mm-yyyy'), 'D4', 'M', 538362310, 1000000240, 'Wheat');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750082, 'Ahmad', 'Rhymes', to_date('02-10-1990', 'dd-mm-yyyy'), 'J2', 'M', 501700088, 1000000131, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750083, 'Jann', 'Loeb', to_date('09-01-1993', 'dd-mm-yyyy'), 'E5', 'M', 512756901, 1000000099, 'Soy');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750084, 'Embeth', 'Mantegna', to_date('11-11-2000', 'dd-mm-yyyy'), 'I8', 'M', 586234280, 1000000137, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750085, 'Derek', 'Franklin', to_date('26-12-2004', 'dd-mm-yyyy'), 'B4', 'M', 524368830, 1000000382, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750086, 'Pam', 'Botti', to_date('18-06-1982', 'dd-mm-yyyy'), 'H9', 'M', 554360178, 1000000006, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750087, 'Bridget', 'Sheen', to_date('13-07-1994', 'dd-mm-yyyy'), 'C1', 'F', 515517155, 1000000240, 'Gluten');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750088, 'France', 'Sanchez', to_date('28-04-2016', 'dd-mm-yyyy'), 'J6', 'F', 576141116, 1000000107, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750089, 'Anjelica', 'Pleasence', to_date('28-01-2006', 'dd-mm-yyyy'), 'B2', 'F', 553358164, 1000000233, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750090, 'Rascal', 'Place', to_date('15-12-1994', 'dd-mm-yyyy'), 'L4', 'F', 512452770, 1000000136, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750091, 'Junior', 'Sylvian', to_date('29-08-2016', 'dd-mm-yyyy'), 'I2', 'F', 581813253, 1000000086, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750092, 'Johnnie', 'Howard', to_date('17-10-1997', 'dd-mm-yyyy'), 'E6', 'F', 513899454, 1000000376, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750093, 'Taylor', 'Collette', to_date('24-08-2004', 'dd-mm-yyyy'), 'D8', 'F', 508759639, 1000000353, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750094, 'Al', 'Brandt', to_date('11-03-1992', 'dd-mm-yyyy'), 'A6', 'M', 557999181, 1000000363, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750095, 'Roscoe', 'Jamal', to_date('31-03-2006', 'dd-mm-yyyy'), 'E2', 'F', 509353403, 1000000094, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750096, 'Maura', 'Merchant', to_date('25-05-2016', 'dd-mm-yyyy'), 'H1', 'M', 508551409, 1000000107, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750097, 'Oro', 'Devine', to_date('09-05-1990', 'dd-mm-yyyy'), 'I1', 'F', 516261621, 1000000068, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750098, 'Amanda', 'Busey', to_date('14-12-2018', 'dd-mm-yyyy'), 'G8', 'M', 564981314, 1000000022, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750099, 'Ann', 'Barrymore', to_date('09-07-2019', 'dd-mm-yyyy'), 'K6', 'F', 553698448, 1000000223, 'Latex');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750100, 'Kate', 'Weston', to_date('15-01-2001', 'dd-mm-yyyy'), 'F5', 'F', 515638962, 1000000148, 'Tree Nuts');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750101, 'Jean-Luc', 'Kahn', to_date('30-01-2000', 'dd-mm-yyyy'), 'H3', 'M', 564051686, 1000000109, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750102, 'Dustin', 'Ruffalo', to_date('08-08-1987', 'dd-mm-yyyy'), 'D3', 'F', 547333550, 1000000196, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750103, 'Ron', 'Magnuson', to_date('07-02-1998', 'dd-mm-yyyy'), 'E9', 'M', 514613853, 1000000328, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750104, 'Sharon', 'Dillon', to_date('20-10-2023', 'dd-mm-yyyy'), 'C7', 'M', 567114301, 1000000107, 'Wheat');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750105, 'Kiefer', 'Clayton', to_date('09-09-2017', 'dd-mm-yyyy'), 'C3', 'F', 566057772, 1000000083, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750106, 'Amanda', 'Herrmann', to_date('22-07-2011', 'dd-mm-yyyy'), 'C5', 'F', 563283253, 1000000210, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750107, 'Rhona', 'Clayton', to_date('08-01-2014', 'dd-mm-yyyy'), 'L3', 'F', 577883614, 1000000376, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750108, 'Lea', 'Mewes', to_date('11-06-2015', 'dd-mm-yyyy'), 'C2', 'F', 542153478, 1000000370, 'Dairy');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750109, 'Eric', 'Snider', to_date('24-11-2019', 'dd-mm-yyyy'), 'A7', 'F', 544674675, 1000000346, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750110, 'Oro', 'Giannini', to_date('12-03-1989', 'dd-mm-yyyy'), 'I5', 'F', 546961801, 1000000006, 'Shellfish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750111, 'Roger', 'Dunaway', to_date('26-01-1996', 'dd-mm-yyyy'), 'D2', 'F', 547695445, 1000000208, 'Shellfish');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750112, 'Adina', 'Shalhoub', to_date('28-02-2000', 'dd-mm-yyyy'), 'E9', 'M', 553920267, 1000000037, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750113, 'Madeleine', 'Farina', to_date('17-12-1986', 'dd-mm-yyyy'), 'E1', 'M', 509710283, 1000000387, 'none');
insert into PUPIL (id, firstname, lastname, birthdate, homeclass, gender, parentphone, institutionid, allergics)
values (238750114, 'Lupe', 'Ticotin', to_date('17-12-1999', 'dd-mm-yyyy'), 'A1', 'F', 578457988, 1000000077, 'none');
commit;
prompt 400 records loaded
prompt Loading STUDENTCOUNCIL...
insert into STUDENTCOUNCIL (year, head, assistant)
values (1824, 'Kid', 'Kristin');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1825, 'Bridgette', 'Marie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1826, 'Trace', 'Violet');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1827, 'Chalee', 'Jessie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1828, 'Brad', 'Olivia');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1829, 'Jean-Claude', 'Genevieve');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1830, 'Jason', 'Jack');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1831, 'Christine', 'Justin');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1832, 'Julianna', 'Edgar');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1833, 'Harold', 'Danielle');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1834, 'Lin', 'Leonard');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1835, 'Radney', 'Tara');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1836, 'Xander', 'Miranda');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1837, 'Cuba', 'Brian');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1838, 'Daryl', 'Judith');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1839, 'Grace', 'Dominic');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1840, 'Jamie', 'Grace');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1841, 'Naomi', 'Stephen');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1842, 'Rutger', 'Isabelle');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1843, 'Madeline', 'Denise');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1844, 'Saul', 'Liz');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1845, 'Leslie', 'Pamela');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1846, 'Mili', 'Alicia');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1847, 'Katrin', 'Chloe');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1848, 'Chantי', 'Dana');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1849, 'Paula', 'Jacob');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1850, 'Andy', 'Harper');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1851, 'Gary', 'Tamara');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1852, 'Nile', 'Theodore');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1853, 'Jane', 'Brianna');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1854, 'Caroline', 'Will');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1855, 'Frances', 'Alyssa');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1856, 'Mickey', 'Patrick');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1857, 'Tom', 'Samuel');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1858, 'Ving', 'Alexis');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1859, 'Daryle', 'Daphne');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1860, 'Clea', 'Kayla');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1861, 'Joely', 'Katelyn');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1862, 'Rhea', 'Cora');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1863, 'Moe', 'Victoria');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1864, 'Geggy', 'Irene');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1865, 'Lance', 'Joseph');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1866, 'Max', 'Edith');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1867, 'Graham', 'Jean');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1868, 'Beth', 'Tammy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1869, 'Gordie', 'Katherine');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1870, 'Gwyneth', 'Natalie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1871, 'Toni', 'Sherry');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1872, 'Mekhi', 'Jamie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1873, 'Temuera', 'James');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1874, 'Tara', 'Johnny');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1875, 'Shannon', 'Dan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1876, 'Cole', 'Nolan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1877, 'Trey', 'Betty');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1878, 'Ronnie', 'Monica');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1879, 'Woody', 'Brianna');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1880, 'Roger', 'Roy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1881, 'Morris', 'Jose');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1882, 'Debi', 'Eric');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1883, 'William', 'Ronald');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1884, 'Simon', 'Johnny');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1885, 'James', 'Veronica');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1886, 'Xander', 'Jordan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1887, 'Lari', 'Simon');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1888, 'Lee', 'Lindsay');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1889, 'Tara', 'Sophia');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1890, 'Emmylou', 'Sheila');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1891, 'Hugh', 'Lori');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1892, 'Roscoe', 'Janet');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1893, 'Kiefer', 'Eleanor');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1894, 'Gordon', 'Gabrielle');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1895, 'Denny', 'Peter');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1896, 'Natalie', 'Courtney');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1897, 'Famke', 'Janice');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1898, 'Pamela', 'Ivy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1899, 'Etta', 'Greg');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1900, 'Nils', 'Vicki');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1901, 'Oliver', 'Kevin');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1902, 'Mia', 'Christine');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1903, 'Sona', 'Joe');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1904, 'Tanya', 'Jackson');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1905, 'Herbie', 'Sherry');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1906, 'Russell', 'Ruth');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1907, 'Mary', 'Kathy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1908, 'Stellan', 'Preston');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1909, 'Isaiah', 'Tammy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1910, 'Lou', 'Ruth');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1911, 'Marlon', 'Pamela');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1912, 'Henry', 'Ralph');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1913, 'Noah', 'Heather');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1914, 'Cliff', 'Justin');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1915, 'Ethan', 'Carl');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1916, 'Anna', 'Sophia');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1917, 'Bo', 'Makayla');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1918, 'Lea', 'Kristin');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1919, 'Chaka', 'Donald');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1920, 'Kristin', 'Marshall');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1921, 'Angela', 'Stanley');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1922, 'Gloria', 'Spencer');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1923, 'Faye', 'Colin');
commit;
prompt 100 records committed...
insert into STUDENTCOUNCIL (year, head, assistant)
values (1924, 'Victor', 'Taylor');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1925, 'Kurtwood', 'Joanna');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1926, 'Edgar', 'Amanda');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1927, 'Ruth', 'Dylan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1928, 'Meredith', 'Jessica');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1929, 'Joseph', 'Jessica');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1930, 'Merillee', 'Rose');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1931, 'Ving', 'Patrick');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1932, 'Cathy', 'Sherri');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1933, 'Amy', 'Gary');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1934, 'Julie', 'Madeline');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1935, 'Aaron', 'Anastasia');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1936, 'Maceo', 'Darla');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1937, 'Peabo', 'Meredith');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1938, 'Nora', 'Nicholas');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1939, 'Carlos', 'Sharon');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1940, 'Juliette', 'Felicity');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1941, 'Keith', 'Peggy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1942, 'Oliver', 'Barbara');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1943, 'Alessandro', 'Patrick');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1944, 'Leelee', 'Hannah');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1945, 'Frankie', 'Shirley');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1946, 'First', 'Michelle');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1947, 'Earl', 'Matthew');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1948, 'Bob', 'Joy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1949, 'Red', 'Colin');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1950, 'Sara', 'Elijah');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1951, 'Lena', 'Rebecca');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1952, 'Mae', 'Eleanor');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1953, 'Lupe', 'Mark');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1954, 'Stephen', 'Kathy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1955, 'Queen', 'Neil');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1956, 'Peter', 'Janice');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1957, 'Miranda', 'Sylvia');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1958, 'Solomon', 'Rose');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1959, 'Peabo', 'Janice');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1960, 'Kenny', 'Timothy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1961, 'Chloe', 'Julie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1962, 'Horace', 'Gabrielle');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1963, 'Armand', 'Mandy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1964, 'Rosanne', 'Elizabeth');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1965, 'Edgar', 'Isaac');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1966, 'Lisa', 'Bryan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1967, 'Harold', 'Melanie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1968, 'Hal', 'William');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1969, 'Stephanie', 'Julia');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1970, 'Stewart', 'Angela');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1971, 'Rosanna', 'Greg');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1972, 'Rodney', 'Morgan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1973, 'Annette', 'Giovanni');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1974, 'Davey', 'Samantha');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1975, 'Ashton', 'Morgan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1976, 'Elias', 'Kathleen');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1977, 'Christmas', 'Larry');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1978, 'Dom', 'Carol');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1979, 'Coley', 'Sara');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1980, 'Bret', 'Joyce');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1981, 'Cameron', 'Diana');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1982, 'Dan', 'Ian');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1983, 'John', 'Ian');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1984, 'Angela', 'Jerry');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1985, 'Bridgette', 'Eliza');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1986, 'Samantha', 'Stanley');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1987, 'Sonny', 'Shawn');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1988, 'Maggie', 'Sharon');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1989, 'Guy', 'Jay');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1990, 'Rod', 'Charles');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1991, 'Joanna', 'Eliza');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1992, 'Sonny', 'Eliana');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1993, 'Molly', 'John');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1994, 'Dylan', 'Rosa');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1995, 'Jill', 'Ralph');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1996, 'Kate', 'Alison');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1997, 'Mindy', 'Diane');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1998, 'Ruth', 'Priscilla');
insert into STUDENTCOUNCIL (year, head, assistant)
values (1999, 'Forest', 'Theodore');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2000, 'Bobby', 'Marian');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2001, 'Tyrone', 'Suzanne');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2002, 'Tramaine', 'Jerry');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2003, 'Jessica', 'Frank');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2004, 'Sonny', 'Russell');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2005, 'Balthazar', 'Linda');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2006, 'Frankie', 'Quinn');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2007, 'Sona', 'Ashley');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2008, 'Pam', 'Doreen');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2009, 'Diamond', 'Kate');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2010, 'Teena', 'Kate');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2011, 'Luke', 'Connor');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2012, 'Jeremy', 'Christopher');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2013, 'Vern', 'Eric');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2014, 'Christine', 'Lois');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2015, 'Rodney', 'Teresa');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2016, 'Geggy', 'Dakota');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2017, 'Garry', 'Edith');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2018, 'Jet', 'Olivia');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2019, 'Aaron', 'Mallory');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2020, 'Cyndi', 'Madison');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2021, 'Emma', 'Sophie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2022, 'Trace', 'Amanda');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2023, 'Olympia', 'Paula');
commit;
prompt 200 records committed...
insert into STUDENTCOUNCIL (year, head, assistant)
values (2024, 'Leelee', 'Gabriel');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2025, 'Manu', 'Marissa');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2026, 'Rade', 'Janet');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2027, 'Gaby', 'Stanley');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2028, 'Cheryl', 'Dan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2029, 'Omar', 'Louis');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2030, 'Joan', 'Sally');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2031, 'Gwyneth', 'Neil');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2032, 'Sylvester', 'Rachel');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2033, 'Gene', 'Tami');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2034, 'Nikki', 'Julie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2035, 'Viggo', 'Jenna');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2036, 'Warren', 'Martha');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2037, 'Shelby', 'Raymond');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2038, 'Kathleen', 'Douglas');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2039, 'Sammy', 'Diana');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2040, 'Hilton', 'Eugene');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2041, 'Patty', 'Johnny');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2042, 'Jimmie', 'Kimberly');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2043, 'Elvis', 'Vincent');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2044, 'Nils', 'Anthony');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2045, 'Jackie', 'Adam');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2046, 'Latin', 'Terry');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2047, 'Rich', 'Vicki');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2048, 'Dorry', 'Wanda');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2049, 'Emerson', 'Ronald');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2050, 'Chet', 'Jessica');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2051, 'Oliver', 'Wanda');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2052, 'Jesus', 'Troy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2053, 'Gordie', 'Ivy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2054, 'Henry', 'Willie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2055, 'Lee', 'Joan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2056, 'Marina', 'Linda');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2057, 'Rhona', 'Diana');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2058, 'Natacha', 'Gina');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2059, 'Bernard', 'Alice');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2060, 'Alannah', 'Rebecca');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2061, 'Clarence', 'Johnny');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2062, 'Seth', 'Cindy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2063, 'Harriet', 'Terry');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2064, 'Colin', 'Sonia');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2065, 'Morgan', 'Dave');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2066, 'Ernest', 'Jerome');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2067, 'Madeleine', 'Vivian');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2068, 'Mili', 'Jerry');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2069, 'Adrien', 'Lois');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2070, 'Larenz', 'Sean');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2071, 'Lydia', 'Jennifer');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2072, 'Toshiro', 'Mallory');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2073, 'Carla', 'Crystal');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2074, 'Edward', 'Paula');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2075, 'Edwin', 'Kimberly');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2076, 'Raul', 'Morgan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2077, 'Sandra', 'Joyce');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2078, 'Hugo', 'Jill');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2079, 'Sally', 'Roger');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2080, 'Rodney', 'Tyler');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2081, 'Desmond', 'Sean');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2082, 'Naomi', 'Sharon');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2083, 'Suzanne', 'Brianna');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2084, 'Kenneth', 'Stacy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2085, 'Powers', 'Catherine');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2086, 'Kelli', 'Randy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2087, 'Cornell', 'Roberta');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2088, 'Hilton', 'Meredith');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2089, 'Famke', 'Maggie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2090, 'Art', 'Phyllis');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2091, 'Hank', 'Elise');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2092, 'Lea', 'Wanda');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2093, 'Zooey', 'Jose');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2094, 'Patti', 'Penny');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2095, 'Hikaru', 'Shawn');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2096, 'Lonnie', 'Pauline');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2097, 'Sophie', 'Sabrina');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2098, 'Alana', 'Joe');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2099, 'Rueben', 'Madeline');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2100, 'Norm', 'Shannon');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2101, 'Elisabeth', 'Randy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2102, 'Jaime', 'Eugene');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2103, 'Aida', 'Steven');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2104, 'Gavin', 'Troy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2105, 'Bobbi', 'Jared');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2106, 'Aida', 'Kristin');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2107, 'Sammy', 'Gabrielle');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2108, 'Olympia', 'Nicholas');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2109, 'Sona', 'Travis');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2110, 'Angelina', 'Jonathan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2111, 'Mia', 'Abigail');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2112, 'Elias', 'Kay');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2113, 'Norm', 'Donald');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2114, 'Aaron', 'Gavin');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2115, 'Malcolm', 'Willie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2116, 'Ronny', 'Judy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2117, 'Taye', 'Harvey');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2118, 'Trini', 'Juan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2119, 'Charlton', 'Alison');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2120, 'Jessica', 'Julie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2121, 'Joely', 'Kenneth');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2122, 'Chaka', 'Roy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2123, 'Campbell', 'Natalie');
commit;
prompt 300 records committed...
insert into STUDENTCOUNCIL (year, head, assistant)
values (2124, 'Kasey', 'Isaac');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2125, 'Jeremy', 'Gregory');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2126, 'Allan', 'Michelle');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2127, 'Oro', 'Charles');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2128, 'Walter', 'Charlotte');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2129, 'Betty', 'Violet');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2130, 'Johnny', 'Virginia');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2131, 'Hank', 'April');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2132, 'Colm', 'Alison');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2133, 'Olympia', 'Quinn');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2134, 'Harry', 'Ashley');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2135, 'Curtis', 'Amelia');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2136, 'Praga', 'Sandra');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2137, 'Lupe', 'Ryan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2138, 'Lindsay', 'Stephanie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2139, 'Lea', 'Hannah');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2140, 'Terri', 'Robin');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2141, 'Gord', 'Cassidy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2142, 'Albertina', 'Erin');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2143, 'Chrissie', 'John');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2144, 'CeCe', 'Jasmine');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2145, 'Juice', 'Harvey');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2146, 'Frankie', 'Gabriella');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2147, 'Dave', 'Juan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2148, 'Amy', 'Debbie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2149, 'Judi', 'Arianna');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2150, 'Lennie', 'Ashley');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2151, 'Cledus', 'Darla');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2152, 'Mandy', 'Frances');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2153, 'Sheena', 'Rachael');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2154, 'Josh', 'Samantha');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2155, 'Jonny Lee', 'Megan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2156, 'Salma', 'Chad');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2157, 'Whoopi', 'Sophie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2158, 'Swoosie', 'Jesse');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2159, 'Vern', 'Lorna');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2160, 'Katie', 'Ariel');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2161, 'Mira', 'Matthew');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2162, 'Junior', 'Michael');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2163, 'Corey', 'Mitchell');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2164, 'Guy', 'Crystal');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2165, 'Mike', 'Raymond');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2166, 'Teena', 'Grace');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2167, 'Leo', 'Virginia');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2168, 'Miriam', 'Leah');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2169, 'Saul', 'Aiden');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2170, 'Candice', 'Fiona');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2171, 'Christian', 'Kelly');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2172, 'Vienna', 'Wesley');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2173, 'Ian', 'Dean');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2174, 'Cesar', 'Hugh');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2175, 'Liam', 'Robert');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2176, 'Clarence', 'Isabel');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2177, 'Liam', 'Kurt');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2178, 'Billy', 'Karen');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2179, 'Frances', 'Katherine');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2180, 'Ashley', 'Tamara');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2181, 'Jackie', 'Evan');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2182, 'Jodie', 'Marian');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2183, 'Elizabeth', 'Debra');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2184, 'Uma', 'Stanley');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2185, 'Gil', 'Mallory');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2186, 'Rupert', 'Vicky');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2187, 'Sandra', 'Dawn');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2188, 'Robbie', 'Kurt');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2189, 'Harris', 'Joseph');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2190, 'Rhona', 'Kayla');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2191, 'Stockard', 'Regina');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2192, 'Lee', 'Joyce');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2193, 'Fionnula', 'Ariel');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2194, 'Corey', 'Bethany');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2195, 'Kevin', 'Carol');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2196, 'Ricardo', 'Pauline');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2197, 'Mary', 'Billy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2198, 'Ray', 'Elizabeth');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2199, 'Nik', 'Yvonne');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2200, 'Ray', 'Rose');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2201, 'Frederic', 'Olivia');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2202, 'Anjelica', 'Linda');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2203, 'Norm', 'Maggie');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2204, 'Nils', 'Gerald');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2205, 'Harry', 'Stephen');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2206, 'Jonatha', 'Keith');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2207, 'Faye', 'Helen');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2208, 'Hikaru', 'Katherine');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2209, 'Davy', 'Ruth');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2210, 'Andrae', 'Jeremy');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2211, 'Parker', 'Steven');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2212, 'Beth', 'Todd');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2213, 'Shirley', 'Pauline');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2214, 'Amanda', 'Francesca');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2215, 'Neneh', 'Karla');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2216, 'Rik', 'John');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2217, 'Vincent', 'Samuel');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2218, 'Devon', 'Brandon');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2219, 'Taryn', 'Eric');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2220, 'Sheryl', 'Neal');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2221, 'Lorraine', 'Shirley');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2222, 'Herbie', 'Philip');
insert into STUDENTCOUNCIL (year, head, assistant)
values (2223, 'Lynette', 'Phyllis');
commit;
prompt 400 records loaded
prompt Loading REPRESENTIVE...
insert into REPRESENTIVE (id, role, age, average, year)
values (238749715, 'none', 16, 84, 2028);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749716, 'none', 15, 69, 2186);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749717, 'head', 16, 71, 2102);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749718, 'none', 16, 96, 2098);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749719, 'none', 18, 99, 2070);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749720, 'assistent', 18, 96, 2149);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749721, 'none', 17, 94, 2122);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749722, 'assistent', 18, 78, 1874);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749723, 'none', 16, 81, 2084);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749724, 'none', 16, 82, 2039);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749725, 'none', 16, 77, 1971);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749726, 'none', 16, 85, 2215);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749727, 'none', 17, 81, 1968);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749728, 'none', 17, 73, 2165);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749729, 'none', 14, 91, 1835);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749730, 'none', 17, 86, 1864);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749731, 'head', 15, 89, 2136);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749732, 'none', 16, 89, 2145);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749733, 'none', 18, 73, 2098);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749734, 'none', 17, 75, 1962);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749735, 'head', 15, 67, 2090);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749736, 'none', 16, 74, 1886);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749737, 'none', 14, 68, 1926);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749738, 'none', 16, 90, 2220);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749739, 'assistent', 14, 78, 2201);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749740, 'assistent', 17, 66, 2149);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749741, 'none', 16, 74, 1839);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749742, 'assistent', 17, 97, 1898);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749743, 'head', 15, 96, 1880);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749744, 'none', 17, 83, 1934);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749745, 'none', 16, 100, 1882);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749746, 'none', 18, 84, 1978);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749747, 'none', 16, 66, 2154);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749748, 'head', 15, 66, 1850);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749749, 'none', 15, 87, 2208);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749750, 'none', 15, 91, 2138);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749751, 'none', 17, 73, 1842);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749752, 'none', 15, 91, 1889);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749753, 'none', 16, 75, 2045);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749754, 'none', 15, 83, 2130);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749755, 'none', 15, 81, 2127);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749756, 'none', 15, 69, 2005);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749757, 'none', 15, 80, 1875);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749758, 'none', 16, 92, 1952);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749759, 'none', 16, 96, 1934);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749760, 'none', 16, 91, 1886);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749761, 'none', 15, 90, 2011);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749762, 'none', 18, 88, 2024);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749763, 'head', 16, 91, 2105);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749764, 'none', 15, 97, 1928);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749765, 'none', 16, 84, 1966);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749766, 'none', 14, 83, 2166);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749767, 'none', 15, 94, 1972);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749768, 'none', 16, 77, 2214);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749769, 'none', 14, 95, 1835);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749770, 'none', 15, 82, 2167);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749771, 'none', 16, 76, 1933);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749772, 'none', 17, 65, 1886);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749773, 'none', 16, 89, 2064);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749774, 'none', 18, 69, 1965);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749775, 'none', 17, 80, 2027);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749776, 'none', 17, 85, 2121);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749777, 'none', 15, 65, 2029);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749778, 'none', 17, 72, 2219);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749779, 'none', 18, 65, 2110);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749780, 'assistent', 14, 72, 1906);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749781, 'none', 15, 78, 2207);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749782, 'none', 14, 75, 2087);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749783, 'none', 17, 78, 2028);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749784, 'none', 14, 78, 2212);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749785, 'none', 16, 82, 1957);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749786, 'none', 16, 84, 2198);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749787, 'none', 15, 96, 2192);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749788, 'head', 17, 76, 2169);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749789, 'none', 15, 65, 2090);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749790, 'none', 15, 75, 2028);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749791, 'head', 15, 89, 2156);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749792, 'assistent', 18, 97, 2044);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749793, 'none', 18, 74, 1845);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749794, 'head', 15, 94, 2077);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749795, 'head', 14, 78, 1990);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749796, 'assistent', 16, 73, 2213);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749797, 'head', 16, 93, 1864);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749798, 'head', 17, 99, 2040);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749799, 'none', 16, 90, 2054);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749800, 'head', 16, 77, 2135);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749801, 'none', 16, 72, 1970);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749802, 'none', 16, 96, 2186);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749803, 'none', 16, 74, 1974);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749804, 'none', 15, 97, 2132);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749805, 'none', 14, 92, 2137);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749806, 'none', 18, 90, 1931);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749807, 'head', 17, 69, 2017);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749808, 'head', 14, 98, 1957);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749809, 'none', 14, 66, 1869);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749810, 'none', 17, 73, 2013);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749811, 'none', 14, 86, 2068);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749812, 'none', 15, 79, 2176);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749813, 'none', 17, 91, 1972);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749814, 'head', 16, 86, 1866);
commit;
prompt 100 records committed...
insert into REPRESENTIVE (id, role, age, average, year)
values (238749815, 'assistent', 18, 97, 2199);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749816, 'none', 14, 65, 1938);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749817, 'none', 14, 74, 1932);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749818, 'none', 18, 98, 2199);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749819, 'head', 14, 95, 2051);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749820, 'none', 17, 95, 1952);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749821, 'head', 16, 80, 2089);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749822, 'none', 18, 70, 1965);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749823, 'head', 16, 80, 2207);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749824, 'assistent', 18, 65, 1863);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749825, 'none', 18, 72, 2209);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749826, 'none', 15, 85, 2143);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749827, 'none', 15, 90, 1963);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749828, 'none', 15, 80, 2023);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749829, 'none', 16, 77, 2063);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749830, 'none', 16, 85, 1906);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749831, 'none', 14, 76, 1908);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749832, 'none', 16, 80, 2072);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749833, 'assistent', 17, 67, 2003);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749834, 'assistent', 17, 77, 2000);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749835, 'assistent', 16, 74, 2095);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749836, 'none', 15, 81, 1908);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749837, 'none', 15, 94, 1929);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749838, 'assistent', 18, 86, 2120);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749839, 'none', 15, 85, 2222);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749840, 'none', 16, 94, 1863);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749841, 'none', 14, 96, 1874);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749842, 'none', 15, 68, 1882);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749843, 'none', 14, 98, 2198);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749844, 'head', 18, 75, 2082);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749845, 'none', 15, 66, 2173);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749846, 'none', 17, 83, 2198);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749847, 'none', 16, 82, 1927);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749848, 'assistent', 14, 95, 1890);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749849, 'none', 17, 80, 2040);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749850, 'assistent', 14, 69, 1856);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749851, 'none', 14, 79, 1877);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749852, 'none', 14, 77, 1976);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749853, 'none', 17, 100, 2142);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749854, 'none', 15, 75, 2086);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749855, 'none', 18, 90, 2058);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749856, 'none', 18, 73, 2162);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749857, 'assistent', 14, 78, 1974);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749858, 'none', 14, 78, 1945);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749859, 'none', 14, 93, 2195);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749860, 'none', 18, 71, 1980);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749861, 'none', 17, 83, 2036);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749862, 'none', 16, 76, 2085);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749863, 'none', 14, 73, 1904);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749864, 'head', 18, 93, 2045);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749865, 'none', 14, 74, 2005);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749866, 'head', 16, 78, 2130);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749867, 'none', 14, 80, 2069);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749868, 'head', 17, 77, 1836);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749869, 'none', 18, 73, 2112);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749870, 'head', 17, 90, 2053);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749871, 'none', 14, 76, 2212);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749872, 'none', 18, 80, 1862);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749873, 'none', 18, 77, 2117);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749874, 'none', 15, 72, 1948);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749875, 'assistent', 14, 66, 1874);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749876, 'assistent', 16, 85, 1845);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749877, 'none', 17, 88, 1884);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749878, 'none', 16, 68, 2205);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749879, 'none', 18, 87, 1985);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749880, 'none', 14, 67, 2090);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749881, 'none', 18, 94, 1954);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749882, 'none', 17, 85, 2090);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749883, 'none', 15, 90, 1841);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749884, 'none', 15, 85, 2064);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749885, 'head', 17, 67, 2122);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749886, 'head', 17, 88, 1912);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749887, 'none', 18, 69, 2081);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749888, 'none', 18, 93, 2165);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749889, 'assistent', 16, 88, 2013);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749890, 'none', 16, 89, 2005);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749891, 'none', 17, 91, 2058);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749892, 'head', 17, 72, 1905);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749893, 'none', 17, 87, 2053);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749894, 'head', 17, 71, 2100);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749895, 'none', 18, 66, 2016);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749896, 'head', 18, 90, 2078);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749897, 'assistent', 14, 86, 2048);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749898, 'none', 15, 79, 1899);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749899, 'none', 14, 95, 2066);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749900, 'none', 17, 77, 2138);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749901, 'none', 17, 75, 2158);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749902, 'none', 15, 67, 2052);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749903, 'none', 17, 65, 1961);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749904, 'none', 16, 100, 1975);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749905, 'head', 17, 77, 1870);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749906, 'none', 14, 68, 1932);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749907, 'none', 14, 67, 2067);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749908, 'none', 17, 100, 2088);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749909, 'none', 14, 96, 2176);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749910, 'none', 14, 73, 2208);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749911, 'head', 18, 100, 1944);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749912, 'none', 14, 98, 2160);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749913, 'none', 17, 76, 2145);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749914, 'none', 18, 92, 2223);
commit;
prompt 200 records committed...
insert into REPRESENTIVE (id, role, age, average, year)
values (238749915, 'head', 18, 92, 2115);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749916, 'none', 16, 73, 2036);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749917, 'none', 16, 99, 1902);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749918, 'none', 18, 72, 2164);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749919, 'none', 16, 72, 1848);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749920, 'none', 16, 97, 1893);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749921, 'none', 17, 93, 1997);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749922, 'none', 18, 100, 2045);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749923, 'assistent', 14, 86, 2123);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749924, 'assistent', 17, 71, 2020);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749925, 'none', 17, 66, 1987);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749926, 'none', 14, 68, 1872);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749927, 'none', 15, 76, 2214);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749928, 'none', 17, 76, 2190);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749929, 'none', 14, 98, 2205);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749930, 'head', 17, 96, 1827);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749931, 'none', 18, 86, 1860);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749932, 'none', 17, 68, 1836);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749933, 'none', 17, 78, 1939);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749934, 'none', 17, 86, 2039);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749935, 'none', 17, 71, 1839);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749936, 'assistent', 17, 89, 1824);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749937, 'none', 18, 87, 2004);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749938, 'none', 18, 71, 1957);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749939, 'assistent', 16, 67, 2149);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749940, 'assistent', 15, 73, 1832);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749941, 'none', 15, 67, 2120);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749942, 'head', 15, 98, 2130);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749943, 'none', 16, 68, 2175);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749944, 'none', 17, 87, 2121);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749945, 'none', 17, 90, 1886);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749946, 'none', 15, 70, 1977);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749947, 'head', 18, 90, 2071);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749948, 'none', 15, 65, 2115);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749949, 'none', 17, 66, 2152);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749950, 'head', 18, 98, 1966);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749951, 'none', 17, 87, 2131);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749952, 'none', 16, 92, 2168);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749953, 'none', 14, 90, 1999);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749954, 'none', 18, 90, 2186);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749955, 'none', 16, 82, 2164);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749956, 'assistent', 16, 96, 2148);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749957, 'none', 15, 68, 2110);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749958, 'none', 17, 66, 2123);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749959, 'assistent', 17, 88, 2072);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749960, 'none', 17, 96, 2006);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749961, 'none', 16, 68, 2147);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749962, 'head', 18, 75, 2038);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749963, 'assistent', 15, 92, 2021);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749964, 'none', 18, 77, 1951);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749965, 'head', 17, 92, 2126);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749966, 'none', 14, 74, 1935);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749967, 'none', 17, 81, 2220);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749968, 'none', 17, 92, 1830);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749969, 'none', 18, 68, 2191);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749970, 'head', 17, 98, 2145);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749971, 'head', 18, 69, 1891);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749972, 'none', 15, 66, 2099);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749973, 'none', 14, 84, 1989);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749974, 'head', 15, 69, 1892);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749975, 'none', 15, 85, 1851);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749976, 'none', 14, 77, 1996);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749977, 'none', 14, 94, 2047);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749978, 'none', 16, 72, 1874);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749979, 'head', 17, 87, 1881);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749980, 'none', 14, 88, 2122);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749981, 'none', 16, 87, 1945);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749982, 'none', 17, 93, 2038);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749983, 'assistent', 17, 97, 2102);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749984, 'none', 17, 86, 2212);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749985, 'none', 18, 71, 2089);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749986, 'assistent', 17, 77, 2150);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749987, 'none', 14, 83, 1952);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749988, 'head', 18, 99, 2110);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749989, 'assistent', 15, 68, 1893);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749990, 'none', 16, 100, 1976);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749991, 'head', 14, 88, 1960);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749992, 'assistent', 18, 85, 1945);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749993, 'none', 15, 97, 1946);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749994, 'none', 17, 68, 1852);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749995, 'none', 18, 80, 1922);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749996, 'none', 14, 94, 1906);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749997, 'none', 17, 95, 2192);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749998, 'none', 14, 65, 2063);
insert into REPRESENTIVE (id, role, age, average, year)
values (238749999, 'none', 15, 79, 1873);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750000, 'none', 16, 79, 2017);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750001, 'head', 18, 85, 2103);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750002, 'none', 16, 93, 2217);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750003, 'none', 18, 77, 1867);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750004, 'none', 14, 68, 1911);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750005, 'assistent', 15, 88, 2055);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750006, 'assistent', 18, 92, 2216);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750007, 'assistent', 18, 100, 2144);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750008, 'none', 15, 76, 2206);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750009, 'none', 15, 84, 1902);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750010, 'none', 18, 78, 2036);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750011, 'none', 18, 85, 2116);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750012, 'none', 14, 96, 1881);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750013, 'none', 16, 66, 1952);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750014, 'none', 15, 90, 1902);
commit;
prompt 300 records committed...
insert into REPRESENTIVE (id, role, age, average, year)
values (238750015, 'none', 17, 88, 2132);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750016, 'head', 18, 86, 2047);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750017, 'none', 16, 67, 1941);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750018, 'none', 18, 76, 2060);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750019, 'none', 18, 90, 2058);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750020, 'assistent', 17, 71, 2128);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750021, 'none', 18, 79, 2009);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750022, 'head', 16, 95, 2151);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750023, 'none', 16, 96, 1851);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750024, 'none', 17, 87, 2031);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750025, 'none', 16, 72, 2074);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750026, 'none', 15, 91, 2192);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750027, 'none', 14, 89, 2135);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750028, 'head', 15, 71, 1923);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750029, 'none', 15, 99, 2008);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750030, 'assistent', 14, 95, 1945);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750031, 'head', 15, 86, 1973);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750032, 'none', 18, 95, 2005);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750033, 'none', 16, 95, 2212);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750034, 'none', 14, 74, 1895);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750035, 'none', 15, 93, 1846);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750036, 'none', 16, 69, 1890);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750037, 'none', 18, 91, 2189);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750038, 'none', 15, 95, 2223);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750039, 'assistent', 18, 98, 1826);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750040, 'none', 17, 92, 1973);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750041, 'none', 18, 89, 1922);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750042, 'head', 14, 68, 2185);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750043, 'none', 14, 88, 2149);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750044, 'none', 17, 77, 2011);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750045, 'none', 18, 87, 2046);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750046, 'none', 17, 89, 1881);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750047, 'none', 17, 80, 2194);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750048, 'assistent', 15, 65, 2095);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750049, 'assistent', 14, 73, 2025);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750050, 'assistent', 15, 69, 2037);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750051, 'none', 18, 71, 1854);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750052, 'none', 16, 72, 2024);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750053, 'head', 17, 77, 1929);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750054, 'none', 17, 88, 2172);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750055, 'assistent', 14, 98, 2116);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750056, 'none', 15, 74, 1885);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750057, 'none', 18, 96, 2203);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750058, 'none', 16, 89, 1980);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750059, 'none', 17, 87, 2031);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750060, 'none', 15, 71, 2223);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750061, 'none', 17, 78, 1847);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750062, 'none', 17, 89, 1902);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750063, 'none', 18, 87, 2090);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750064, 'none', 16, 74, 2217);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750065, 'none', 14, 94, 2190);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750066, 'none', 18, 92, 2101);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750067, 'none', 17, 85, 2003);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750068, 'none', 16, 95, 1858);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750069, 'none', 16, 69, 1863);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750070, 'none', 15, 76, 1837);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750071, 'none', 18, 100, 2068);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750072, 'none', 17, 96, 2120);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750073, 'assistent', 14, 67, 2178);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750074, 'assistent', 15, 97, 2042);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750075, 'none', 14, 99, 2151);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750076, 'head', 18, 93, 1936);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750077, 'none', 14, 91, 2097);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750078, 'none', 18, 88, 1897);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750079, 'none', 18, 96, 1859);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750080, 'none', 16, 65, 1977);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750081, 'none', 16, 81, 2015);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750082, 'none', 14, 72, 2203);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750083, 'none', 17, 65, 1913);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750084, 'none', 14, 92, 2020);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750085, 'none', 17, 74, 1926);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750086, 'assistent', 14, 75, 1959);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750087, 'none', 18, 79, 1928);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750088, 'none', 14, 88, 1929);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750089, 'none', 14, 90, 2005);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750090, 'none', 17, 79, 2137);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750091, 'head', 16, 76, 2182);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750092, 'head', 16, 83, 1828);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750093, 'assistent', 16, 83, 1980);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750094, 'assistent', 15, 83, 1856);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750095, 'none', 15, 68, 2196);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750096, 'none', 18, 97, 1875);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750097, 'none', 18, 74, 2109);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750098, 'none', 16, 92, 2157);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750099, 'none', 16, 92, 2107);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750100, 'none', 17, 98, 2037);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750101, 'none', 16, 70, 2150);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750102, 'head', 14, 70, 2178);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750103, 'none', 16, 91, 2042);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750104, 'head', 14, 96, 1867);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750105, 'none', 15, 84, 1943);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750106, 'none', 16, 71, 2130);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750107, 'none', 16, 85, 1895);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750108, 'none', 15, 98, 1877);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750109, 'none', 15, 90, 1979);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750110, 'none', 18, 85, 1870);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750111, 'none', 16, 83, 1899);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750112, 'none', 16, 94, 2115);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750113, 'none', 18, 87, 1981);
insert into REPRESENTIVE (id, role, age, average, year)
values (238750114, 'none', 17, 65, 1879);
commit;
prompt 400 records loaded
prompt Loading TEACH...
insert into TEACH (id, institutionid)
values (34828621, 1000000309);
insert into TEACH (id, institutionid)
values (32333343, 1000000057);
insert into TEACH (id, institutionid)
values (33895920, 1000000341);
insert into TEACH (id, institutionid)
values (35034542, 1000000383);
insert into TEACH (id, institutionid)
values (32200100, 1000000024);
insert into TEACH (id, institutionid)
values (36572893, 1000000236);
insert into TEACH (id, institutionid)
values (34101841, 1000000211);
insert into TEACH (id, institutionid)
values (33738451, 1000000303);
insert into TEACH (id, institutionid)
values (33035897, 1000000143);
insert into TEACH (id, institutionid)
values (34162406, 1000000150);
insert into TEACH (id, institutionid)
values (35930904, 1000000344);
insert into TEACH (id, institutionid)
values (33859581, 1000000108);
insert into TEACH (id, institutionid)
values (35918791, 1000000359);
insert into TEACH (id, institutionid)
values (36282181, 1000000316);
insert into TEACH (id, institutionid)
values (34998203, 1000000256);
insert into TEACH (id, institutionid)
values (32866315, 1000000268);
insert into TEACH (id, institutionid)
values (34574248, 1000000118);
insert into TEACH (id, institutionid)
values (35894565, 1000000347);
insert into TEACH (id, institutionid)
values (34537909, 1000000229);
insert into TEACH (id, institutionid)
values (32684620, 1000000097);
insert into TEACH (id, institutionid)
values (34077615, 1000000382);
insert into TEACH (id, institutionid)
values (36754588, 1000000125);
insert into TEACH (id, institutionid)
values (33556756, 1000000033);
insert into TEACH (id, institutionid)
values (34816508, 1000000179);
insert into TEACH (id, institutionid)
values (33144914, 1000000305);
insert into TEACH (id, institutionid)
values (36572893, 1000000087);
insert into TEACH (id, institutionid)
values (34755943, 1000000174);
insert into TEACH (id, institutionid)
values (33508304, 1000000318);
insert into TEACH (id, institutionid)
values (35773435, 1000000048);
insert into TEACH (id, institutionid)
values (32490812, 1000000238);
insert into TEACH (id, institutionid)
values (33241818, 1000000064);
insert into TEACH (id, institutionid)
values (35785548, 1000000220);
insert into TEACH (id, institutionid)
values (34126067, 1000000112);
insert into TEACH (id, institutionid)
values (33956485, 1000000295);
insert into TEACH (id, institutionid)
values (34755943, 1000000317);
insert into TEACH (id, institutionid)
values (35785548, 1000000092);
insert into TEACH (id, institutionid)
values (35313141, 1000000391);
insert into TEACH (id, institutionid)
values (34780169, 1000000151);
insert into TEACH (id, institutionid)
values (35337367, 1000000370);
insert into TEACH (id, institutionid)
values (35397932, 1000000370);
insert into TEACH (id, institutionid)
values (35179898, 1000000163);
insert into TEACH (id, institutionid)
values (36391198, 1000000260);
insert into TEACH (id, institutionid)
values (35228350, 1000000229);
insert into TEACH (id, institutionid)
values (33738451, 1000000171);
insert into TEACH (id, institutionid)
values (36039921, 1000000194);
insert into TEACH (id, institutionid)
values (35010316, 1000000360);
insert into TEACH (id, institutionid)
values (33762677, 1000000340);
insert into TEACH (id, institutionid)
values (33895920, 1000000073);
insert into TEACH (id, institutionid)
values (35603853, 1000000173);
insert into TEACH (id, institutionid)
values (35834000, 1000000105);
insert into TEACH (id, institutionid)
values (34174519, 1000000388);
insert into TEACH (id, institutionid)
values (32963219, 1000000013);
insert into TEACH (id, institutionid)
values (35591740, 1000000269);
insert into TEACH (id, institutionid)
values (35930904, 1000000036);
insert into TEACH (id, institutionid)
values (34198745, 1000000212);
insert into TEACH (id, institutionid)
values (34271423, 1000000317);
insert into TEACH (id, institutionid)
values (36112599, 1000000018);
insert into TEACH (id, institutionid)
values (34198745, 1000000066);
insert into TEACH (id, institutionid)
values (36379085, 1000000057);
insert into TEACH (id, institutionid)
values (33193366, 1000000253);
insert into TEACH (id, institutionid)
values (35216237, 1000000129);
insert into TEACH (id, institutionid)
values (34307762, 1000000297);
insert into TEACH (id, institutionid)
values (34380440, 1000000141);
insert into TEACH (id, institutionid)
values (34755943, 1000000107);
insert into TEACH (id, institutionid)
values (33593095, 1000000017);
insert into TEACH (id, institutionid)
values (35797661, 1000000162);
insert into TEACH (id, institutionid)
values (33653660, 1000000355);
insert into TEACH (id, institutionid)
values (35264689, 1000000385);
insert into TEACH (id, institutionid)
values (34671152, 1000000263);
insert into TEACH (id, institutionid)
values (32817863, 1000000286);
insert into TEACH (id, institutionid)
values (33484078, 1000000080);
insert into TEACH (id, institutionid)
values (35712870, 1000000141);
insert into TEACH (id, institutionid)
values (35410045, 1000000000);
insert into TEACH (id, institutionid)
values (34901299, 1000000277);
insert into TEACH (id, institutionid)
values (33665773, 1000000136);
insert into TEACH (id, institutionid)
values (33580982, 1000000030);
insert into TEACH (id, institutionid)
values (36730362, 1000000016);
insert into TEACH (id, institutionid)
values (32418134, 1000000044);
insert into TEACH (id, institutionid)
values (36645571, 1000000052);
insert into TEACH (id, institutionid)
values (36948396, 1000000084);
insert into TEACH (id, institutionid)
values (34852847, 1000000390);
insert into TEACH (id, institutionid)
values (32442360, 1000000231);
insert into TEACH (id, institutionid)
values (35361593, 1000000262);
insert into TEACH (id, institutionid)
values (32684620, 1000000216);
insert into TEACH (id, institutionid)
values (32381795, 1000000254);
insert into TEACH (id, institutionid)
values (34501570, 1000000186);
insert into TEACH (id, institutionid)
values (35349480, 1000000026);
insert into TEACH (id, institutionid)
values (34998203, 1000000245);
insert into TEACH (id, institutionid)
values (35058768, 1000000072);
insert into TEACH (id, institutionid)
values (33205479, 1000000252);
insert into TEACH (id, institutionid)
values (33544643, 1000000277);
insert into TEACH (id, institutionid)
values (34925525, 1000000250);
insert into TEACH (id, institutionid)
values (34392553, 1000000051);
insert into TEACH (id, institutionid)
values (33290270, 1000000377);
insert into TEACH (id, institutionid)
values (36124712, 1000000191);
insert into TEACH (id, institutionid)
values (34901299, 1000000048);
insert into TEACH (id, institutionid)
values (34138180, 1000000272);
insert into TEACH (id, institutionid)
values (33496191, 1000000258);
insert into TEACH (id, institutionid)
values (33072236, 1000000284);
insert into TEACH (id, institutionid)
values (32817863, 1000000194);
commit;
prompt 100 records committed...
insert into TEACH (id, institutionid)
values (33459852, 1000000152);
insert into TEACH (id, institutionid)
values (32539264, 1000000204);
insert into TEACH (id, institutionid)
values (36027808, 1000000033);
insert into TEACH (id, institutionid)
values (32951106, 1000000112);
insert into TEACH (id, institutionid)
values (34646926, 1000000028);
insert into TEACH (id, institutionid)
values (32926880, 1000000327);
insert into TEACH (id, institutionid)
values (34041276, 1000000020);
insert into TEACH (id, institutionid)
values (35458497, 1000000141);
insert into TEACH (id, institutionid)
values (36621345, 1000000059);
insert into TEACH (id, institutionid)
values (33060123, 1000000055);
insert into TEACH (id, institutionid)
values (36912057, 1000000207);
insert into TEACH (id, institutionid)
values (33375061, 1000000322);
insert into TEACH (id, institutionid)
values (33520417, 1000000070);
insert into TEACH (id, institutionid)
values (36500215, 1000000373);
insert into TEACH (id, institutionid)
values (36354859, 1000000329);
insert into TEACH (id, institutionid)
values (36669797, 1000000289);
insert into TEACH (id, institutionid)
values (33060123, 1000000299);
insert into TEACH (id, institutionid)
values (34913412, 1000000389);
insert into TEACH (id, institutionid)
values (35410045, 1000000016);
insert into TEACH (id, institutionid)
values (35906678, 1000000307);
insert into TEACH (id, institutionid)
values (36330633, 1000000291);
insert into TEACH (id, institutionid)
values (32551377, 1000000222);
insert into TEACH (id, institutionid)
values (34501570, 1000000239);
insert into TEACH (id, institutionid)
values (36548667, 1000000215);
insert into TEACH (id, institutionid)
values (32539264, 1000000300);
insert into TEACH (id, institutionid)
values (34622700, 1000000217);
insert into TEACH (id, institutionid)
values (32309117, 1000000081);
insert into TEACH (id, institutionid)
values (33011671, 1000000312);
insert into TEACH (id, institutionid)
values (32745185, 1000000025);
insert into TEACH (id, institutionid)
values (33605208, 1000000085);
insert into TEACH (id, institutionid)
values (36706136, 1000000034);
insert into TEACH (id, institutionid)
values (33835355, 1000000152);
insert into TEACH (id, institutionid)
values (36064147, 1000000268);
insert into TEACH (id, institutionid)
values (36996848, 1000000370);
insert into TEACH (id, institutionid)
values (32284891, 1000000220);
insert into TEACH (id, institutionid)
values (36330633, 1000000077);
insert into TEACH (id, institutionid)
values (35010316, 1000000318);
insert into TEACH (id, institutionid)
values (34864960, 1000000236);
insert into TEACH (id, institutionid)
values (35519062, 1000000336);
insert into TEACH (id, institutionid)
values (32963219, 1000000263);
insert into TEACH (id, institutionid)
values (35555401, 1000000261);
insert into TEACH (id, institutionid)
values (33048010, 1000000382);
insert into TEACH (id, institutionid)
values (33859581, 1000000123);
insert into TEACH (id, institutionid)
values (35095107, 1000000106);
insert into TEACH (id, institutionid)
values (34029163, 1000000208);
insert into TEACH (id, institutionid)
values (35797661, 1000000285);
insert into TEACH (id, institutionid)
values (36609232, 1000000369);
insert into TEACH (id, institutionid)
values (36391198, 1000000315);
insert into TEACH (id, institutionid)
values (32938993, 1000000063);
insert into TEACH (id, institutionid)
values (36015695, 1000000159);
insert into TEACH (id, institutionid)
values (33992824, 1000000024);
insert into TEACH (id, institutionid)
values (32236439, 1000000148);
insert into TEACH (id, institutionid)
values (32963219, 1000000197);
insert into TEACH (id, institutionid)
values (32442360, 1000000052);
insert into TEACH (id, institutionid)
values (34174519, 1000000246);
insert into TEACH (id, institutionid)
values (32260665, 1000000157);
insert into TEACH (id, institutionid)
values (34949751, 1000000262);
insert into TEACH (id, institutionid)
values (35010316, 1000000054);
insert into TEACH (id, institutionid)
values (32575603, 1000000177);
insert into TEACH (id, institutionid)
values (36766701, 1000000070);
insert into TEACH (id, institutionid)
values (32418134, 1000000124);
insert into TEACH (id, institutionid)
values (34174519, 1000000044);
insert into TEACH (id, institutionid)
values (34949751, 1000000035);
insert into TEACH (id, institutionid)
values (35264689, 1000000192);
insert into TEACH (id, institutionid)
values (33556756, 1000000121);
insert into TEACH (id, institutionid)
values (35943017, 1000000147);
insert into TEACH (id, institutionid)
values (37033187, 1000000334);
insert into TEACH (id, institutionid)
values (36851492, 1000000331);
insert into TEACH (id, institutionid)
values (34973977, 1000000245);
insert into TEACH (id, institutionid)
values (36681910, 1000000330);
insert into TEACH (id, institutionid)
values (33629434, 1000000037);
insert into TEACH (id, institutionid)
values (35434271, 1000000252);
insert into TEACH (id, institutionid)
values (34598474, 1000000255);
insert into TEACH (id, institutionid)
values (34525796, 1000000315);
insert into TEACH (id, institutionid)
values (32878428, 1000000017);
insert into TEACH (id, institutionid)
values (35846113, 1000000056);
insert into TEACH (id, institutionid)
values (35155672, 1000000305);
insert into TEACH (id, institutionid)
values (33823242, 1000000216);
insert into TEACH (id, institutionid)
values (36803040, 1000000262);
insert into TEACH (id, institutionid)
values (34222971, 1000000077);
insert into TEACH (id, institutionid)
values (33362948, 1000000107);
insert into TEACH (id, institutionid)
values (32963219, 1000000309);
insert into TEACH (id, institutionid)
values (36778814, 1000000392);
insert into TEACH (id, institutionid)
values (35022429, 1000000314);
insert into TEACH (id, institutionid)
values (33750564, 1000000213);
insert into TEACH (id, institutionid)
values (34259310, 1000000317);
insert into TEACH (id, institutionid)
values (33544643, 1000000304);
insert into TEACH (id, institutionid)
values (36875718, 1000000183);
insert into TEACH (id, institutionid)
values (33605208, 1000000222);
insert into TEACH (id, institutionid)
values (32357569, 1000000229);
insert into TEACH (id, institutionid)
values (33205479, 1000000147);
insert into TEACH (id, institutionid)
values (35676531, 1000000192);
insert into TEACH (id, institutionid)
values (32575603, 1000000317);
insert into TEACH (id, institutionid)
values (34489457, 1000000236);
insert into TEACH (id, institutionid)
values (33932259, 1000000014);
insert into TEACH (id, institutionid)
values (35240463, 1000000345);
insert into TEACH (id, institutionid)
values (32720959, 1000000121);
insert into TEACH (id, institutionid)
values (34852847, 1000000199);
insert into TEACH (id, institutionid)
values (32309117, 1000000167);
insert into TEACH (id, institutionid)
values (36463876, 1000000069);
commit;
prompt 200 records committed...
insert into TEACH (id, institutionid)
values (34222971, 1000000081);
insert into TEACH (id, institutionid)
values (35519062, 1000000236);
insert into TEACH (id, institutionid)
values (34804395, 1000000178);
insert into TEACH (id, institutionid)
values (34065502, 1000000067);
insert into TEACH (id, institutionid)
values (36003582, 1000000178);
insert into TEACH (id, institutionid)
values (36015695, 1000000041);
insert into TEACH (id, institutionid)
values (35688644, 1000000205);
insert into TEACH (id, institutionid)
values (35446384, 1000000092);
insert into TEACH (id, institutionid)
values (36899944, 1000000357);
insert into TEACH (id, institutionid)
values (35325254, 1000000119);
insert into TEACH (id, institutionid)
values (33968598, 1000000386);
insert into TEACH (id, institutionid)
values (33750564, 1000000255);
insert into TEACH (id, institutionid)
values (36912057, 1000000292);
insert into TEACH (id, institutionid)
values (36718249, 1000000153);
insert into TEACH (id, institutionid)
values (36112599, 1000000361);
insert into TEACH (id, institutionid)
values (32236439, 1000000249);
insert into TEACH (id, institutionid)
values (34113954, 1000000062);
insert into TEACH (id, institutionid)
values (35773435, 1000000095);
insert into TEACH (id, institutionid)
values (34792282, 1000000117);
insert into TEACH (id, institutionid)
values (32466586, 1000000100);
insert into TEACH (id, institutionid)
values (36209503, 1000000166);
insert into TEACH (id, institutionid)
values (35494836, 1000000379);
insert into TEACH (id, institutionid)
values (36524441, 1000000157);
insert into TEACH (id, institutionid)
values (34998203, 1000000048);
insert into TEACH (id, institutionid)
values (33786903, 1000000053);
insert into TEACH (id, institutionid)
values (35022429, 1000000062);
insert into TEACH (id, institutionid)
values (36136825, 1000000203);
insert into TEACH (id, institutionid)
values (33108575, 1000000345);
insert into TEACH (id, institutionid)
values (36754588, 1000000380);
insert into TEACH (id, institutionid)
values (35579627, 1000000088);
insert into TEACH (id, institutionid)
values (35288915, 1000000009);
insert into TEACH (id, institutionid)
values (33447739, 1000000187);
insert into TEACH (id, institutionid)
values (33665773, 1000000200);
insert into TEACH (id, institutionid)
values (34598474, 1000000080);
insert into TEACH (id, institutionid)
values (36984735, 1000000313);
insert into TEACH (id, institutionid)
values (35773435, 1000000163);
insert into TEACH (id, institutionid)
values (33568869, 1000000265);
insert into TEACH (id, institutionid)
values (32406021, 1000000250);
insert into TEACH (id, institutionid)
values (35567514, 1000000304);
insert into TEACH (id, institutionid)
values (34889186, 1000000234);
insert into TEACH (id, institutionid)
values (35615966, 1000000063);
insert into TEACH (id, institutionid)
values (36548667, 1000000044);
insert into TEACH (id, institutionid)
values (36076260, 1000000021);
insert into TEACH (id, institutionid)
values (34949751, 1000000034);
insert into TEACH (id, institutionid)
values (32842089, 1000000178);
insert into TEACH (id, institutionid)
values (35179898, 1000000304);
insert into TEACH (id, institutionid)
values (35240463, 1000000074);
insert into TEACH (id, institutionid)
values (32490812, 1000000298);
insert into TEACH (id, institutionid)
values (35591740, 1000000368);
insert into TEACH (id, institutionid)
values (35943017, 1000000160);
insert into TEACH (id, institutionid)
values (36488102, 1000000288);
insert into TEACH (id, institutionid)
values (36257955, 1000000216);
insert into TEACH (id, institutionid)
values (32321230, 1000000180);
insert into TEACH (id, institutionid)
values (35058768, 1000000243);
insert into TEACH (id, institutionid)
values (36403311, 1000000074);
insert into TEACH (id, institutionid)
values (36354859, 1000000307);
insert into TEACH (id, institutionid)
values (33035897, 1000000079);
insert into TEACH (id, institutionid)
values (32660394, 1000000223);
insert into TEACH (id, institutionid)
values (35591740, 1000000129);
insert into TEACH (id, institutionid)
values (34283536, 1000000023);
insert into TEACH (id, institutionid)
values (35506949, 1000000308);
insert into TEACH (id, institutionid)
values (36330633, 1000000280);
insert into TEACH (id, institutionid)
values (35313141, 1000000253);
insert into TEACH (id, institutionid)
values (36984735, 1000000079);
insert into TEACH (id, institutionid)
values (35422158, 1000000274);
insert into TEACH (id, institutionid)
values (33496191, 1000000087);
insert into TEACH (id, institutionid)
values (34501570, 1000000096);
insert into TEACH (id, institutionid)
values (34138180, 1000000300);
insert into TEACH (id, institutionid)
values (36815153, 1000000051);
insert into TEACH (id, institutionid)
values (34307762, 1000000129);
insert into TEACH (id, institutionid)
values (36645571, 1000000031);
insert into TEACH (id, institutionid)
values (36439650, 1000000202);
insert into TEACH (id, institutionid)
values (33726338, 1000000021);
insert into TEACH (id, institutionid)
values (34949751, 1000000142);
insert into TEACH (id, institutionid)
values (32890541, 1000000147);
insert into TEACH (id, institutionid)
values (34126067, 1000000295);
insert into TEACH (id, institutionid)
values (35809774, 1000000226);
insert into TEACH (id, institutionid)
values (36875718, 1000000277);
insert into TEACH (id, institutionid)
values (33774790, 1000000173);
insert into TEACH (id, institutionid)
values (35870339, 1000000106);
insert into TEACH (id, institutionid)
values (36039921, 1000000254);
insert into TEACH (id, institutionid)
values (34973977, 1000000191);
insert into TEACH (id, institutionid)
values (33544643, 1000000322);
insert into TEACH (id, institutionid)
values (32757298, 1000000138);
insert into TEACH (id, institutionid)
values (36912057, 1000000049);
insert into TEACH (id, institutionid)
values (32587716, 1000000060);
insert into TEACH (id, institutionid)
values (32757298, 1000000265);
insert into TEACH (id, institutionid)
values (32878428, 1000000139);
insert into TEACH (id, institutionid)
values (33338722, 1000000043);
insert into TEACH (id, institutionid)
values (35119333, 1000000321);
insert into TEACH (id, institutionid)
values (32345456, 1000000223);
insert into TEACH (id, institutionid)
values (35700757, 1000000112);
insert into TEACH (id, institutionid)
values (34562135, 1000000216);
insert into TEACH (id, institutionid)
values (36548667, 1000000137);
insert into TEACH (id, institutionid)
values (32587716, 1000000191);
insert into TEACH (id, institutionid)
values (33278157, 1000000040);
insert into TEACH (id, institutionid)
values (33120688, 1000000076);
insert into TEACH (id, institutionid)
values (32999558, 1000000184);
insert into TEACH (id, institutionid)
values (32563490, 1000000082);
insert into TEACH (id, institutionid)
values (33689999, 1000000334);
commit;
prompt 300 records committed...
insert into TEACH (id, institutionid)
values (32272778, 1000000373);
insert into TEACH (id, institutionid)
values (34222971, 1000000168);
insert into TEACH (id, institutionid)
values (34622700, 1000000002);
insert into TEACH (id, institutionid)
values (33811129, 1000000216);
insert into TEACH (id, institutionid)
values (34864960, 1000000129);
insert into TEACH (id, institutionid)
values (34041276, 1000000265);
insert into TEACH (id, institutionid)
values (34768056, 1000000241);
insert into TEACH (id, institutionid)
values (33665773, 1000000021);
insert into TEACH (id, institutionid)
values (32648281, 1000000196);
insert into TEACH (id, institutionid)
values (36972622, 1000000085);
insert into TEACH (id, institutionid)
values (32563490, 1000000198);
insert into TEACH (id, institutionid)
values (34029163, 1000000219);
insert into TEACH (id, institutionid)
values (34550022, 1000000141);
insert into TEACH (id, institutionid)
values (34235084, 1000000361);
insert into TEACH (id, institutionid)
values (36633458, 1000000224);
insert into TEACH (id, institutionid)
values (36766701, 1000000373);
insert into TEACH (id, institutionid)
values (32272778, 1000000058);
insert into TEACH (id, institutionid)
values (35712870, 1000000168);
insert into TEACH (id, institutionid)
values (36427537, 1000000397);
insert into TEACH (id, institutionid)
values (33484078, 1000000014);
insert into TEACH (id, institutionid)
values (34089728, 1000000094);
insert into TEACH (id, institutionid)
values (36863605, 1000000057);
insert into TEACH (id, institutionid)
values (32551377, 1000000214);
insert into TEACH (id, institutionid)
values (35494836, 1000000245);
insert into TEACH (id, institutionid)
values (35894565, 1000000113);
insert into TEACH (id, institutionid)
values (36851492, 1000000324);
insert into TEACH (id, institutionid)
values (33399287, 1000000014);
insert into TEACH (id, institutionid)
values (33932259, 1000000064);
insert into TEACH (id, institutionid)
values (36161051, 1000000280);
insert into TEACH (id, institutionid)
values (35119333, 1000000397);
insert into TEACH (id, institutionid)
values (32745185, 1000000126);
insert into TEACH (id, institutionid)
values (35264689, 1000000222);
insert into TEACH (id, institutionid)
values (36730362, 1000000166);
insert into TEACH (id, institutionid)
values (35470610, 1000000156);
insert into TEACH (id, institutionid)
values (36076260, 1000000135);
insert into TEACH (id, institutionid)
values (36524441, 1000000196);
insert into TEACH (id, institutionid)
values (34174519, 1000000385);
insert into TEACH (id, institutionid)
values (33702112, 1000000364);
insert into TEACH (id, institutionid)
values (33920146, 1000000285);
insert into TEACH (id, institutionid)
values (32333343, 1000000293);
insert into TEACH (id, institutionid)
values (35628079, 1000000348);
insert into TEACH (id, institutionid)
values (36742475, 1000000241);
insert into TEACH (id, institutionid)
values (33641547, 1000000192);
insert into TEACH (id, institutionid)
values (34319875, 1000000080);
insert into TEACH (id, institutionid)
values (36270068, 1000000155);
insert into TEACH (id, institutionid)
values (36366972, 1000000149);
insert into TEACH (id, institutionid)
values (33411400, 1000000098);
insert into TEACH (id, institutionid)
values (35228350, 1000000329);
insert into TEACH (id, institutionid)
values (35809774, 1000000193);
insert into TEACH (id, institutionid)
values (33835355, 1000000207);
insert into TEACH (id, institutionid)
values (35192011, 1000000236);
insert into TEACH (id, institutionid)
values (33714225, 1000000103);
insert into TEACH (id, institutionid)
values (35894565, 1000000079);
insert into TEACH (id, institutionid)
values (33508304, 1000000032);
insert into TEACH (id, institutionid)
values (33835355, 1000000330);
insert into TEACH (id, institutionid)
values (32999558, 1000000154);
insert into TEACH (id, institutionid)
values (32975332, 1000000112);
insert into TEACH (id, institutionid)
values (34271423, 1000000003);
insert into TEACH (id, institutionid)
values (35543288, 1000000015);
insert into TEACH (id, institutionid)
values (32381795, 1000000248);
insert into TEACH (id, institutionid)
values (35737096, 1000000059);
insert into TEACH (id, institutionid)
values (33362948, 1000000053);
insert into TEACH (id, institutionid)
values (33023784, 1000000181);
insert into TEACH (id, institutionid)
values (36112599, 1000000023);
insert into TEACH (id, institutionid)
values (34307762, 1000000065);
insert into TEACH (id, institutionid)
values (32975332, 1000000380);
insert into TEACH (id, institutionid)
values (34259310, 1000000047);
insert into TEACH (id, institutionid)
values (35894565, 1000000161);
insert into TEACH (id, institutionid)
values (32866315, 1000000086);
insert into TEACH (id, institutionid)
values (35022429, 1000000090);
insert into TEACH (id, institutionid)
values (33423513, 1000000356);
insert into TEACH (id, institutionid)
values (34901299, 1000000296);
insert into TEACH (id, institutionid)
values (33980711, 1000000245);
insert into TEACH (id, institutionid)
values (33786903, 1000000160);
insert into TEACH (id, institutionid)
values (35397932, 1000000297);
insert into TEACH (id, institutionid)
values (35664418, 1000000034);
insert into TEACH (id, institutionid)
values (33023784, 1000000117);
insert into TEACH (id, institutionid)
values (35470610, 1000000329);
insert into TEACH (id, institutionid)
values (36972622, 1000000147);
insert into TEACH (id, institutionid)
values (35652305, 1000000313);
insert into TEACH (id, institutionid)
values (32224326, 1000000140);
insert into TEACH (id, institutionid)
values (36996848, 1000000314);
insert into TEACH (id, institutionid)
values (32624055, 1000000049);
insert into TEACH (id, institutionid)
values (35216237, 1000000275);
insert into TEACH (id, institutionid)
values (35712870, 1000000347);
insert into TEACH (id, institutionid)
values (36463876, 1000000147);
insert into TEACH (id, institutionid)
values (35082994, 1000000102);
insert into TEACH (id, institutionid)
values (33653660, 1000000071);
insert into TEACH (id, institutionid)
values (35058768, 1000000021);
insert into TEACH (id, institutionid)
values (36694023, 1000000040);
insert into TEACH (id, institutionid)
values (33193366, 1000000184);
insert into TEACH (id, institutionid)
values (32999558, 1000000385);
insert into TEACH (id, institutionid)
values (33968598, 1000000285);
insert into TEACH (id, institutionid)
values (37008961, 1000000177);
insert into TEACH (id, institutionid)
values (32551377, 1000000301);
insert into TEACH (id, institutionid)
values (34671152, 1000000293);
insert into TEACH (id, institutionid)
values (34525796, 1000000007);
insert into TEACH (id, institutionid)
values (32502925, 1000000030);
insert into TEACH (id, institutionid)
values (33350835, 1000000253);
insert into TEACH (id, institutionid)
values (34162406, 1000000232);
commit;
prompt 400 records loaded
prompt Enabling foreign key constraints for PARTICIPANT...
alter table PARTICIPANT enable constraint SYS_C009151;
alter table PARTICIPANT enable constraint SYS_C009152;
prompt Enabling foreign key constraints for PUPIL...
alter table PUPIL enable constraint SYS_C009144;
prompt Enabling foreign key constraints for REPRESENTIVE...
alter table REPRESENTIVE enable constraint SYS_C009146;
alter table REPRESENTIVE enable constraint SYS_C009147;
prompt Enabling foreign key constraints for TEACH...
alter table TEACH enable constraint SYS_C009154;
alter table TEACH enable constraint SYS_C009155;
prompt Enabling triggers for ACADEMIC_INSTITUTION...
alter table ACADEMIC_INSTITUTION enable all triggers;
prompt Enabling triggers for TEACHER...
alter table TEACHER enable all triggers;
prompt Enabling triggers for TRAINING...
alter table TRAINING enable all triggers;
prompt Enabling triggers for PARTICIPANT...
alter table PARTICIPANT enable all triggers;
prompt Enabling triggers for PUPIL...
alter table PUPIL enable all triggers;
prompt Enabling triggers for STUDENTCOUNCIL...
alter table STUDENTCOUNCIL enable all triggers;
prompt Enabling triggers for REPRESENTIVE...
alter table REPRESENTIVE enable all triggers;
prompt Enabling triggers for TEACH...
alter table TEACH enable all triggers;
set feedback on
set define on
prompt Done.
